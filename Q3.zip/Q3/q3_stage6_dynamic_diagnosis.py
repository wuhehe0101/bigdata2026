# -*- coding: utf-8 -*-
"""MathorCup Q3 Stage 6: dynamic score changes / persistent-alarm diagnosis.
Python q3_stage6_dynamic_diagnosis.py (place beside Q3_stage1_results).
Uses ONLY frozen Q2 score, no future observations at each evaluated time.
Outputs ASCII filenames; no matplotlib / scipy / pyproj.
"""
from pathlib import Path
import argparse
import json
import numpy as np
import pandas as pd

THRESHOLD = 0.5193085227
CASES = [
    ('ice_collapse_20260826', '2026-08-26 10:52:00', 'ice-rock collapse proxy; not exact debris-flow initiation'),
    ('flood_20250708', '2025-07-08 05:45:00', 'flood only; not a debris-flow training/validation label'),
]
WINDOWS = (1, 6, 12, 24, 48, 72)

def find_input(base, explicit):
    candidates = [Path(explicit)] if explicit else [base/'Q3_stage1_results'/'hourly_q2_score.csv', base/'hourly_q2_score.csv']
    for c in candidates:
        if c.is_file():
            return c.resolve()
    raise FileNotFoundError('找不到 hourly_q2_score.csv。尝试: ' + '; '.join(map(str,candidates)))

def round_json(x):
    if isinstance(x, (np.integer,)): return int(x)
    if isinstance(x, (np.floating,)): return float(x) if np.isfinite(x) else None
    if isinstance(x, (pd.Timestamp,)): return str(x)
    raise TypeError(type(x).__name__)

def main():
    p = argparse.ArgumentParser(description='Q3 stage6: score change and alarm persistence, no plot DLLs')
    p.add_argument('--input', default=None, help='第一阶段hourly_q2_score.csv的绝对路径')
    p.add_argument('--out', default=None, help='结果文件夹')
    p.add_argument('--history-hours', type=int, default=168)
    a = p.parse_args()
    base = Path(__file__).resolve().parent
    src = find_input(base, a.input)
    out = Path(a.out).resolve() if a.out else base/'Q3_stage6_results'
    out.mkdir(parents=True, exist_ok=True)
    print('[1/5] 读取:', src, flush=True)
    df = pd.read_csv(src, encoding='utf-8-sig', low_memory=False)
    for name in ('Timestamp','score'):
        if name not in df: raise ValueError('输入文件缺少列 '+name)
    df['Timestamp'] = pd.to_datetime(df['Timestamp'], errors='raise')
    if df['Timestamp'].duplicated().any(): raise ValueError('重复时间戳')
    df = df.set_index('Timestamp').sort_index().asfreq('h')
    df['score'] = pd.to_numeric(df['score'], errors='coerce')
    score = df['score']
    alarm = score.ge(THRESHOLD).where(score.notna(), pd.NA).astype('boolean')
    df['alarm'] = alarm
    for h in (6,24):
        # Delta only if both endpoints observed; no filling missing data.
        df[f'delta_{h}h'] = score - score.shift(h)
    # Complete continuous alarm run; missing values break runs and mark left-censored starts.
    valid = alarm.fillna(False).astype(bool).to_numpy()
    vals = score.notna().to_numpy()
    lengths = np.zeros(len(df), dtype=np.int64)
    start_index = np.full(len(df), -1, dtype=np.int64)
    for i in range(len(df)):
        if valid[i]:
            if i and valid[i-1]:
                lengths[i] = lengths[i-1] + 1
                start_index[i] = start_index[i-1]
            else:
                lengths[i] = 1
                start_index[i] = i
    df['alarm_run_hours_observed'] = lengths
    df['alarm_run_start_observed'] = pd.NaT
    idx = df.index.to_numpy()
    ix = start_index >= 0
    df.loc[ix,'alarm_run_start_observed'] = pd.to_datetime(idx[start_index[ix]])
    # A transition is confirmed only if preceding hour is observed and below threshold.
    prev_valid = np.r_[False, vals[:-1]]
    df['confirmed_new_crossing'] = valid & prev_valid & np.r_[False, ~valid[:-1]]
    df['run_left_censored'] = ix & ((start_index == 0) | (~vals[np.maximum(start_index-1,0)]))
    # Build exploratory reference from training PERIOD only, never case/test time periods.
    train = df.loc['2021-04-01':'2021-07-31']
    baseline = {}
    for h in (6,24):
        arr = train[f'delta_{h}h'].dropna().to_numpy(dtype=float)
        if len(arr) < 50: raise ValueError(f'训练期有效delta_{h}h太少: {len(arr)}')
        baseline[f'delta_{h}h'] = {'n':len(arr), 'q95':float(np.quantile(arr,.95)), 'q99':float(np.quantile(arr,.99)), 'median':float(np.median(arr))}
        df[f'rise_{h}h_q95'] = (df[f'delta_{h}h'] > baseline[f'delta_{h}h']['q95']).astype('boolean')
        df.loc[df[f'delta_{h}h'].isna(), f'rise_{h}h_q95'] = pd.NA
    print('[2/5] 训练期参考分位数:', json.dumps(baseline,ensure_ascii=False), flush=True)
    rows = []
    window_rows = []
    hour_rows = []
    for case_id, reference, note in CASES:
        event = pd.Timestamp(reference)
        sub = df.loc[(df.index >= event - pd.Timedelta(hours=a.history_hours)) & (df.index < event)].copy()
        if sub.empty: raise ValueError(f'{case_id} 在文件时间范围之外')
        last = sub.iloc[-1]
        start_run = last['alarm_run_start_observed'] if (pd.notna(last['alarm']) and bool(last['alarm'])) else pd.NaT
        # The alarm run may extend earlier than the displayed analysis window; use full score history.
        row = {'case_id':case_id, 'reference_time':str(event), 'case_note':note,
               'last_hour':str(sub.index[-1]), 'last_score':float(last['score']) if pd.notna(last['score']) else None,
               'last_above_threshold':bool(last['alarm']) if pd.notna(last['alarm']) else None,
               'alarm_run_hours_at_last_hour':int(last['alarm_run_hours_observed']),
               'alarm_run_start_observed':str(start_run) if pd.notna(start_run) else '',
               'run_left_censored':bool(last['run_left_censored']),
               'confirmed_crossings_history':int(sub['confirmed_new_crossing'].sum()),
               'history_valid_score_hours':int(sub['score'].notna().sum()),
               'history_hours':len(sub)}
        for h in (6,24):
            col = f'delta_{h}h'
            row[f'last_{col}'] = float(last[col]) if pd.notna(last[col]) else None
            row[f'last_rise_{h}h_above_train_q95'] = bool(last[f'rise_{h}h_q95']) if pd.notna(last[f'rise_{h}h_q95']) else None
        rows.append(row)
        sub['case_id'] = case_id
        sub['hours_before_reference'] = ((event-sub.index).total_seconds()/3600).round(3)
        hour_rows.append(sub.reset_index()[['case_id','Timestamp','hours_before_reference','score','alarm','delta_6h','delta_24h','rise_6h_q95','rise_24h_q95','confirmed_new_crossing','alarm_run_hours_observed','run_left_censored']])
        for h in WINDOWS:
            w = sub.loc[sub.index >= event - pd.Timedelta(hours=h)]
            window_rows.append({'case_id':case_id,'lookback_hours':h, 'hours_present':len(w),
                'score_valid_hours':int(w['score'].notna().sum()),
                'alarm_hours':int(w['alarm'].fillna(False).sum()),
                'confirmed_new_crossings':int(w['confirmed_new_crossing'].sum()),
                'delta6_positive_hours':int(w['delta_6h'].gt(0).sum()),
                'delta6_q95_exceed_hours':int(w['rise_6h_q95'].fillna(False).sum()),
                'delta24_q95_exceed_hours':int(w['rise_24h_q95'].fillna(False).sum()),
                'max_score':float(w['score'].max()) if w['score'].notna().any() else None,
                'min_score':float(w['score'].min()) if w['score'].notna().any() else None})
    print('[3/5] 案例分析完成',flush=True)
    pd.DataFrame(rows).to_csv(out/'case_dynamic_summary.csv',index=False,encoding='utf-8-sig')
    pd.DataFrame(window_rows).to_csv(out/'case_dynamic_windows.csv',index=False,encoding='utf-8-sig')
    pd.concat(hour_rows,ignore_index=True).to_csv(out/'case_dynamic_hourly.csv',index=False,encoding='utf-8-sig')
    pd.DataFrame([{'feature':k,**v} for k,v in baseline.items()]).to_csv(out/'training_change_thresholds.csv',index=False,encoding='utf-8-sig')
    summary = {'stage':'6 / dynamic change and persistent alarm diagnosis',
       'source':str(src), 'frozen_Q2_alarm_threshold':THRESHOLD,
       'training_reference_period':'2021-04-01 to 2021-07-31 (inclusive)',
       'baseline':baseline, 'cases':rows,
       'cautions':[
         'Train-derived q95 is an exploratory score-change flag, not a calibrated debris-flow prediction threshold.',
         'An alarm that predates the inspected window cannot be assigned an exact first alert from that window.',
         'The event timestamps are approximate; 2025 event is a flood, not a mudslide label.',
         'This is a retrospective diagnostic replay using pre-event observations, not a prospective forecast test.',
         'Hour-level 95% trigger-time prediction interval and coverage remain unverified.'
       ]}
    (out/'stage6_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2,default=round_json),encoding='utf-8')
    (out/'README_results.txt').write_text('Stage6: risk score changes and persistent alarms.\n'
       'case_dynamic_summary.csv: each event last-known hour + alarm-run status.\n'
       'case_dynamic_windows.csv: 1/6/12/24/48/72 hour summary.\n'
       'case_dynamic_hourly.csv: hourly curve data (open in Excel).\n'
       'training_change_thresholds.csv: training-derived exploratory delta q95/q99.\n'
       'stage6_summary.json: audit summary and caveats.\n'
       'These are NOT proven trigger-time predictions or verified 95% intervals.\n',encoding='utf-8-sig')
    print('[4/5] 写入CSV/JSON',flush=True)
    for r in rows:
        print(f"  {r['case_id']}: score={r['last_score']}, alarm_run={r['alarm_run_hours_at_last_hour']}h, crossings={r['confirmed_crossings_history']}, delta6={r['last_delta_6h']}, delta24={r['last_delta_24h']}", flush=True)
    print('[5/5] 完成:',out,flush=True)

if __name__ == '__main__':
    main()
