# -*- coding: utf-8 -*-
"""第三问：基准时间区间对比（现有模型 / 均匀48h / 训练期历史窗口）。
放入 Q3 文件夹直接运行。依赖 pandas numpy；无 matplotlib/rasterio/pyproj。
历史基准只使用训练期、在发行时刻可用的事件日期标签估计未来第1天/第2天相对权重。
未来日期用于训练标签而非预测特征；测试期绝不用于拟合。
"""
from pathlib import Path
import argparse, json
import numpy as np
import pandas as pd

H=48

def load(path):
    for enc in ('utf-8-sig','gb18030','utf-8'):
        try: return pd.read_csv(path,encoding=enc,low_memory=False)
        except UnicodeDecodeError: pass
    raise ValueError('无法读取文件编码: '+str(path))

def overlap_hours(a,b,c,d):
    return max(0.0,(min(b,d)-max(a,c)).total_seconds()/3600)

def hours_interval(probs,alpha=.95):
    """固定等尾95%最小小时格区间；返回 [start_hour,end_hour)"""
    p=np.asarray(probs,dtype=float);p=p/p.sum(); cum=np.r_[0,np.cumsum(p)]
    left=int(np.searchsorted(cum, (1-alpha)/2, side='right')-1)
    right=int(np.searchsorted(cum, 1-(1-alpha)/2, side='left'))
    left=max(0,min(H-1,left));right=max(left+1,min(H,right))
    return left,right

def shortest(probs,alpha=.95):
    p=np.asarray(probs,dtype=float);p=p/p.sum(); cum=np.r_[0,np.cumsum(p)]
    choices=[]
    for a in range(H):
        b=int(np.searchsorted(cum,cum[a]+alpha-1e-12,side='left'))
        if b<=H and b>a: choices.append((b-a,a,b))
    _,a,b=min(choices)
    return a,b

def classify(issue,event,st,en):
    d0=event;d1=event+pd.Timedelta(days=1)
    a=issue+pd.Timedelta(hours=st);b=issue+pd.Timedelta(hours=en)
    o=overlap_hours(d0,d1,a,b)
    kind='full' if o>=24-1e-8 else ('none' if o<=1e-8 else 'partial')
    return kind,o,o/24, a,b

def baseline_train_distribution(forecasts, dates):
    """训练窗口含事件时，分配到前24小时/后24小时的天数频率；
    同一事件可落入两个训练发行窗口，因此仅作探索性的发行窗口条件分布。
    +1拉普拉斯平滑；缺失小时按日期内均匀分配。
    """
    f=forecasts[forecasts.split.eq('train')].copy()
    days=sorted(set(dates))
    counts=np.ones(2,dtype=float)
    windows=0
    for issue in f.issue_time:
        found=False
        for d in days:
            if d < issue or d>=issue+pd.Timedelta(hours=48):continue
            found=True
            counts[0]+=overlap_hours(d,d+pd.Timedelta(days=1),issue,issue+pd.Timedelta(hours=24))/24
            counts[1]+=overlap_hours(d,d+pd.Timedelta(days=1),issue+pd.Timedelta(hours=24),issue+pd.Timedelta(hours=48))/24
        if found: windows+=1
    p=np.r_[np.repeat(counts[0]/counts.sum()/24,24),np.repeat(counts[1]/counts.sum()/24,24)]
    return p, counts, windows

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--root',default=str(Path(__file__).resolve().parent))
    a=ap.parse_args();root=Path(a.root)
    out=root/'Q3_interval_baseline_comparison_results';out.mkdir(parents=True,exist_ok=True)
    fpath=root/'Q3_final_validation_results'/'issued_forecasts.csv'
    epath=root/'Q3_stage1_results'/'event_date_audit.csv'
    if not fpath.exists() or not epath.exists():
        raise FileNotFoundError('必须存在 Q3_final_validation_results/issued_forecasts.csv 和 Q3_stage1_results/event_date_audit.csv')
    f=load(fpath); e=load(epath)
    cols={'split','issue_time','ci95_conditional_start','ci95_conditional_end_exclusive'}
    if not cols.issubset(f.columns) or 'event_date' not in e:
        raise ValueError('CSV字段不符合现有第八阶段之后的文件格式')
    for c in ['issue_time','ci95_conditional_start','ci95_conditional_end_exclusive']:
        f[c]=pd.to_datetime(f[c],errors='coerce')
    f=f.dropna(subset=['issue_time']).sort_values('issue_time')
    f['split']=f['split'].astype(str).str.lower().str.strip()
    e['event_date']=pd.to_datetime(e.event_date,errors='coerce').dt.normalize()
    dates=sorted(set(e.event_date.dropna()))
    p_hist,counts,nwin=baseline_train_distribution(f,dates)
    p_uni=np.ones(H)/H
    methods={'uniform_48h':p_uni,'train_day_bin':p_hist}
    intervals={m:hours_interval(p) for m,p in methods.items()}
    distributions=pd.DataFrame({'hour_after_issue':np.arange(H),'uniform_48h':p_uni,'train_day_bin':p_hist})
    distributions.to_csv(out/'baseline_hour_probabilities.csv',index=False,encoding='utf-8-sig')
    rows=[]
    for d in dates:
        issue=d-pd.Timedelta(days=1)
        rr=f[f.issue_time.eq(issue)]
        if rr.empty:continue
        r=rr.iloc[0]
        # 训练和测试分组必须包含事件日，避免边界跨组造成假阳性
        bounds=f[f.split.eq(r['split'])].issue_time
        if bounds.empty or not(bounds.min().normalize()<=d<=bounds.max().normalize()):continue
        for method in ['q2_original','uniform_48h','train_day_bin']:
            if method=='q2_original':
                start=r['ci95_conditional_start'];end=r['ci95_conditional_end_exclusive']
                if pd.isna(start) or pd.isna(end):continue
                sh=(start-issue).total_seconds()/3600;eh=(end-issue).total_seconds()/3600
            else:sh,eh=intervals[method]
            kind,o,w,aa,bb=classify(issue,d,sh,eh)
            rows.append({'split':r['split'],'event_date':str(d.date()),'issue_time':str(issue),
                'method':method,'interval_start':str(aa),'interval_end_exclusive':str(bb),
                'width_h':round(eh-sh,6),'status':kind,'overlap_h':round(o,6),
                'uniform_day_fuzzy_weight':round(w,8),
                'cover_lower':int(kind=='full'),'cover_upper':int(kind!='none')})
    detail=pd.DataFrame(rows)
    if detail.empty:raise RuntimeError('没有可评价事件：检查CSV日期是否与预报发行时间对应')
    detail.to_csv(out/'event_level_method_comparison.csv',index=False,encoding='utf-8-sig')
    summ=[]
    for (split,method),g in detail.groupby(['split','method']):
        summ.append({'split':split,'method':method,'n_event_dates':len(g),
          'full':int((g.status=='full').sum()),'partial':int((g.status=='partial').sum()),
          'none':int((g.status=='none').sum()),'coverage_lower':g.cover_lower.mean(),
          'coverage_upper':g.cover_upper.mean(),
          'uniform_day_fuzzy':g.uniform_day_fuzzy_weight.mean(),
          'mean_width_hours':g.width_h.mean()})
    s=pd.DataFrame(summ).sort_values(['split','method'])
    s.to_csv(out/'comparison_summary.csv',index=False,encoding='utf-8-sig')
    # 2026年案例只做独立展示，绝不用于挑选模型。
    issue=pd.Timestamp('2026-08-25 10:00');ref=pd.Timestamp('2026-08-26 10:52')
    cases=[]
    original=(pd.Timestamp('2026-08-25 11:00'),pd.Timestamp('2026-08-27 09:00'))
    for method in ['q2_original','uniform_48h','train_day_bin']:
        aa,bb=original if method=='q2_original' else (issue+pd.Timedelta(hours=intervals[method][0]),issue+pd.Timedelta(hours=intervals[method][1]))
        cases.append({'method':method,'issue_time':str(issue),'interval_start':str(aa),
            'interval_end_exclusive':str(bb),'width_h':(bb-aa).total_seconds()/3600,
            'reference_onset':str(ref),'reference_inside':bool(aa<=ref<bb)})
    pd.DataFrame(cases).to_csv(out/'case_2026_comparison.csv',index=False,encoding='utf-8-sig')
    meta={'historical_train_day_bin_counts_with_laplace_1':counts.tolist(),
          'train_positive_issue_windows_count':nwin,
          'baseline_intervals_hours_from_issue':{k:list(map(int,v)) for k,v in intervals.items()},
          'notes':['同一天仅取事件前一天00:00发行的预测，杜绝重叠预测多次计数。',
                   '历史基准的未来第1天/第2天权重根据训练期发行窗口及有记录事件日期估计，小时内一律均匀；同一历史事件可能在多个训练发行窗口出现，此基准是探索性而非独立事件模型。',
                   '所有95%区间均条件于预测时域内有事件；均匀模糊分数是假设，不是实测覆盖率。',
                   '原Q2模型区间宽度接近48小时；若三种方法都类似，说明未有小时定位增益。',
                   '仅事件日期不够比较无事件窗口的真正时间预测校准；严禁按2026年事件调整模型。']}
    (out/'method_notes.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding='utf-8')
    print('[完成] 基准对比输出:',out)
    print('训练期历史基准两天计数(含平滑):',counts.round(4).tolist(),'分布按小时展开')
    print(s.to_string(index=False,float_format=lambda x:f'{x:.4f}'))
    print('\n2026案例（仅展示，不用于调参）:')
    print(pd.DataFrame(cases)[['method','width_h','reference_inside']].to_string(index=False))
    print('提醒：模糊覆盖率不是实际95%小时覆盖率；本比较不等于模型通过独立校准。')

if __name__=='__main__':main()
