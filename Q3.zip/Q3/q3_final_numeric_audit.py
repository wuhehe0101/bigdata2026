# -*- coding: utf-8 -*-
"""第三问最终数值核定：不重训、不调参；只读取已有结果。放到 Q3 文件夹直接运行。
可指定 --root D:\\...\\Q3 ；不使用matplotlib/rasterio/pyproj。
"""
from pathlib import Path
import argparse,json
import pandas as pd

def pick(root, candidates):
    for s in candidates:
        p=root/s
        if p.exists():return p
    raise FileNotFoundError('未找到必要文件（任选其中一个路径）:\n'+'\n'.join(map(str,candidates)))

def main():
    pa=argparse.ArgumentParser()
    pa.add_argument('--root',default=str(Path(__file__).resolve().parent))
    args=pa.parse_args();r=Path(args.root)
    issued=pd.read_csv(pick(r,['Q3_final_validation_results/issued_forecasts.csv']),parse_dates=['issue_time','ci95_conditional_start','ci95_conditional_end_exclusive'])
    event=pd.read_csv(pick(r,['Q3_final_validation_results/test_distinct_event_audit.csv']),parse_dates=['event_date','earliest_prior_warning'])
    case=pd.read_csv(pick(r,['Q3_time_improvement_results/2026_case_horizon_comparison.csv','Q3_prospective_results/case_fixed_issue_48h_forecasts.csv']))
    spatial=pd.read_csv(pick(r,['Q3_stage4_results/spatial_path_audit.csv','Q3_stage4_validation/spatial_path_audit.csv','Q3_stage4_fixed_test/spatial_path_audit.csv','Q3_stage4_v2_smoke/spatial_path_audit.csv']))
    glacier=pd.read_csv(pick(r,['Q3_stage7_results/source_neighborhood_audit.csv','Q3_stage7_test/source_neighborhood_audit.csv']))
    out=r/'Q3_final_numeric_audit_results';out.mkdir(exist_ok=True)
    te=issued[issued.split=='test'].sort_values('issue_time').copy();te['warning']=te.warning.astype(str).str.lower().eq('true')
    # Treat consecutive daily warning issues as one episode, not repeated new alarms.
    alarms=te[te.warning].copy(); prev=None; episode_id=0; startmap={}; episodes=[]
    for _,z in alarms.iterrows():
        t=z.issue_time
        if prev is None or (t-prev)!=pd.Timedelta(days=1):
            episode_id+=1;episodes.append({'episode_id':episode_id,'first_issue_time':t,'last_issue_time':t,'number_of_issues':1})
        else:
            episodes[-1]['last_issue_time']=t;episodes[-1]['number_of_issues']+=1
        startmap[t]=episodes[-1]['first_issue_time'];prev=t
    rows=[]
    for _,v in event.iterrows():
        d=v.event_date;start=d;stop=d+pd.Timedelta(days=1)
        pre=te[(te.warning)&(te.issue_time<d)&(te.issue_time+pd.Timedelta(hours=48)>d)].copy()
        if len(pre):
            first_issue=pre.issue_time.min(); episode_start=startmap[first_issue]
            # 48h earliest eligible issue may occur DURING an already active warning episode.
            valid_lead_from_issue=(d-first_issue).total_seconds()/3600
            lead_episode=(d-episode_start).total_seconds()/3600
            rows.append(dict(event_date=str(d.date()),any_prior_warning=True,earliest_qualifying_48h_issue=str(first_issue),
                 qualifying_issue_lead_hours_lower=valid_lead_from_issue,qualifying_issue_lead_hours_upper_exclusive=valid_lead_from_issue+24,
                 ongoing_episode_first_issue=str(episode_start),episode_initial_alarm_lead_lower_h=lead_episode,
                 episode_initial_alarm_lead_upper_exclusive_h=lead_episode+24,
                 episode_start_is_within_48h_horizon=bool(episode_start+pd.Timedelta(hours=48)>d),
                 note='episode_start是持续报警的起点，不代表这一条48h发布预测窗口覆盖事件' ))
        else:
            rows.append(dict(event_date=str(d.date()),any_prior_warning=False,earliest_qualifying_48h_issue='',
                qualifying_issue_lead_hours_lower=None,qualifying_issue_lead_hours_upper_exclusive=None,
                ongoing_episode_first_issue='',episode_initial_alarm_lead_lower_h=None,episode_initial_alarm_lead_upper_exclusive_h=None,
                episode_start_is_within_48h_horizon=False,note='无符合48h窗口条件的事前报警'))
    ev_out=pd.DataFrame(rows);ev_out.to_csv(out/'event_lead_time_final.csv',index=False,encoding='utf-8-sig')
    ep_out=pd.DataFrame(episodes);ep_out.to_csv(out/'warning_episodes_final.csv',index=False,encoding='utf-8-sig')
    if 'horizon_h' in case.columns:c=case[case.horizon_h==48].iloc[0];case_res=dict(issue_time=str(c.issue_time),reference_onset=str(c.reference_collapse_onset),conditional_event_prob=float(c.p_event),interval_start=str(c.eq_start),interval_end_exclusive=str(c.eq_end_exclusive),reference_covered=bool(c.eq_contains_reference))
    else:
        c=case[case.case_id.astype(str).str.contains('20260826')].iloc[0];case_res=dict(issue_time=str(c.issue_time),reference_onset=str(c.event_reference_time),conditional_event_prob=float(c.forecast_event_probability_48h),interval_start=str(c.conditional_interval_start),interval_end_exclusive=str(c.conditional_interval_end_exclusive),reference_covered=bool(c.reference_inside_conditional_interval))
    case_res['issue_to_reference_hours']=(pd.Timestamp(case_res['reference_onset'])-pd.Timestamp(case_res['issue_time'])).total_seconds()/3600
    sp=spatial[spatial.threshold==1000].copy();sp_out=sp[['source','length_m','min_distance_to_port_m','end_reason']].copy();sp_out['length_km']=sp_out.length_m/1000;sp_out.to_csv(out/'candidate_spatial_distances.csv',index=False,encoding='utf-8-sig')
    glacier.to_csv(out/'source_region_static_screen.csv',index=False,encoding='utf-8-sig')
    summary=dict(test_event_dates=len(ev_out),event_dates_with_eligible_prior_warning=int(ev_out.any_prior_warning.sum()),
        n_daily_warning_episodes=len(ep_out),max_contiguous_warning_issue_days=int(ep_out.number_of_issues.max()),
        case_2026=case_res,spatial_candidates=sp_out.to_dict(orient='records'),
        limitations=['事件实际发生小时未知，提前量为日期引起的区间，不是精确值',
        '预警连续状态起点不等于每条48h预测的有效预警提前量',
        '候选D8路径以栅格无数据边界终止，路径长度不是实测泥石流运移距离',
        '2026参考时刻是冰岩崩塌起始而非核实的泥石流触发时刻',
        '名义95%条件区间的真实覆盖率未得到验证，且预测区间依赖风险持续假设'])
    (out/'numeric_audit_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
    print('[完成] 最终数值核定:',out)
    print('\n测试事件日提前量（小时，左闭右开）:')
    print(ev_out[['event_date','any_prior_warning','earliest_qualifying_48h_issue','qualifying_issue_lead_hours_lower','qualifying_issue_lead_hours_upper_exclusive','ongoing_episode_first_issue']].to_string(index=False))
    print('\n持续报警片段:')
    print(ep_out.to_string(index=False))
    print('\n2026案例:',case_res)
    print('\n空间候选:');print(sp_out.to_string(index=False))
    print('提醒：不存在经过验证的小时级95%实际覆盖率。')
if __name__=='__main__':main()
