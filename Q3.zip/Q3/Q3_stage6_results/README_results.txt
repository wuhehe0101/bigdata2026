﻿Stage6: risk score changes and persistent alarms.
case_dynamic_summary.csv: each event last-known hour + alarm-run status.
case_dynamic_windows.csv: 1/6/12/24/48/72 hour summary.
case_dynamic_hourly.csv: hourly curve data (open in Excel).
training_change_thresholds.csv: training-derived exploratory delta q95/q99.
stage6_summary.json: audit summary and caveats.
These are NOT proven trigger-time predictions or verified 95% intervals.
