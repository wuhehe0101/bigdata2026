# -*- coding: utf-8 -*-
"""第三问：在无小时级灾害标签下，诚实比较预报时域和条件时间区间。
放在 Q3 目录运行，读取 Q3_stage1_results 与 Q3_stage2_results。
不使用未来气象观测、不按2026案例选参；无绘图库依赖。
"""
from pathlib import Path
import argparse,json
import numpy as np
import pandas as pd
B0=-2.070474371019093
B1=0.4419896098872232
HORIZONS=(24,36,48)
TARGET_BG=0.35
CASE_ISSUE=pd.Timestamp('2026-08-25 10:00')
CASE_ONSET=pd.Timestamp('2026-08-26 10:52') # 冰岩崩塌参考，不是泥石流精确触发

def compute(score,horizon):
    s=np.clip(float(score),1e-10,1-1e-10)
    p24=1/(1+np.exp(-np.clip(B0+B1*np.log(s/(1-s)),-30,30)))
    hazard=-np.expm1(np.log1p(-p24)/24)
    hours=np.arange(horizon)
    probs=hazard*(1-hazard)**hours
    p_event=float(probs.sum())
    cond=probs/p_event
    cum=np.cumsum(cond)
    # Equal-tailed quantile interval of hour BINS, with half-open endpoint
    eql=int(np.searchsorted(cum,.025))
    equ=int(np.searchsorted(cum,.975))
    # Deterministic minimum-width contiguous interval, sum >=95%, tie-break earliest
    best=None
    for i in range(horizon):
        for j in range(i,horizon):
            if cond[i:j+1].sum()>=.95-1e-12:
                cand=(j-i+1,i,j)
                if best is None or cand<best:best=cand
                break
    _,short_l,short_u=best
    return dict(p24=float(p24),p_event=p_event,eq_l=eql,eq_u=equ+1,
                shortest_l=short_l,shortest_u=short_u+1,
                eq_width_h=equ-eql+1,shortest_width_h=short_u-short_l+1)

def coverage(a,b,day):
    end=day+pd.Timedelta(days=1)
    if a<=day and b>=end:return 'certain_covered'
    if b<=day or a>=end:return 'certain_not_covered'
    return 'unknown_partial_overlap'

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--root',default=str(Path(__file__).resolve().parent))
    args=ap.parse_args();root=Path(args.root)
    s1=root/'Q3_stage1_results';s2=root/'Q3_stage2_results';out=root/'Q3_time_improvement_results'
    out.mkdir(parents=True,exist_ok=True)
    files=[s1/'hourly_q2_score.csv',s1/'test_daily_scores.csv',s1/'event_date_audit.csv',s2/'train_daily_calibration.csv']
    for f in files:
        if not f.exists():raise FileNotFoundError('缺少输入：'+str(f))
    hourly=pd.read_csv(files[0],parse_dates=['Timestamp']).set_index('Timestamp').sort_index()
    test=pd.read_csv(files[1]);train=pd.read_csv(files[3]); ev=pd.read_csv(files[2])
    dates={pd.Timestamp(x).normalize() for x in ev['event_date'].dropna()}
    forecast_rows=[]; case_rows=[]; audits=[]; summaries=[]
    for H in HORIZONS:
        frames={}
        for split,frame in [('train',train),('test',test)]:
            rows=[]
            for _,r in frame.iterrows():
                issue=pd.Timestamp(r['date']).normalize()
                if issue not in hourly.index or pd.isna(hourly.at[issue,'score']):continue
                c=compute(hourly.at[issue,'score'],H)
                # only event dates whose DAY intersects forecast horizon; label is date-level proxy
                matches=sorted(d for d in dates if d<issue+pd.Timedelta(hours=H) and d+pd.Timedelta(days=1)>issue)
                rows.append(dict(split=split,horizon_h=H,issue=issue,score=float(hourly.at[issue,'score']),
                     event_dates=';'.join(str(x.date()) for x in matches),positive=int(bool(matches)),**c))
            frames[split]=pd.DataFrame(rows)
        tr,te=frames['train'],frames['test']
        if tr.empty or te.empty:continue
        # training-only: max recorded-event-window recall subject to <=35% background window alarm
        candidates=[]
        for threshold in np.unique(np.r_[tr.p_event.values,tr.p_event.max()+1e-9]):
            hit=tr.p_event>=threshold;pos=tr.positive==1;neg=~pos
            bg=float(hit[neg].mean()) if neg.any() else np.nan
            recall=float(hit[pos].mean()) if pos.any() else np.nan
            candidates.append((float(threshold),recall,bg))
        good=[x for x in candidates if x[2]<=TARGET_BG+1e-12]
        pool=good if good else candidates
        threshold=sorted(pool,key=lambda x:(-x[1],x[2],-x[0]))[0][0]
        for frame in (tr,te):
            frame['warning']=frame.p_event>=threshold
            for method in ('eq','shortest'):
                frame[f'{method}_start']=frame.issue+pd.to_timedelta(frame[f'{method}_l'],unit='h')
                frame[f'{method}_end_exclusive']=frame.issue+pd.to_timedelta(frame[f'{method}_u'],unit='h')
        for frame in (tr,te):
            forecast_rows.extend(frame.to_dict('records'))
        pos=te.positive==1; neg=~pos; w=te.warning
        # test incident dates; do not double-count overlapping forecasts
        testdays={pd.Timestamp(v).normalize() for v in test.date}
        incident=sorted(d for d in dates if d in testdays)
        event_hit=[]
        for d in incident:
            # Only issue before event DATE, and forecast horizon intersects its day
            possible=te[(te.issue<d)&(te.issue+pd.Timedelta(hours=H)>d)&(te.warning)]
            event_hit.append(bool(len(possible)))
            if len(possible):
                earliest=possible.issue.min();lead=(d-earliest).total_seconds()/3600
            else:earliest=pd.NaT;lead=np.nan
            audits.append(dict(kind='event_warning',horizon_h=H,event_date=str(d.date()),
                               any_pre_date_warning=bool(len(possible)),first_pre_date_issue=str(earliest) if pd.notna(earliest) else '',
                               lead_min_h=lead if np.isfinite(lead) else None,
                               lead_max_exclusive_h=lead+24 if np.isfinite(lead) else None))
        for _,r in te.iterrows():
            if not r.event_dates:continue
            for event in r.event_dates.split(';'):
                day=pd.Timestamp(event)
                for method in ('eq','shortest'):
                    status=coverage(r[f'{method}_start'],r[f'{method}_end_exclusive'],day)
                    audits.append(dict(kind='interval_date',horizon_h=H,issue=str(r.issue),
                                       event_date=event,method=method,status=status,
                                       warning=bool(r.warning)))
        casescore=float(hourly.at[CASE_ISSUE,'score']);case=compute(casescore,H)
        casedict=dict(horizon_h=H,issue_time=str(CASE_ISSUE),reference_collapse_onset=str(CASE_ONSET),
                      q2_score_at_issue=casescore,**case)
        for method in ('eq','shortest'):
            start=CASE_ISSUE+pd.Timedelta(hours=case[f'{method}_l'])
            end=CASE_ISSUE+pd.Timedelta(hours=case[f'{method}_u'])
            casedict[f'{method}_start']=str(start);casedict[f'{method}_end_exclusive']=str(end)
            casedict[f'{method}_contains_reference']=bool(start<=CASE_ONSET<end)
        case_rows.append(casedict)
        summaries.append(dict(horizon_h=H,train_only_warning_threshold=float(threshold),
           test_windows=len(te),test_positive_windows=int(pos.sum()),test_hit_windows=int((pos&w).sum()),
           test_window_recall=float(w[pos].mean()) if pos.any() else None,
           test_background_alarm_fraction=float(w[neg].mean()) if neg.any() else None,
           distinct_recorded_test_event_days=len(incident),event_days_with_prior_warning=sum(event_hit),
           mean_equal_tail_width_test_h=float(te.eq_width_h.mean()),
           mean_shortest_width_test_h=float(te.shortest_width_h.mean()),
           case_48h_reference_in_horizon=bool(CASE_ISSUE<=CASE_ONSET<CASE_ISSUE+pd.Timedelta(hours=H))))
    pd.DataFrame(forecast_rows).to_csv(out/'all_issued_forecasts.csv',index=False,encoding='utf-8-sig')
    pd.DataFrame(audits).to_csv(out/'event_and_interval_audit.csv',index=False,encoding='utf-8-sig')
    pd.DataFrame(case_rows).to_csv(out/'2026_case_horizon_comparison.csv',index=False,encoding='utf-8-sig')
    pd.DataFrame(summaries).to_csv(out/'horizon_warning_comparison.csv',index=False,encoding='utf-8-sig')
    result=dict(warning_metrics=summaries,case_results=case_rows,
       limitations=[
           '24h/36h/48h具有不同预测目标，不能用较短时域的较短区间宣称在48h预报目标下精度提高。',
           '最短95%区间是基于同一个未验证的风险持续-常数危险率条件分布，95%仅是模型内概率质量，不是经验覆盖保证。',
           '固定发布时刻后不使用未来观测；历史灾害仅有日期时，小时级时间区间覆盖仍不能精确判定。',
           '事件日期记录可能不完整，背景窗口报警比例不是真实误报率。',
           '2026年冰崩起始参考时刻不是泥石流确切触发时刻，不能用于训练选择方案。',
           '小时步长下区间端点为左闭右开；最短区间允许在模型分布假设下非等尾。'])
    (out/'comparison_summary.json').write_text(json.dumps(result,ensure_ascii=False,indent=2,default=str),encoding='utf-8')
    print('[完成] 48小时/36小时/24小时预警比较')
    for x in summaries:print('时域',x['horizon_h'],'小时 | 训练阈值',round(x['train_only_warning_threshold'],6),
          '| 测试窗口召回率',round(x['test_window_recall'],4),
          '| 背景窗口报警比例',round(x['test_background_alarm_fraction'],4),
          '| 测试事件日事前报警',f"{x['event_days_with_prior_warning']}/{x['distinct_recorded_test_event_days']}")
    for r in case_rows:
        print('2026案例',r['horizon_h'],'h | 条件事件概率',round(r['p_event'],5),
              '| 等尾区间',r['eq_start'],'至',r['eq_end_exclusive'],
              '| 最短区间',r['shortest_start'],'至',r['shortest_end_exclusive'],
              '| 参考时刻被覆盖',r['shortest_contains_reference'])
    print('输出文件夹:',out)
    print('警告：无法由这些数据验证真实95%小时级覆盖率；勿按2026事件事后选方案。')
if __name__=='__main__':main()
