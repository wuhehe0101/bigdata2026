# -*- coding: utf-8 -*-
"""MathorCup Q3 / Stage 1: data and time-label audit.
Run: python q3_stage1_audit.py --weather clead.csv --events 吉隆县历史灾害_干净版.csv
All output filenames use ASCII to avoid Windows ZIP mojibake.
"""
from pathlib import Path
import argparse
import json
import numpy as np
import pandas as pd
from sklearn.metrics import roc_auc_score, average_precision_score, confusion_matrix

# Frozen Q2.0 model (train on daily 00:00 samples); never refit on test data.
B0 = -0.2777418424
B = np.array([0.1998220392, 0.7153120356])
MU = np.array([4.7901234568, 31.3607664609])
SD = np.array([7.8600663607, 7.1384357546])
THRESHOLD = 0.5193085227
TRAIN_BEGIN, TRAIN_END = '2021-04-01', '2021-07-31'
TEST_BEGIN, TEST_END = '2021-08-16', '2021-09-30'

def find_input(value, alternatives):
    """先尝试显式路径，再依次查找脚本目录、上一级目录和当前工作目录。"""
    script_dir = Path(__file__).resolve().parent
    dirs = [script_dir, script_dir.parent, Path.cwd()]
    requested = Path(value).expanduser()
    candidates = ([requested] if requested.is_absolute() else
                  [requested] + [d / requested for d in dirs])
    for name in alternatives:
        candidates.extend(d / name for d in dirs)
    seen = set()
    for candidate in candidates:
        key = str(candidate.resolve())
        if key not in seen:
            seen.add(key)
            if candidate.is_file():
                print(f'读取文件：{candidate.resolve()}')
                return candidate.resolve()
    searched = '\n'.join('  ' + str(c) for c in candidates)
    raise FileNotFoundError(
        f'找不到数据文件 {value}。\n已尝试以下路径：\n{searched}\n'
        '请把CSV放到脚本同目录或其上一级目录，或运行时用 --weather/--events 指定绝对路径。'
    )


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--weather', default='clead.csv')
    p.add_argument('--events', default='吉隆县历史灾害_干净版(1).csv')
    p.add_argument('--out', default=None, help='默认保存到脚本所在文件夹/Q3_stage1_results')
    p.add_argument('--lookback-hours', type=int, default=72)
    a = p.parse_args()
    base = Path(__file__).resolve().parent
    out = Path(a.out).expanduser() if a.out else base / 'Q3_stage1_results'
    weather_path = find_input(a.weather, ['clead.csv'])
    events_path = find_input(a.events, [
        '吉隆县历史灾害_干净版.csv',
        '吉隆县历史灾害_干净版(1).csv',
    ])
    out.mkdir(parents=True, exist_ok=True)
    usecols = ['Timestamp', 'MET_Precip(mm)', 'MET_Ta_2m(degree C)']
    met = pd.read_csv(weather_path, usecols=usecols, low_memory=False)
    n_raw = len(met)
    met['Timestamp'] = pd.to_datetime(met['Timestamp'], errors='coerce')
    n_nat = int(met['Timestamp'].isna().sum())
    if n_nat:
        raise ValueError(f'气象 Timestamp 无法解析：{n_nat} 条；请先检查原始文件。')
    duplicate = int(met['Timestamp'].duplicated().sum())
    if duplicate:
        raise ValueError(f'气象时间戳重复：{duplicate} 条；不能静默取平均。')
    met = met.set_index('Timestamp').sort_index()
    original_hours = len(met)
    met = met.asfreq('h')
    missing_rows = len(met) - original_hours
    precip = pd.to_numeric(met[usecols[1]], errors='coerce')
    temp = pd.to_numeric(met[usecols[2]], errors='coerce')
    invalid_p = int((precip.notna() & ((precip < 0) | (precip >= 999))).sum())
    invalid_t = int((temp.notna() & ((temp <= -80) | (temp >= 60))).sum())
    precip = precip.where((precip >= 0) & (precip < 999))
    temp = temp.where((temp > -80) & (temp < 60))
    met['precip_qc'] = precip
    met['temp_qc'] = temp
    # Carry forward the Q2 assumption: Timestamp marks START of the hour;
    # risk at hour t only uses values strictly earlier than t (shift(1)).
    met['P72'] = precip.shift(1).rolling(72, min_periods=72).sum()
    met['D72'] = temp.clip(lower=0).shift(1).rolling(72, min_periods=72).sum() / 24
    eta = B0 + B[0] * (met['P72']-MU[0]) / SD[0] + B[1] * (met['D72']-MU[1]) / SD[1]
    met['score'] = 1 / (1 + np.exp(-np.clip(eta, -700, 700)))
    met['alarm'] = (met['score'] >= THRESHOLD).astype('boolean')
    met.loc[met['score'].isna(), 'alarm'] = pd.NA
    met.index.name = 'Timestamp'

    event = pd.read_csv(events_path, encoding='utf-8-sig')
    if '发生日期' not in event.columns:
        raise ValueError('历史灾害文件缺少“发生日期”列。')
    event['event_date'] = pd.to_datetime(event['发生日期'], errors='coerce').dt.normalize()
    if event['event_date'].isna().any():
        raise ValueError('发现无法解析的灾害发生日期，请先核实原始记录。')
    dates = sorted(event['event_date'].unique())
    summary_rows = []
    for day in dates:
        day = pd.Timestamp(day)
        left, right = day, day + pd.Timedelta(days=1)
        past = met.loc[(met.index >= left - pd.Timedelta(hours=a.lookback_hours)) & (met.index < left)]
        same_day = met.loc[(met.index >= left) & (met.index < right)]
        before_alarm = past.index[past['alarm'].fillna(False).astype(bool)]
        at_midnight = met.loc[left] if left in met.index else None
        first = before_alarm.min() if len(before_alarm) else pd.NaT
        summary_rows.append({
            'event_date': day.date().isoformat(),
            'records_on_day': int((event['event_date'] == day).sum()),
            'label_left_inclusive': str(left), 'label_right_exclusive': str(right),
            'weather_available_that_day_hours': int(same_day['temp_qc'].notna().sum()),
            'midnight_score_available': bool(at_midnight is not None and pd.notna(at_midnight['score'])),
            'midnight_score': float(at_midnight['score']) if at_midnight is not None and pd.notna(at_midnight['score']) else np.nan,
            'valid_pre_event_day_score_hours': int(past['score'].notna().sum()),
            'any_alarm_prior_to_event_day': bool(len(before_alarm)),
            'first_alarm_within_lookback': str(first) if pd.notna(first) else '',
            'possible_lead_min_hours': round((left-first).total_seconds()/3600,2) if pd.notna(first) else np.nan,
            'possible_lead_max_exclusive_hours': round((right-first).total_seconds()/3600,2) if pd.notna(first) else np.nan,
            'event_hour_verified': False,
            'event_date_source_verified': False,
            'note': '日期含义尚未由原始出处复核；提前量仅在报警对应此事件且日期为真实发生日期时成立。'
        })
    event_audit = pd.DataFrame(summary_rows)
    event_audit.to_csv(out/'event_date_audit.csv', index=False, encoding='utf-8-sig')
    daily = met.loc[met.index.hour == 0, ['P72','D72','score','alarm']].copy()
    daily.index = daily.index.normalize()
    daily.index.name = 'date'
    daily['event_label'] = daily.index.isin(dates).astype(int)
    daily.to_csv(out/'daily_score_and_labels.csv', encoding='utf-8-sig')
    met[['precip_qc','temp_qc','P72','D72','score','alarm']].to_csv(out/'hourly_q2_score.csv', encoding='utf-8-sig')
    test = daily.loc[TEST_BEGIN:TEST_END].dropna(subset=['P72','D72','score']).copy()
    test.to_csv(out/'test_daily_scores.csv', encoding='utf-8-sig')
    y = test['event_label'].to_numpy(dtype=int)
    yh = test['alarm'].to_numpy(dtype=int)
    tn, fp, fn, tp = confusion_matrix(y, yh, labels=[0,1]).ravel()
    metrics = {
       'n': len(test), 'event_days': int(y.sum()), 'tn':int(tn),'fp':int(fp),'fn':int(fn),'tp':int(tp),
       'auc':float(roc_auc_score(y,test['score'])) if len(set(y)) == 2 else None,
       'ap':float(average_precision_score(y,test['score'])) if y.sum() else None,
       'event_recall':float(tp/(tp+fn)) if tp+fn else None,
       'background_alarm_fraction':float(fp/(fp+tn)) if fp+tn else None
    }
    summary = {
       'weather_records_original':n_raw,'hour_grid_rows':len(met),'missing_timestamp_rows':missing_rows,
       'invalid_precip_observations':invalid_p,'invalid_temperature_observations':invalid_t,
       'precip_missing_after_qc':int(precip.isna().sum()),'temp_missing_after_qc':int(temp.isna().sum()),
       'first_weather_hour':str(met.index.min()),'last_weather_hour':str(met.index.max()),
       'complete_hourly_score_hours':int(met['score'].notna().sum()),
       'event_records':len(event),'distinct_event_dates':len(dates),
       'event_days_with_complete_midnight_score':int(event_audit['midnight_score_available'].sum()),
       'train_daily_complete_n':int(daily.loc[TRAIN_BEGIN:TRAIN_END]['score'].notna().sum()),
       'test_daily_metrics':metrics,
       'interpretation': '小时评分是冻结的日级模型在逐小时上的探索性应用，非已校准小时触发危险率。',
       'time_label_caution':'事件仅有日期，所有发生小时未知；无记录日期未核实为无灾日期。',
       'timestamp_caution':'沿用第二问shift(1)，假设Timestamp为小时开始；须核对气象资料元数据。',
       'next_stage':'必须核实事件日期来源和完整监测区间，再判断能否建立区间删失生存模型；不能凭这些数据承诺95%小时级覆盖率。'
    }
    (out/'stage1_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
    (out/'README_results.txt').write_text(
        'Q3 第一阶段：数据与时间标签审计\n\n'
        'event_date_audit.csv：每个独立事件日的区间标签、缺失情况及事件日前报警。\n'
        'hourly_q2_score.csv：严格使用此前72小时气象数据计算的探索性小时评分。\n'
        'daily_score_and_labels.csv：与第二问一致的每天零时评分与记录事件标签。\n'
        'test_daily_scores.csv：固定时间测试期的日级验证数据。\n'
        'stage1_summary.json：缺失值、记录计数及测试指标。\n\n'
        '重要：以上不包含经证实的95%触发时间预测区间或覆盖率。\n'
        '对于只记录日期的事件，真实触发时间只能定位到该日期对应的24小时区间（前提是日期来源可靠）。\n',
        encoding='utf-8-sig')
    print(json.dumps(summary,ensure_ascii=False,indent=2))
    print('文件输出：',out.resolve())

if __name__ == '__main__':
    main()
