﻿Q3 Stage 5: case replay / 2026 ice collapse and 2025 flood.
case_replay_summary.csv: one row per case; alarms and bounds.
case_windows.csv: 1/6/12/24/48/72-hour windows.
case_hourly_before_events.csv: hourly score for 72 hours before each reference.
All scores are retrospective and do not constitute a validated 95% trigger-time prediction.
