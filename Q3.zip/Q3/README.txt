ZIP file names use English/ASCII to avoid Windows extractor encoding issues.
Main code: q3_integrated.py
Dependency: q3_time_core.py
Keep both .py files in same directory.
Run in the directory holding your original input files:
python q3_integrated.py --weather clead.csv --events "吉隆县历史灾害_干净版(1).csv" --dem "DEM(1).tif" --d8 "D8流向.tif" --acc "汇流累积_像元数.tif"
If input data are elsewhere, use full paths.
The result_ files are prior precomputed outputs (numbered to avoid filename encoding issues).
