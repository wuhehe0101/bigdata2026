# -*- coding: utf-8 -*-
"""MathorCup Q3 stage 8: integrate stage 1-7 without refitting models.
Place this script in Q3 next to Q3_stageN_results folders; run directly in PyCharm.
Requires pandas only. No matplotlib, rasterio or pyproj.
"""
from pathlib import Path
import argparse
import json
import sys
import pandas as pd

FOLDERS = {i: f'Q3_stage{i}_results' for i in range(1, 8)}
FILES = {
 1: ('stage1_summary.json', 'test_daily_scores.csv'),
 2: ('stage2_summary.json', 'test_interval_forecasts.csv'),
 3: ('stage3_summary.json', 'window_warning_summary.csv', 'test_warning_metrics.csv'),
 4: ('stage4_summary.json', 'spatial_path_audit.csv', 'threshold_sensitivity.csv'),
 5: ('stage5_summary.json', 'case_replay_summary.csv'),
 6: ('stage6_summary.json', 'case_dynamic_summary.csv', 'training_change_thresholds.csv'),
 7: ('stage7_summary.json', 'source_neighborhood_audit.csv'),
}

def read_json(p):
    with p.open(encoding='utf-8-sig') as f: return json.load(f)

def read_csv(p): return pd.read_csv(p, encoding='utf-8-sig')

def val(x):
    if pd.isna(x): return None
    if hasattr(x,'item'): return x.item()
    return x

def main():
    ap = argparse.ArgumentParser(description='Q3 Stage 8: integrate existing validated outputs')
    ap.add_argument('--root', default=str(Path(__file__).resolve().parent), help='Q3 folder')
    ap.add_argument('--out', default='', help='output folder; default root/Q3_stage8_results')
    a = ap.parse_args()
    root = Path(a.root).expanduser().resolve()
    out = Path(a.out).expanduser().resolve() if a.out else root/'Q3_stage8_results'
    print('[1/5] 检查各阶段文件', flush=True)
    missing = [str(root/FOLDERS[k]/f) for k,fs in FILES.items() for f in fs if not (root/FOLDERS[k]/f).is_file()]
    if missing:
        print('缺少以下必需文件（不会重新计算或编造结果）：', *missing, sep='\n  ', flush=True)
        raise SystemExit(2)
    data = {}
    for k,fs in FILES.items():
        data[k] = {f: read_json(root/FOLDERS[k]/f) if f.endswith('.json') else read_csv(root/FOLDERS[k]/f) for f in fs}
    s1 = data[1]['stage1_summary.json']; s2=data[2]['stage2_summary.json']; s3=data[3]['stage3_summary.json']
    s4=data[4]['stage4_summary.json']; s5=data[5]['stage5_summary.json']; s6=data[6]['stage6_summary.json']; s7=data[7]['stage7_summary.json']
    w = data[3]['window_warning_summary.csv']; bg=data[3]['test_warning_metrics.csv']
    paths=data[4]['spatial_path_audit.csv']; thresh=data[4]['threshold_sensitivity.csv']
    cases=data[5]['case_replay_summary.csv']; dynamics=data[6]['case_dynamic_summary.csv']
    gl=data[7]['source_neighborhood_audit.csv']
    print('[2/5] 跨阶段一致性检查',flush=True)
    issues=[]
    def check(ok,msg):
        if not ok: issues.append(msg)
    tm=s1['test_daily_metrics']; em=s2['test_exploratory_metrics']
    check(int(tm['n'])==int(s2['n_test_complete_days']),'第1、2阶段测试集日期数不一致')
    check(int(tm['event_days'])==int(s2['test_event_days']),'第1、2阶段事件日数量不一致')
    check(abs(float(tm['auc'])-float(em['auc']))<1e-8,'第1、2阶段AUC不一致')
    check(abs(float(s3['frozen_q2_threshold'])-0.5193085227)<1e-8,'第3阶段评分阈值与第二问2.0不一致')
    check(bool(s2.get('q2_frozen_model_unchanged')),'第2阶段没有确认冻结第二问模型')
    check(set(paths['source'].astype(str)) >= {'A','B'},'第四阶段缺少源区A或B')
    check(set(gl['source'].astype(str)) >= {'A','B'},'第七阶段缺少源区A或B')
    check(len(w)>=3,'第3阶段预警窗口记录不完整')
    check('ice_collapse_20260826' in set(cases['case_id']),'第五阶段缺少2026案例')
    check('ice_collapse_20260826' in set(dynamics['case_id']),'第六阶段缺少2026案例')
    if issues:
        print('发现跨阶段不一致：',*issues,sep='\n - ',flush=True)
        raise SystemExit('为避免论文引用错误，已停止整合。请核对各阶段结果文件。')
    print('[3/5] 汇总时间、空间与冰川结果',flush=True)
    rows=[]
    def add(section,metric,value,unit='',meaning='',status='observed_or_computed'):
        rows.append(dict(section=section,metric=metric,value=value,unit=unit,interpretation=meaning,evidence_status=status))
    add('Q2_daily','roc_auc',float(tm['auc']),'', '2021年46个完整测试日期，3个事件日；日期级排序能力')
    add('Q2_daily','event_day_recall',float(tm['event_recall']),'fraction','3个记录事件日识别2个')
    add('Q2_daily','background_day_alarm_fraction',float(tm['background_alarm_fraction']),'fraction','背景日未确认均为无灾日')
    add('Q2_daily','test_event_days',int(tm['event_days']),'days')
    add('Q3_time','hourly_95pct_coverage_verified',False,'','真实触发小时缺失；不能将名义95%当成经验覆盖率','not_identifiable')
    add('Q3_time','coverage_lower_bound',float(s3['interval_coverage']['certain_coverage_lower_bound']),'fraction','区间基于已知事件日构造，非前瞻性预测','not_informative')
    add('Q3_time','coverage_upper_bound',float(s3['interval_coverage']['possible_coverage_upper_bound']),'fraction','区间基于已知事件日构造，非前瞻性预测','not_informative')
    for _,r in w.sort_values('lookback_hours').iterrows():
        hours=int(r['lookback_hours']); b=bg.loc[bg['lookback_hours']==hours]
        add('Q3_warning',f'event_pre_day_alarm_{hours}h',float(r['event_day_pre_warning_fraction_all']),'fraction','事件日前回看窗口是否曾报警；并非精确触发时间预测')
        if not b.empty: add('Q3_warning',f'background_pre_day_alarm_{hours}h',float(b.iloc[0]['pre_alarm_background_fraction']),'fraction','无记录背景日中有报警的比例')
    for _,r in paths.loc[paths['threshold'].eq(1000)].sort_values('source').iterrows():
        src=str(r['source']);
        if str(r['status'])=='traced':
            add('Q3_spatial',f'source_{src}_candidate_path_length_km',float(r['length_m'])/1000,'km','D8栅格推算的候选线路全长；不是泥石流真实影响长度','terrain_candidate')
            add('Q3_spatial',f'source_{src}_nearest_port_m',float(r['min_distance_to_port_m']),'m','距口岸近似点最小距离','terrain_candidate')
            add('Q3_spatial',f'source_{src}_snap_distance_m',float(r['start_to_approx_source_m']),'m','源区坐标吸附到高汇流像元的距离','terrain_candidate')
    add('Q3_spatial','A_B_shared_pixels',int(s4['overlap_pixels_A_B_primary']),'cells','两条候选路径下游重合像元','terrain_candidate')
    for _,r in gl.sort_values('source').iterrows():
        src=str(r['source']);add('Q3_glacier',f'source_{src}_median_relative_score',float(r['nearby_score_median']),'relative','近似源区500米邻域静态冰川条件筛查；非冰崩概率','descriptive')
        add('Q3_glacier',f'source_{src}_glacier_pixels',int(r['nearby_glacier_pixels']),'cells','500米邻域可分析冰川像元','descriptive')
    add('Q3_glacier','common_valid_pixels',int(s7['common_valid_pixels']),'cells','NetCDF静态变量共同有效像元','descriptive')
    for _,r in cases.iterrows():
        cid=str(r['case_id']); add('Q3_case',f'{cid}_last_score',float(r['last_score']),'score','灾前已知气象评分回放；并非实时预测结果','retrospective')
        add('Q3_case',f'{cid}_new_crossings_72h',int(r['new_crossings_within_72']),'times','72小时窗口内评分新越阈次数','retrospective')
    for _,r in dynamics.iterrows():
        cid=str(r['case_id']); add('Q3_case',f'{cid}_alarm_run_observed_hours',int(r['alarm_run_hours_at_last_hour']),'hours','已观察到的连续报警时长；不是首次预警提前量','retrospective')
        for name in ('last_delta_6h','last_delta_24h'):
            add('Q3_case',f'{cid}_{name}',float(r[name]),'score_difference','灾前最近整点评分变化','retrospective')
    out.mkdir(parents=True,exist_ok=True)
    pd.DataFrame(rows).to_csv(out/'integrated_metrics.csv',index=False,encoding='utf-8-sig')
    # join two separate source-region assessments without implying causal linkage
    p=paths.loc[paths['threshold'].eq(1000),['source','status','length_m','min_distance_to_port_m','start_to_approx_source_m','end_reason']].copy()
    regions=p.merge(gl,how='outer',on='source',validate='one_to_one')
    regions.to_csv(out/'source_region_comparison.csv',index=False,encoding='utf-8-sig')
    thresh.to_csv(out/'spatial_threshold_sensitivity.csv',index=False,encoding='utf-8-sig')
    warning=w.merge(bg[['lookback_hours','pre_alarm_background_fraction']],on='lookback_hours',how='left',validate='one_to_one')
    warning.to_csv(out/'warning_window_comparison.csv',index=False,encoding='utf-8-sig')
    case_join=cases.merge(dynamics[['case_id','alarm_run_hours_at_last_hour','last_delta_6h','last_delta_24h']],on='case_id',how='left',validate='one_to_one')
    case_join.to_csv(out/'case_comparison.csv',index=False,encoding='utf-8-sig')
    evidence=pd.DataFrame([
      ('第二问模型日级AUC与召回率','可以报告','2021年固定回测；3个事件日、模型比较曾使用测试集'),
      ('事件日前24/48/72h报警比例','可以报告但须限定','事后检查的窗口内曾报警，并非准确的实时预警提前量'),
      ('2026冰崩事件前评分','可以报告但须限定','事件前已知数据的回放，持续报警不等于短临成功预测'),
      ('95%触发时间预测区间','未得到独立可靠验证','第二阶段区间以已知事件日期为条件，不是前瞻性预测'),
      ('95%区间实际覆盖率','不可识别','小时级真值缺失；已报告的0到1界限没有判别力'),
      ('D8候选通道长度','可以报告但须限定','不能当作泥石流真实传播长度、实际波及范围'),
      ('冰川静态相对评分','可以报告但须限定','没有2026年逐小时冰流加速度和冰崩标签'),
      ('口岸实际空间受灾范围','未从这些模型推定','需要实测灾害范围、动力学模拟和物理校验'),
    ],columns=['result','reportability','caution'])
    evidence.to_csv(out/'evidence_audit.csv',index=False,encoding='utf-8-sig')
    report={
      'stage':'8 / integrated evidence audit',
      'data_scope':'stage1-7 outputs; no model refitting or synthetic facts',
      'Q2_daily_test':tm,
      'warning_windows':warning.to_dict(orient='records'),
      'primary_paths':regions[['source','status','length_m','min_distance_to_port_m','end_reason','nearby_score_median']].to_dict(orient='records'),
      'case_replays':case_join.to_dict(orient='records'),
      'glacier_valid_pixels':int(s7['common_valid_pixels']),
      'hourly_95pct_coverage_verified':False,
      'time_interval_warning':'Stage 2 intervals condition on already-known event date; not prospective 95% trigger time prediction intervals.',
      'method_limitations':evidence.to_dict(orient='records')
    }
    (out/'stage8_summary.json').write_text(json.dumps(report,ensure_ascii=False,indent=2,default=str),encoding='utf-8')
    def getpath(s):return paths[(paths.source==s)&(paths.threshold==1000)].iloc[0]
    pa=getpath('A');pb=getpath('B')
    line=[
      '第三问 第八阶段：时空分析结果整合（仅汇总真实运行结果）','',
      f"日期级测试集：{tm['n']}个日期，其中{tm['event_days']}个记录事件日，AUC={tm['auc']:.4f}，事件召回率={tm['event_recall']:.2%}。",
      '该结果属于小样本、已有选模参与的探索性检验，不能证明业务预警性能。','',
      '事件日前回看窗口报警比例：',
    ]
    for _,r in warning.sort_values('lookback_hours').iterrows():
        line.append(f"  {int(r['lookback_hours'])}h: 事件日前 {r['event_day_pre_warning_fraction_all']:.2%}; 背景日 {r['pre_alarm_background_fraction']:.2%}")
    line.extend(['','D8汇流阈值1000像元：',
        f"  A候选路径 {pa['length_m']/1000:.3f}km，最近口岸 {pa['min_distance_to_port_m']:.2f}m，终止于 {pa['end_reason']}。",
        f"  B候选路径 {pb['length_m']/1000:.3f}km，最近口岸 {pb['min_distance_to_port_m']:.2f}m，终止于 {pb['end_reason']}。",
        f"  两条候选路径共有 {s4['overlap_pixels_A_B_primary']} 个重合像元；路径靠近口岸不代表真实泥石流到达。",'',
        f"冰川共同有效像元：{s7['common_valid_pixels']}，评分为静态相对筛查指标，不能解读为冰崩概率。",'',
        '2026年冰崩事件与2025年洪水分别作为典型事件与辅助案例回放，后者不计入泥石流触发时刻验证。',
        '【关键局限】现有日期级标签不足以确认小时级触发时间预测区间的95%覆盖率；第二阶段区间不是前瞻性时间预测。',
        '不能将灾前持续报警的窗口边界当作首次预警时间，也不能将D8路径长度当作真实影响距离。',
        '', '结果来源：第一至第七阶段输出；完整表格见同目录CSV与JSON。'
    ])
    (out/'paper_results_draft.txt').write_text('\n'.join(line),encoding='utf-8-sig')
    print('[4/5] 输出文件',flush=True)
    for f in sorted(out.iterdir()):print(' ',f.name)
    print('[5/5] 完成:',out,flush=True)
    print('关键校验：日期级AUC=',round(float(tm['auc']),4),'；95%小时区间已验证=否',flush=True)

if __name__=='__main__': main()
