# -*- coding: utf-8 -*-
"""MathorCup 问题三：继承第二问2.0的冻结逻辑回归模型。
说明：逐小时评分是日级模型的探索性扩展；本脚本不会伪造95%触发时间置信区间。
运行：python Q3_真实数据_第二问2_0衔接.py --weather clead.csv --events 吉隆县历史灾害_干净版.csv --dem DEM.tif
"""
from pathlib import Path
import argparse
import json
import warnings
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from sklearn.metrics import roc_auc_score, average_precision_score, confusion_matrix

# 第二问2.0 P72+D72模型：不重新拟合，不根据测试集调阈值
INTERCEPT = -0.2777418424
COEF = np.array([0.1998220392, 0.7153120356])
MEAN = np.array([4.7901234568, 31.3607664609])
SCALE = np.array([7.8600663607, 7.1384357546])
ALARM_THRESHOLD = 0.5193085227
TRAIN_START, TRAIN_END = '2021-04-01', '2021-07-31'
TEST_START, TEST_END = '2021-08-16', '2021-09-30'


def cli():
    p = argparse.ArgumentParser(description='第三问：第二问2.0模型的可验证预警回测')
    p.add_argument('--weather', default='clead.csv', help='含 Timestamp、MET_Precip(mm)、MET_Ta_2m(degree C)')
    p.add_argument('--events', default='吉隆县历史灾害_干净版(1).csv')
    p.add_argument('--dem', default='DEM(1).tif', help='可选，用于灾害点DEM覆盖审计')
    p.add_argument('--out', default='Q3_真实数据预警结果')
    p.add_argument('--lookback', type=int, default=72, help='事件日前最多检查多少小时的报警')
    return p.parse_args()


def read_weather(path):
    cols = ['Timestamp', 'MET_Precip(mm)', 'MET_Ta_2m(degree C)']
    d = pd.read_csv(path, usecols=cols, low_memory=False)
    d['Timestamp'] = pd.to_datetime(d['Timestamp'], errors='coerce')
    if d['Timestamp'].isna().any():
        raise ValueError('气象数据存在无法解析的 Timestamp')
    if d['Timestamp'].duplicated().any():
        raise ValueError('气象数据存在重复时间戳，请先核实')
    d = d.set_index('Timestamp').sort_index().asfreq('h')
    p = pd.to_numeric(d['MET_Precip(mm)'], errors='coerce')
    t = pd.to_numeric(d['MET_Ta_2m(degree C)'], errors='coerce')
    p = p.where((p >= 0) & (p < 999))
    t = t.where((t > -80) & (t < 60))
    # 完全继承第二问 shift(1) 与完整72小时窗口规则
    d['P72'] = p.shift(1).rolling(72, min_periods=72).sum()
    d['D72'] = t.clip(lower=0).shift(1).rolling(72, min_periods=72).sum() / 24
    z1 = (d['P72'] - MEAN[0]) / SCALE[0]
    z2 = (d['D72'] - MEAN[1]) / SCALE[1]
    eta = INTERCEPT + COEF[0] * z1 + COEF[1] * z2
    d['score'] = 1.0 / (1.0 + np.exp(-np.clip(eta, -700, 700)))
    d['alarm'] = np.where(d['score'].notna(), d['score'] >= ALARM_THRESHOLD, np.nan)
    d.index.name = 'Timestamp'
    return d


def read_events(path):
    e = pd.read_csv(path, encoding='utf-8-sig')
    if '发生日期' not in e.columns:
        raise ValueError('历史灾害CSV缺少「发生日期」字段')
    e['发生日期'] = pd.to_datetime(e['发生日期'], errors='coerce').dt.normalize()
    if e['发生日期'].isna().any():
        raise ValueError('历史灾害记录中存在非法发生日期')
    return e


def evaluate_daily(w, e, out):
    # 第二问是在每日零时使用此前72小时观测，对当天事件日进行评分
    daily = w.loc[w.index.hour == 0, ['P72', 'D72', 'score', 'alarm']].copy()
    daily.index = daily.index.normalize()
    daily.index.name = 'date'
    daily['event'] = daily.index.isin(e['发生日期'].unique()).astype(int)
    sel = daily.loc[TEST_START:TEST_END].dropna(subset=['P72', 'D72', 'score']).copy()
    if len(sel) == 0:
        raise ValueError('测试期没有完整气象特征')
    sel['alarm'] = sel['alarm'].astype(int)
    y = sel['event'].to_numpy(dtype=int)
    pred = sel['alarm'].to_numpy(dtype=int)
    tn, fp, fn, tp = confusion_matrix(y, pred, labels=[0, 1]).ravel()
    metrics = {
        'test_samples': int(len(sel)), 'test_recorded_event_days': int(y.sum()),
        'test_background_days': int((y == 0).sum()),
        'roc_auc': float(roc_auc_score(y, sel['score'])) if len(np.unique(y)) == 2 else None,
        'average_precision': float(average_precision_score(y, sel['score'])) if y.sum() else None,
        'tn': int(tn), 'fp': int(fp), 'fn': int(fn), 'tp': int(tp),
        'recorded_event_recall': float(tp / (tp + fn)) if tp + fn else None,
        'background_alarm_fraction': float(fp / (fp + tn)) if fp + tn else None,
        'note': '事件日标签仅精确到天，背景日不等于核实的无灾日；本分数非校准概率。'
    }
    daily.to_csv(out / '每日零时风险与事件标签.csv', encoding='utf-8-sig')
    sel.to_csv(out / '测试期每日零时结果.csv', encoding='utf-8-sig')
    return metrics


def event_audit(w, e, out, lookback):
    # 事件发生时刻仅知落于 [事件日00:00, 次日00:00)，不能赋予真实小时
    # 对每一个不同事件日期，在事件前lookback小时~事件日结束观测报警；日内报警不算已证实提前报警
    rows = []
    for day in sorted(pd.to_datetime(e['发生日期'].unique())):
        start, end = day, day + pd.Timedelta(days=1)
        s = w.loc[(w.index >= start - pd.Timedelta(hours=lookback)) & (w.index < end), ['score', 'alarm']].copy()
        pre = s.loc[s.index < start].dropna(subset=['score'])
        in_day = s.loc[s.index >= start].dropna(subset=['score'])
        hits_pre = pre.index[pre['alarm'] == 1]
        hits_today = in_day.index[in_day['alarm'] == 1]
        # 报警连续起始点，避免把72小时前已经持续的报警当作精确发报时刻
        first_pre = hits_pre.min() if len(hits_pre) else pd.NaT
        # 如果提前报警时间为 t_a，真实时刻 T∈[day,day+24h)，领先量在 [day-t_a,day+24h-t_a) 内
        lower = (start - first_pre).total_seconds()/3600 if pd.notna(first_pre) else np.nan
        upper = (end - first_pre).total_seconds()/3600 if pd.notna(first_pre) else np.nan
        rows.append({
            'event_date': day.date().isoformat(),
            'records_on_day': int((e['发生日期'] == day).sum()),
            'pre_hours_with_valid_features': int(len(pre)),
            'pre_day_any_alarm': bool(len(hits_pre)),
            'first_prior_alarm_in_lookback': first_pre.isoformat(sep=' ') if pd.notna(first_pre) else '',
            'lead_lower_bound_hours_if_alarm_relevant': lower,
            'lead_upper_bound_hours_exclusive_if_alarm_relevant': upper,
            'any_alarm_during_event_day': bool(len(hits_today)),
            'day_midnight_score': float(w.at[start, 'score']) if start in w.index and pd.notna(w.at[start, 'score']) else np.nan,
            'caution': '仅事件日期已知；报警可持续很久，非经独立验证的预警提前量。'
        })
    audit = pd.DataFrame(rows)
    audit.to_csv(out / '历史事件预警时间审计.csv', index=False, encoding='utf-8-sig')
    return audit


def spatial_audit(e, dem_path, out):
    if not dem_path or not Path(dem_path).is_file():
        return '未提供DEM；空间范围未计算。缺少D8和汇流栅格，无法核验传播路径。'
    import rasterio
    from rasterio.warp import transform as xytransform
    if not {'经度','纬度'}.issubset(e.columns):
        return '灾害表无经纬度，跳过DEM覆盖审计。'
    res = e.copy()
    with rasterio.open(dem_path) as src:
        lons = pd.to_numeric(res['经度'], errors='coerce').to_numpy()
        lats = pd.to_numeric(res['纬度'], errors='coerce').to_numpy()
        valid_coord = np.isfinite(lons) & np.isfinite(lats)
        xs, ys = np.full(len(res), np.nan), np.full(len(res), np.nan)
        if valid_coord.any():
            xx, yy = xytransform('EPSG:4326', src.crs, lons[valid_coord].tolist(), lats[valid_coord].tolist())
            xs[valid_coord], ys[valid_coord] = xx, yy
        is_inside = valid_coord & (xs >= src.bounds.left) & (xs <= src.bounds.right) & (ys >= src.bounds.bottom) & (ys <= src.bounds.top)
        elevations = np.full(len(res), np.nan)
        idx = np.where(is_inside)[0]
        if len(idx):
            vals = list(src.sample([(xs[i], ys[i]) for i in idx]))
            for i, v in zip(idx, vals):
                z = float(v[0]); elevations[i] = z if np.isfinite(z) and (src.nodata is None or z != src.nodata) else np.nan
        res['DEM范围内'] = is_inside
        res['DEM高程_m'] = elevations
        res.to_csv(out / '历史灾点DEM覆盖审计.csv', index=False, encoding='utf-8-sig')
        return f'DEM CRS={src.crs}；{len(res)}条灾害记录中{int(is_inside.sum())}条坐标在栅格矩形范围内，{int(np.isfinite(elevations).sum())}条取得有效高程。仅为覆盖统计，不是空间预警距离。'


def make_plots(w, audit, out):
    plt.rcParams['axes.unicode_minus'] = False
    for font in ['Microsoft YaHei', 'SimHei', 'DejaVu Sans']:
        if font in {x.name for x in __import__('matplotlib').font_manager.fontManager.ttflist}:
            plt.rcParams['font.sans-serif'] = [font]; break
    for day_text, tag in [('2021-08-18', '2021_08_18'), ('2021-08-25', '2021_08_25'), ('2026-08-26', '2026_08_26')]:
        day = pd.Timestamp(day_text)
        d = w.loc[day - pd.Timedelta(days=5):day + pd.Timedelta(days=2)]
        if d['score'].notna().sum() == 0: continue
        fig, ax = plt.subplots(figsize=(12,4))
        ax.plot(d.index, d['score'], lw=1.5, label='Meteorological risk score')
        ax.axhline(ALARM_THRESHOLD, ls='--', color='tab:red', label='Training threshold')
        ax.axvspan(day, day + pd.Timedelta(days=1), color='tab:orange', alpha=.15, label='Recorded event day / case date')
        ax.set_ylim(0,1); ax.set_ylabel('Score (not calibrated probability)')
        ax.set_title(f'Dynamic score around {day_text}'); ax.grid(alpha=.2);ax.legend(loc='best')
        fig.autofmt_xdate();fig.tight_layout();fig.savefig(out/f'动态评分_{tag}.png',dpi=180);plt.close(fig)


def main():
    a = cli()
    out = Path(a.out);out.mkdir(parents=True,exist_ok=True)
    for path in [a.weather,a.events]:
        if not Path(path).is_file(): raise FileNotFoundError(f'文件不存在：{path}')
    w = read_weather(a.weather); e = read_events(a.events)
    w[['P72','D72','score','alarm']].to_csv(out/'逐小时动态评分.csv',encoding='utf-8-sig')
    metrics = evaluate_daily(w,e,out)
    audit = event_audit(w,e,out,a.lookback)
    spatial = spatial_audit(e,a.dem,out)
    make_plots(w,audit,out)
    summary = {
        'weather_start':str(w.index.min()), 'weather_end':str(w.index.max()),
        'weather_hours':len(w), 'hours_complete_P72_D72':int(w['score'].notna().sum()),
        'historical_records':int(len(e)), 'distinct_event_dates':int(e['发生日期'].nunique()),
        'second_question_frozen_model': {'intercept':INTERCEPT, 'coefficients':COEF.tolist(), 'means':MEAN.tolist(), 'scales':SCALE.tolist(), 'threshold':ALARM_THRESHOLD},
        'daily_test_metrics':metrics, 'spatial':spatial,
        'temporal_uncertainty':'历史记录仅有日期，不能估计/验证真实泥石流触发小时的95%置信/预测区间，也不能可靠计算小时级PICP。',
        'hourly_extension_note':'逐小时沿用日级模型参数是探索性滚动风险监测；小时级阈值性能尚未验证。',
        'warning_time_note':'事件前报警只提供按24小时事件日期区间推导的可能领先量上下界，并非真实证实的提前预警。',
        'spatial_scope_note':'空间预警距离尚须D8流向、汇流累积、可靠源区及目标区定义与路径验证。'
    }
    (out/'结果摘要.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(summary,ensure_ascii=False,indent=2))
    print('\n结果目录：',out.resolve())

if __name__ == '__main__': main()
