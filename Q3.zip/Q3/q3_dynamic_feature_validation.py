# -*- coding: utf-8 -*-
"""第三问：冻结48h基准 vs 事前动态气象特征增强模型。
放在 Q3 目录直接运行；读取 Q3_stage1_results 和 Q3_stage2_results。
只需要 numpy、pandas、scikit-learn；不使用 Matplotlib/Rasterio/pyproj。
注意：2021年历史事件只有日期；2026年事件不进入训练或模型选择。
"""
from pathlib import Path
import argparse
import json
import numpy as np
import pandas as pd
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score, average_precision_score, brier_score_loss

CAL_B0 = -2.070474371019093
CAL_B1 = 0.4419896098872232
HORIZON = 48
MAX_TRAIN_BACKGROUND_ALARM = 0.35
FEATURES = ['logit_score', 'precip_6h', 'precip_24h', 'dD72_24h', 'dscore_24h']


def sigmoid(x):
    return 1.0 / (1.0 + np.exp(-np.clip(x, -35, 35)))


def baseline_p48(score):
    s = np.clip(np.asarray(score, dtype=float), 1e-10, 1 - 1e-10)
    p24 = sigmoid(CAL_B0 + CAL_B1 * np.log(s / (1 - s)))
    return 1 - (1 - p24) ** 2


def build_hourly(path):
    h = pd.read_csv(path, parse_dates=['Timestamp']).set_index('Timestamp').sort_index()
    h = h[~h.index.duplicated(keep='first')]
    # 数据文件连续逐小时。严格把最近气象统计截止到发布时刻前1小时；不会用发布后的整点观测。
    if not (h.index.to_series().diff().dropna() == pd.Timedelta(hours=1)).all():
        raise ValueError('hourly_q2_score.csv 时间轴不连续；请先完成Stage1时间网格补齐')
    p = pd.to_numeric(h['precip_qc'], errors='coerce')
    h['precip_6h'] = p.shift(1).rolling(6, min_periods=6).sum()
    h['precip_24h'] = p.shift(1).rolling(24, min_periods=24).sum()
    h['dD72_24h'] = pd.to_numeric(h['D72'], errors='coerce') - pd.to_numeric(h['D72'], errors='coerce').shift(24)
    h['dscore_24h'] = pd.to_numeric(h['score'], errors='coerce') - pd.to_numeric(h['score'], errors='coerce').shift(24)
    s = pd.to_numeric(h['score'], errors='coerce').clip(1e-8, 1-1e-8)
    h['logit_score'] = np.log(s/(1-s))
    # 基准分数为Stage1按历史窗口计算。若不确定整点数据可用时刻，采取再滞后1小时更保守。
    return h


def choose_threshold(scores, y, limit=MAX_TRAIN_BACKGROUND_ALARM):
    a = np.asarray(scores, float); y = np.asarray(y, int)
    candidates = np.unique(np.r_[a, a.max() + 1e-9])
    records=[]
    for t in candidates:
        alarm=a>=t
        bg=alarm[y==0].mean() if (y==0).any() else np.nan
        rec=alarm[y==1].mean() if (y==1).any() else np.nan
        records.append((float(t), float(rec),float(bg), float(alarm.mean())))
    d=pd.DataFrame(records,columns=['threshold','train_window_recall','train_background_alarm_fraction','train_all_alarm_fraction'])
    feasible=d[d.train_background_alarm_fraction<=limit+1e-12]
    if feasible.empty: feasible=d
    sel=feasible.sort_values(['train_window_recall','train_background_alarm_fraction','threshold'],ascending=[False,True,False]).iloc[0]
    return float(sel.threshold),d


def metrics(f):
    if f.empty:return dict(n=0)
    y=f.event_within_48h.to_numpy(dtype=bool); a=f.warning.to_numpy(dtype=bool)
    out=dict(n=int(len(f)),positive_windows=int(y.sum()),background_windows=int((~y).sum()),
        tp=int((y&a).sum()),fp=int((~y&a).sum()),fn=int((y&~a).sum()),tn=int((~y&~a).sum()),
        window_recall=float(a[y].mean()) if y.any() else None,
        background_alarm_fraction=float(a[~y].mean()) if (~y).any() else None,
        issued_alarm_fraction=float(a.mean()),
        brier=float(brier_score_loss(y.astype(int),f.predicted_risk.to_numpy())))
    if len(np.unique(y))==2:
        out['auc']=float(roc_auc_score(y.astype(int),f.predicted_risk))
        out['average_precision']=float(average_precision_score(y.astype(int),f.predicted_risk))
    else:out['auc']=None;out['average_precision']=None
    return out


def event_check(f, event_dates, split_dates):
    allowed=set(pd.to_datetime(split_dates).dt.normalize())
    rows=[]
    for e in sorted(event_dates & allowed):
        # 排除事件日当天发行的预报，并要求在事件日00点前发布且预报窗口覆盖事件日的开始。
        earlier=f[(f.issue_time<e)&(f.issue_time+pd.Timedelta(hours=HORIZON)>e)&(f.warning)]
        first=earlier.issue_time.min() if len(earlier) else pd.NaT
        rows.append(dict(event_date=str(e.date()),any_prior_issue=not pd.isna(first),
            earliest_prior_issue='' if pd.isna(first) else str(first),
            min_lead_hours='' if pd.isna(first) else (e-first).total_seconds()/3600,
            max_lead_exclusive_hours='' if pd.isna(first) else (e-first).total_seconds()/3600+24))
    return pd.DataFrame(rows,columns=['event_date','any_prior_issue','earliest_prior_issue','min_lead_hours','max_lead_exclusive_hours'])


def build_issue_rows(days, h, events, split):
    records=[]
    for raw in pd.to_datetime(days['date']):
        t=raw.normalize()
        if t not in h.index:continue
        r=h.loc[t]
        if pd.isna(r['score']):continue
        dates=[e for e in events if t<=e<t+pd.Timedelta(hours=HORIZON)]
        rec=dict(split=split,issue_time=t,event_within_48h=int(bool(dates)),
                 event_dates=';'.join(str(e.date()) for e in sorted(dates)),
                 score=float(r['score']),p48_baseline=float(baseline_p48([r['score']])[0]))
        for name in FEATURES:rec[name]=float(r[name]) if pd.notna(r[name]) else np.nan
        records.append(rec)
    return pd.DataFrame(records)


def run(root):
    s1=root/'Q3_stage1_results';s2=root/'Q3_stage2_results';out=root/'Q3_dynamic_feature_results';out.mkdir(parents=True,exist_ok=True)
    for p in [s1/'hourly_q2_score.csv',s1/'event_date_audit.csv',s1/'test_daily_scores.csv',s2/'train_daily_calibration.csv']:
        if not p.exists():raise FileNotFoundError(f'缺少文件：{p}')
    h=build_hourly(s1/'hourly_q2_score.csv')
    ev=pd.read_csv(s1/'event_date_audit.csv')
    events={pd.Timestamp(x).normalize() for x in ev['event_date'].dropna()}
    trd=pd.read_csv(s2/'train_daily_calibration.csv');ted=pd.read_csv(s1/'test_daily_scores.csv')
    tr=build_issue_rows(trd,h,events,'train');te=build_issue_rows(ted,h,events,'test')
    if tr.empty or te.empty:raise ValueError('无法生成训练/测试发行记录，请核对原始日期列')
    ytr=tr.event_within_48h.to_numpy(dtype=int)
    if len(np.unique(ytr))<2:raise ValueError('训练期无正负两类样本，不能拟合增强模型')
    # 模型和特征集合在测试前固定；仅训练期拟合预处理、系数、报警阈值。
    model=Pipeline([('impute',SimpleImputer(strategy='median')),
                    ('scale',StandardScaler()),
                    ('logreg',LogisticRegression(C=0.1,max_iter=2000,random_state=42))])
    model.fit(tr[FEATURES],ytr)
    tr['p48_dynamic']=model.predict_proba(tr[FEATURES])[:,1]
    te['p48_dynamic']=model.predict_proba(te[FEATURES])[:,1]
    comparison=[];all_preds=[];all_events=[];all_th=[]
    for name,col in [('baseline','p48_baseline'),('dynamic','p48_dynamic')]:
        threshold, grid=choose_threshold(tr[col],ytr)
        grid.insert(0,'model',name);all_th.append(grid)
        for split,base,days in [('train',tr,trd),('test',te,ted)]:
            cur=base.copy();cur['model']=name;cur['predicted_risk']=cur[col];cur['warning']=cur.predicted_risk>=threshold
            cur['threshold']=threshold
            ev_audit=event_check(cur,events,days['date']);ev_audit.insert(0,'model',name);ev_audit.insert(1,'split',split)
            all_events.append(ev_audit);all_preds.append(cur)
            met=metrics(cur);met.update(dict(model=name,split=split,threshold=threshold,
                  distinct_event_dates=len(ev_audit),prior_warned_event_dates=int(ev_audit.any_prior_issue.sum())))
            comparison.append(met)
    pd.concat(all_preds,ignore_index=True).to_csv(out/'issued_forecasts_comparison.csv',index=False,encoding='utf-8-sig')
    pd.concat(all_events,ignore_index=True).to_csv(out/'event_level_warning_comparison.csv',index=False,encoding='utf-8-sig')
    pd.concat(all_th,ignore_index=True).to_csv(out/'train_threshold_search.csv',index=False,encoding='utf-8-sig')
    result=pd.DataFrame(comparison)
    result.to_csv(out/'metrics_comparison.csv',index=False,encoding='utf-8-sig')
    coefficients=dict(intercept=float(model.named_steps['logreg'].intercept_[0]),
        standardized_coefficients={k:float(v) for k,v in zip(FEATURES,model.named_steps['logreg'].coef_[0])},
        features=FEATURES,C=0.1)
    (out/'dynamic_model_coefficients.json').write_text(json.dumps(coefficients,ensure_ascii=False,indent=2),encoding='utf-8')
    notes={
      'protocol':'2021 train-only fit and threshold; 2021 test untouched; issue at 00:00, horizon 48h',
      'feature_timing':'6h/24h precipitation strictly from hours before issue; Q2 scores and D72 are rolling past-window measurements',
      'caution':'小样本、相关重叠窗口、无灾标签未完整核实；单次测试优于基准不能证明泛化；此脚本不提供95%小时区间覆盖保证',
      'baseline':'冻结Stage2校准并外推48小时风险的情景模型；非独立校准的未来48小时真概率',
      'dynamic':'特征集合固定的训练期正则化Logistic回归；输出概率也未经严格校准',
      'selection':'不利用2026事件选特征或阈值；36h/24h时域不参与本次选择',
      'counts':dict(train=len(tr),test=len(te)),
      'missing_dynamic_train':{k:int(tr[k].isna().sum()) for k in FEATURES},
      'missing_dynamic_test':{k:int(te[k].isna().sum()) for k in FEATURES}}
    (out/'run_summary.json').write_text(json.dumps(notes,ensure_ascii=False,indent=2),encoding='utf-8')
    print('[完成] 动态特征增强模型 vs 冻结48h基准')
    for row in comparison:
        print(f"{row['model']:8s} {row['split']:5s} | 阈值 {row['threshold']:.6f} | 窗口召回 {row['window_recall']:.4f} | 背景报警 {row['background_alarm_fraction']:.4f} | 事件日提前报警 {row['prior_warned_event_dates']}/{row['distinct_event_dates']} | AUC {row['auc']:.4f}" if row['auc'] is not None else str(row))
    print('输出文件夹:',out)
    print('提醒：历史样本仅日期标签；增强模型未证明小时级触发时刻或真实95%覆盖率。')

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--root',default=str(Path(__file__).resolve().parent));args=parser.parse_args()
    run(Path(args.root))
