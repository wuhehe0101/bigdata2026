# -*- coding: utf-8 -*-
"""MathorCup Q3 Stage 3 - auditable pre-event warning analysis.

Place alongside Q3_stage1_results and Q3_stage2_results, then run directly.
Optional: python q3_stage3_warning_validation.py --stage1 PATH --stage2 PATH --out PATH
Dependencies: pandas, numpy (no matplotlib required).

Important: day-only event labels do not reveal actual trigger hour. This program
never reports its own outputs as validated 95% hourly trigger-time coverage.
"""
from pathlib import Path
import argparse
import json
import numpy as np
import pandas as pd
# Matplotlib intentionally not imported: safe mode avoids Windows DLL loading crashes.

TEST_BEGIN = '2021-08-16'
TEST_END = '2021-09-30'
WINDOWS = (24, 48, 72)
SCORE_THRESHOLD = 0.5193085227  # frozen Q2 training threshold


def root_paths():
    folder = Path(__file__).resolve().parent
    p = argparse.ArgumentParser(description='Q3第三阶段：事件日前预警和覆盖率审计')
    p.add_argument('--stage1', type=Path, default=folder / 'Q3_stage1_results')
    p.add_argument('--stage2', type=Path, default=folder / 'Q3_stage2_results')
    p.add_argument('--out', type=Path, default=folder / 'Q3_stage3_results')
    return p.parse_args()


def load_csv(path, needed):
    if not path.is_file():
        raise FileNotFoundError(f'缺少输入文件: {path}。请先检查第一、二阶段结果路径。')
    df = pd.read_csv(path, encoding='utf-8-sig', low_memory=False)
    missing = set(needed) - set(df.columns)
    if missing:
        raise ValueError(f'{path.name} 缺少列: {sorted(missing)}')
    return df


def numeric_or_none(x):
    return None if pd.isna(x) else float(x)


def fmt_time(x):
    return '' if pd.isna(x) else pd.Timestamp(x).strftime('%Y-%m-%d %H:%M:%S')


def event_warning(rows, hourly, window):
    """Check ONLY [event_midnight-window, event_midnight)."""
    day = pd.Timestamp(rows['event_date']).normalize()
    left = day - pd.Timedelta(hours=window)
    grid = hourly.loc[(hourly.index >= left) & (hourly.index < day)]
    expected = int(window)
    valid = grid['score'].notna()
    alarm = valid & grid['alarm_flag']
    fully_observed = len(grid) == expected and bool(valid.all())
    first_alarm = grid.index[alarm].min() if alarm.any() else pd.NaT
    latest_alarm = grid.index[alarm].max() if alarm.any() else pd.NaT
    # First alarm within lookback may be continuation of preexisting warning;
    # a newly issued warning requires a transition from observed non-alarm.
    transitions = alarm & (~alarm.shift(1, fill_value=False)) & valid.shift(1, fill_value=False)
    new_alarm = grid.index[transitions].min() if transitions.any() else pd.NaT
    result = {
        'event_date': day.date().isoformat(), 'lookback_hours': window,
        'observed_score_hours': int(valid.sum()), 'expected_hours': expected,
        'complete_window': fully_observed,
        'alarm_hours': int(alarm.sum()),
        'alarm_before_event_day': bool(alarm.any()),
        'first_alarm_in_window': fmt_time(first_alarm),
        'last_alarm_in_window': fmt_time(latest_alarm),
        'first_confirmed_rising_edge': fmt_time(new_alarm),
        'warning_active_at_last_pre_day_hour': bool(alarm.iloc[-1]) if len(grid) and valid.iloc[-1] else None,
        'lead_lower_hours_if_first_alarm': numeric_or_none((day-first_alarm).total_seconds()/3600) if pd.notna(first_alarm) else None,
        'lead_upper_exclusive_hours_if_first_alarm': numeric_or_none((day + pd.Timedelta(days=1)-first_alarm).total_seconds()/3600) if pd.notna(first_alarm) else None,
        'record_count': int(rows['records_on_day']),
        'event_hour_verified': bool(rows.get('event_hour_verified', False)),
        'event_date_source_verified': bool(rows.get('event_date_source_verified', False)),
        'evaluation_scope': '2021_test' if pd.Timestamp(TEST_BEGIN) <= day <= pd.Timestamp(TEST_END) else 'other',
        'note': '报警仅为第二问日级模型的逐小时探索性评分；提前量依赖事件日期真实性和报警对应同一事件的假设。'
    }
    return result


def daily_window_background(daily, window):
    """For every eligible midnight: did an alarm occur in preceding window?"""
    # Daily samples at 00:00, not an event-hour verification.
    test = daily.loc[TEST_BEGIN:TEST_END].copy()
    return test


def plot_case(hourly, event_day, out):
    """Skip plots in safe mode; retain CSV/JSON computations."""
    return None


def main():
    args = root_paths()
    args.out.mkdir(parents=True, exist_ok=True)
    hourly = load_csv(args.stage1/'hourly_q2_score.csv', ['Timestamp', 'score', 'alarm'])
    events = load_csv(args.stage1/'event_date_audit.csv', ['event_date', 'records_on_day'])
    daily = load_csv(args.stage1/'daily_score_and_labels.csv', ['date','event_label','score'])
    stage2 = load_csv(args.stage2/'test_interval_forecasts.csv', [
        'date','event_label','conditional_95_interval_start','conditional_95_interval_end'])
    hourly['Timestamp'] = pd.to_datetime(hourly['Timestamp'], errors='raise')
    if hourly['Timestamp'].duplicated().any():
        raise ValueError('hourly_q2_score.csv 包含重复时间戳')
    hourly = hourly.set_index('Timestamp').sort_index().asfreq('h')
    hourly['score'] = pd.to_numeric(hourly['score'],errors='coerce')
    # Rebuild alarm from immutable threshold, no dependence on CSV boolean codec.
    hourly['alarm_flag'] = hourly['score'].ge(SCORE_THRESHOLD) & hourly['score'].notna()
    daily['date'] = pd.to_datetime(daily['date'], errors='raise')
    daily = daily.set_index('date').sort_index()
    events['event_date'] = pd.to_datetime(events['event_date'], errors='raise').dt.normalize()

    results = [event_warning(ev, hourly, window) for _, ev in events.iterrows() for window in WINDOWS]
    report = pd.DataFrame(results).sort_values(['event_date','lookback_hours'])
    report.to_csv(args.out/'event_warning_windows.csv', index=False, encoding='utf-8-sig')
    test_event_rows = report.loc[report['evaluation_scope']=='2021_test']
    summary_rows = []
    for window in WINDOWS:
        rows = test_event_rows.loc[test_event_rows['lookback_hours']==window]
        complete = rows.loc[rows['complete_window']]
        # Report two denominators: all recorded test event-days and complete windows.
        summary_rows.append({
            'lookback_hours':window,
            'test_recorded_event_days':int(len(rows)),
            'test_event_days_complete_window':int(len(complete)),
            'test_event_days_with_any_pre_day_alarm':int(rows['alarm_before_event_day'].sum()),
            'test_complete_days_with_pre_day_alarm':int(complete['alarm_before_event_day'].sum()),
            'event_day_pre_warning_fraction_all':float(rows['alarm_before_event_day'].mean()) if len(rows) else np.nan,
            'event_day_pre_warning_fraction_complete':float(complete['alarm_before_event_day'].mean()) if len(complete) else np.nan,
        })
    warning_summary = pd.DataFrame(summary_rows)
    warning_summary.to_csv(args.out/'window_warning_summary.csv', index=False,encoding='utf-8-sig')

    # Evaluation also on background days, always label as "no record" not confirmed no-event.
    background_rows=[]
    test_days = daily.loc[TEST_BEGIN:TEST_END].dropna(subset=['score'])
    for day, val in test_days.iterrows():
        for window in WINDOWS:
            r=event_warning({'event_date':day, 'records_on_day': 0}, hourly, window)
            background_rows.append({
                'date':day.date().isoformat(), 'event_label':int(val['event_label']),
                'lookback_hours':window,'complete_window':r['complete_window'],
                'any_pre_day_alarm':r['alarm_before_event_day'],
                'observed_score_hours':r['observed_score_hours']
            })
    bg=pd.DataFrame(background_rows)
    bg.to_csv(args.out/'test_day_pre_warning_audit.csv',index=False,encoding='utf-8-sig')
    bg_metrics=[]
    for window in WINDOWS:
        w=bg[(bg.lookback_hours==window)&(bg.complete_window)]
        events_w=w[w.event_label==1]
        backgrounds_w=w[w.event_label==0]
        bg_metrics.append({
            'lookback_hours':window, 'complete_event_days':int(len(events_w)),
            'complete_background_days':int(len(backgrounds_w)),
            'pre_alarm_event_fraction':float(events_w.any_pre_day_alarm.mean()) if len(events_w) else None,
            'pre_alarm_background_fraction':float(backgrounds_w.any_pre_day_alarm.mean()) if len(backgrounds_w) else None,
            'caution':'Background means no event *record*, not confirmed no-event.'
        })
    pd.DataFrame(bg_metrics).to_csv(args.out/'test_warning_metrics.csv',index=False,encoding='utf-8-sig')

    # Stage 2 interval audit: for day-only labels, event time in [day, day+1 day).
    # Fully containing event day is certain; any overlap is possible; partial overlap is unknown.
    iv=[]
    for _, r in stage2[stage2.event_label==1].iterrows():
        day=pd.Timestamp(r['date']).normalize(); end_day=day+pd.Timedelta(days=1)
        a=pd.to_datetime(r['conditional_95_interval_start'],errors='coerce')
        b=pd.to_datetime(r['conditional_95_interval_end'],errors='coerce')
        valid=pd.notna(a) and pd.notna(b) and a<=b
        certain=bool(valid and a<=day and b>=end_day)
        possible=bool(valid and a<end_day and b>=day)
        iv.append({'event_date':day.date().isoformat(),
                   'event_time_left':fmt_time(day),'event_time_right_exclusive':fmt_time(end_day),
                   'model_interval_start':fmt_time(a),'model_interval_end':fmt_time(b),
                   'coverage_certain':certain,'coverage_possible':possible,
                   'coverage_undetermined':possible and not certain,
                   'interval_constructed_using_event_day':True,
                   'is_genuine_pre_event_forecast':False,
                   'note':'Stage2 interval conditions on occurrence on the same day; not a prospective prediction.'})
    ivdf=pd.DataFrame(iv)
    ivdf.to_csv(args.out/'interval_coverage_audit.csv',index=False,encoding='utf-8-sig')
    interval_stats={
        'recorded_test_event_days':len(iv),
        'certain_coverage_lower_bound':float(ivdf.coverage_certain.mean()) if len(iv) else None,
        'possible_coverage_upper_bound':float(ivdf.coverage_possible.mean()) if len(iv) else None,
        '95_percent_hourly_coverage_verified':False,
        'prospective_coverage_estimate_available':False,
        'why':'Stage2 interval is conditional on the known event day; it is not a prospective time prediction.'
    }
    outputs=[]
    for day in events.event_date:
        if pd.Timestamp(TEST_BEGIN) <= day <= pd.Timestamp(TEST_END):
            generated=plot_case(hourly,day,args.out)
            if generated:outputs.append(generated)
    # Chart generation disabled to avoid native DLL crashes in matplotlib.
    summary={
        'stage':'3 / warning timing audit',
        'stage1_input':str(args.stage1.resolve()),'stage2_input':str(args.stage2.resolve()),
        'frozen_q2_threshold':SCORE_THRESHOLD,
        'test_event_day_pre_warning_by_window':summary_rows,
        'background_day_evaluation':bg_metrics,
        'interval_coverage':interval_stats,
        'figures':[], 'figures_note':'Skipped in safe mode due to possible matplotlib DLL failure.',
        'warnings':[
            'Event dates and occurrence meaning require external source verification.',
            'No actual trigger hours are available; lead times are bounds, not exact lead times.',
            'A persistent alarm may have started before the measured lookback; first alarm in window is not necessarily a new alert.',
            'Window inspection is retrospective and does not establish real-time operational forecasting.',
            'Background days are unverified no-event days.',
            'Stage2 conditional within-event-day intervals must NOT be called a validated prospective 95% prediction interval.',
            'This script does not identify a 95% trigger-time interval nor a validated 95% coverage probability.'
        ]
    }
    (args.out/'stage3_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
    (args.out/'README_results.txt').write_text('Q3 Stage 3: 预警回测。\n'
        'event_warning_windows.csv: 19个事件日期的事件日前24/48/72小时报警审计。\n'
        'window_warning_summary.csv: 2021测试事件日前报警比例。\n'
        'test_day_pre_warning_audit.csv、test_warning_metrics.csv: 对比无记录背景日。\n'
        'interval_coverage_audit.csv: 第二阶段条件区间的覆盖可判定性检查。\n'
        'stage3_summary.json: 汇总、统计局限。\n'
        '重要：这不是经过验证的95%真实触发时刻预测区间。\n', encoding='utf-8-sig')
    print(json.dumps(summary,ensure_ascii=False,indent=2))
    print('输出目录:',args.out.resolve())

if __name__=='__main__':
    main()
