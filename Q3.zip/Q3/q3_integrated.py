# -*- coding: utf-8 -*-
"""2026 MathorCup 第三问：第二问2.0冻结模型 + D8候选通道空间审计。
本程序不是物理泥石流运动模拟；不声称能够估计真实触发小时95%区间。
使用示例：
python Q3_时空整合_第二问2_0.py --weather clead.csv --events "吉隆县历史灾害_干净版(1).csv" --dem "DEM(1).tif" --d8 "D8流向.tif" --acc "汇流累积_像元数.tif"
"""
import argparse
import json
import math
from pathlib import Path
import numpy as np
import pandas as pd
import rasterio
from rasterio.warp import reproject, Resampling
from rasterio.transform import xy
from rasterio.windows import Window
from matplotlib import pyplot as plt
from q3_time_core import read_weather, read_events, evaluate_daily, event_audit, spatial_audit, make_plots, COEF, INTERCEPT, MEAN, SCALE, ALARM_THRESHOLD

# 这些坐标为此前分析采用的近似坐标，并非经核实的冰崩起始位置/口岸边界
PORT = (340500., 3129500.)
SOURCES = {'候选源区A': (355000., 3130500.), '候选源区B': (356000., 3129500.)}
# D8编码：ESRI-style clockwise from East
FLOW = {1:(0,1),2:(1,1),4:(1,0),8:(1,-1),16:(0,-1),32:(-1,-1),64:(-1,0),128:(-1,1)}


def arguments():
    p=argparse.ArgumentParser()
    p.add_argument('--weather',default='clead.csv')
    p.add_argument('--events',default='吉隆县历史灾害_干净版(1).csv')
    p.add_argument('--dem',default='DEM(1).tif')
    p.add_argument('--d8',default='D8流向.tif')
    p.add_argument('--acc',default='汇流累积_像元数.tif')
    p.add_argument('--out',default='Q3_时空整合输出')
    p.add_argument('--snap-radius',type=float,default=500.)
    p.add_argument('--acc-threshold',type=float,default=1000.)
    p.add_argument('--port-radius',type=float,default=500.)
    return p.parse_args()


def same_grid(a,b):
    return a.crs==b.crs and a.width==b.width and a.height==b.height and a.transform.almost_equals(b.transform)


def snap_to_stream(acc, transform, point, radius, threshold):
    from rasterio.transform import rowcol
    cy,cx=rowcol(transform,*point)
    resolution=min(abs(transform.a),abs(transform.e))
    reach=int(math.ceil(radius/resolution))+2
    rr0=max(0,cy-reach);rr1=min(acc.shape[0],cy+reach+1)
    cc0=max(0,cx-reach);cc1=min(acc.shape[1],cx+reach+1)
    rows,cols=np.mgrid[rr0:rr1,cc0:cc1]
    xx,yy=xy(transform,rows,cols,offset='center')
    xx=np.asarray(xx).reshape(rows.shape); yy=np.asarray(yy).reshape(rows.shape)
    dist=np.hypot(xx-point[0],yy-point[1])
    local=acc[rr0:rr1,cc0:cc1]
    ok=(dist<=radius)&np.isfinite(local)&(local>=threshold)
    if not ok.any(): return None
    # 距离优先，避免按最大汇流量跳到另一条更远的沟道
    d=np.where(ok,dist,np.inf)
    k=np.unravel_index(np.argmin(d),d.shape)
    return int(rows[k]),int(cols[k]),float(d[k])


def trace(d8,start,transform,port,port_radius,max_steps=200000):
    r,c=start; visited=set(); route=[]; reason=''; mind=float('inf');entered=False
    for _ in range(max_steps):
        if not(0<=r<d8.shape[0] and 0<=c<d8.shape[1]):reason='离开栅格边界';break
        if (r,c) in visited:reason='D8循环';break
        visited.add((r,c));route.append((r,c))
        x,y=xy(transform,r,c,offset='center')
        dist=math.hypot(x-port[0],y-port[1]);mind=min(mind,dist)
        if dist<=port_radius:entered=True
        code=int(d8[r,c])
        if code not in FLOW:reason=f'不可用方向编码或NoData: {code}';break
        dr,dc=FLOW[code];r+=dr;c+=dc
    else:reason='超过步数上限'
    return route,mind,entered,reason


def spatial_paths(demfile,d8file,accfile,out,snap_radius,threshold,port_radius):
    with rasterio.open(d8file) as flow, rasterio.open(accfile) as accum, rasterio.open(demfile) as dem:
        if not same_grid(flow,accum):raise ValueError('D8与汇流累积栅格的CRS、transform或尺寸不一致')
        if flow.crs is None or dem.crs is None:raise ValueError('栅格缺少CRS')
        if str(flow.crs)!='EPSG:32645':raise ValueError(f'预期D8使用UTM 45N EPSG:32645，实际{flow.crs}')
        d8=flow.read(1);acc=accum.read(1)
        # DEM重采样只用于为已经存在的D8候选路径提供高程；不重新构建D8
        elev=np.full(flow.shape,np.nan,dtype=np.float32)
        reproject(source=rasterio.band(dem,1),destination=elev,
                  src_transform=dem.transform,src_crs=dem.crs,src_nodata=dem.nodata,
                  dst_transform=flow.transform,dst_crs=flow.crs,dst_nodata=np.nan,
                  resampling=Resampling.bilinear)
        rows=[];summary=[];tracks=[]
        for name,point in SOURCES.items():
            start=snap_to_stream(acc,flow.transform,point,snap_radius,threshold)
            if start is None:
                summary.append({'源区':name,'状态':'附近无符合阈值的候选沟道'});continue
            r,c,snap_dist=start
            route,nearest,entered,reason=trace(d8,(r,c),flow.transform,PORT,port_radius)
            length=0.
            last=None
            for j,(rr,cc) in enumerate(route):
                x,y=xy(flow.transform,rr,cc,offset='center')
                if last is not None:length+=math.hypot(x-last[0],y-last[1])
                last=(x,y)
                rows.append({'候选源区':name,'顺序':j,'累计长度_m':length,'UTM_X':x,'UTM_Y':y,
                             'DEM高程_m':float(elev[rr,cc]) if np.isfinite(elev[rr,cc]) else np.nan,
                             '汇流累积_像元数':float(acc[rr,cc]),'距口岸近似点_m':math.hypot(x-PORT[0],y-PORT[1])})
            tracks.append((name,route))
            summary.append({'源区':name,'状态':'完成候选D8路径追踪','源区坐标近似_X':point[0],
                            '源区坐标近似_Y':point[1],'吸附距离_m':snap_dist,'路径长度_km':length/1000,
                            '最近口岸近似点_m':nearest,'进入口岸指定缓冲区':entered,
                            '终止原因':reason,'有效路径像元数':len(route),
                            '提示':'D8候选通道不是泥石流实测轨迹；进入缓冲区不是到达口岸'})
        pd.DataFrame(rows).to_csv(out/'候选D8路径逐像元.csv',index=False,encoding='utf-8-sig')
        pd.DataFrame(summary).to_csv(out/'空间候选通道审计.csv',index=False,encoding='utf-8-sig')
        fig,ax=plt.subplots(figsize=(9,7))
        from rasterio.transform import rowcol
        pr,pc=rowcol(flow.transform,*PORT)
        radius=1000
        slr=slice(max(0,pr-radius),min(flow.height,pr+radius))
        slc=slice(max(0,pc-radius),min(flow.width,pc+radius))
        local=elev[slr,slc]
        x0,y0=xy(flow.transform,slr.stop-1,slc.start,offset='center')
        x1,y1=xy(flow.transform,slr.start,slc.stop-1,offset='center')
        ax.imshow(local,extent=[x0,x1,y0,y1],origin='upper',cmap='terrain',alpha=.85)
        for i,(name,route) in enumerate(tracks):
            xys=[xy(flow.transform,r,c,offset='center') for r,c in route]
            ax.plot([p[0] for p in xys],[p[1] for p in xys],lw=1.3,label=name)
            ax.scatter([xys[0][0]],[xys[0][1]],s=35)
        ax.scatter([PORT[0]],[PORT[1]],marker='*',s=160,color='red',label='Port approximate point')
        ax.set_aspect('equal');ax.set_xlabel('UTM X (m)');ax.set_ylabel('UTM Y (m)')
        ax.set_title('Candidate D8 channels (not validated debris-flow routes)');ax.legend()
        fig.tight_layout();fig.savefig(out/'候选通道与口岸.png',dpi=180);plt.close(fig)
        return summary


def main():
    args=arguments();out=Path(args.out);out.mkdir(parents=True,exist_ok=True)
    for x in [args.weather,args.events,args.dem,args.d8,args.acc]:
        if not Path(x).is_file():raise FileNotFoundError(f'找不到输入文件: {x}')
    w=read_weather(args.weather);e=read_events(args.events)
    w[['P72','D72','score','alarm']].to_csv(out/'逐小时动态评分.csv',encoding='utf-8-sig')
    met=evaluate_daily(w,e,out);event_audit(w,e,out,72);make_plots(w,None,out)
    coverage=spatial_audit(e,args.dem,out)
    spaces=spatial_paths(args.dem,args.d8,args.acc,out,args.snap_radius,args.acc_threshold,args.port_radius)
    result={'第二问冻结模型':{'intercept':INTERCEPT,'coef':COEF.tolist(),'mean':MEAN.tolist(),'scale':SCALE.tolist(),'threshold':ALARM_THRESHOLD},
            '测试期指标':met,'DEM历史灾点覆盖':coverage,'D8空间候选审计':spaces,
            '限制': ['历史事件仅有日期，不能据此验证触发小时95%置信/预测区间和小时级PICP',
                     '逐小时使用日级模型是探索性扩展，没有独立小时级标签验证',
                     '来源与口岸坐标为近似值；D8为地形推算，不代表泥石流真实传播距离',
                     '原始气象时间戳按小时开始标签并shift(1)，需核对原始数据说明',
                     '无灾害记录日是背景日，并非确认无灾']}
    (out/'结果摘要.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(result,ensure_ascii=False,indent=2));print('输出:',out.resolve())

if __name__=='__main__':main()
