﻿Q3 Stage 3: 预警回测。
event_warning_windows.csv: 19个事件日期的事件日前24/48/72小时报警审计。
window_warning_summary.csv: 2021测试事件日前报警比例。
test_day_pre_warning_audit.csv、test_warning_metrics.csv: 对比无记录背景日。
interval_coverage_audit.csv: 第二阶段条件区间的覆盖可判定性检查。
stage3_summary.json: 汇总、统计局限。
重要：这不是经过验证的95%真实触发时刻预测区间。
