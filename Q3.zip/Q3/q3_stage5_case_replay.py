# -*- coding: utf-8 -*-
"""MathorCup Q3 Stage 5: retrospective pre-event risk-score replay.

Inputs: Q3_stage1_results/hourly_q2_score.csv (frozen Q2.0 score).
Outputs: ASCII-named CSV/JSON/TXT in Q3_stage5_results.
No matplotlib, pyproj, rasterio or scipy imports.

This is retrospective association, NOT a validated prospective time forecast.
Event labels here are approximate reference times supplied by the researcher.
"""
from pathlib import Path
import argparse
import json
import numpy as np
import pandas as pd

THRESHOLD = 0.5193085227
CASES = [
    dict(id='ice_collapse_20260826', event_type='ice-rock collapse / debris-flow chain',
         reference='2026-08-26 10:52:00', time_uncertainty_minutes=15,
         use_for_debris_trigger_validation=True,
         caveat='Approximate ice-rock collapse onset; debris-flow initiation may be later.'),
    dict(id='flood_20250708', event_type='flood (auxiliary case only)',
         reference='2025-07-08 05:45:00', time_uncertainty_minutes=15,
         use_for_debris_trigger_validation=False,
         caveat='Flood report time is not a verified debris-flow initiation time.'),
]
WINDOWS = [1, 6, 12, 24, 48, 72]


def paths(arg):
    base = Path(__file__).resolve().parent
    if arg:
        p = Path(arg).expanduser()
        if not p.is_file():
            raise FileNotFoundError(f'指定的逐小时评分文件不存在: {p}')
        return p
    candidates = [base/'Q3_stage1_results'/'hourly_q2_score.csv',
                  base/'hourly_q2_score.csv',
                  base.parent/'Q3_stage1_results'/'hourly_q2_score.csv']
    for p in candidates:
        if p.is_file():
            return p
    raise FileNotFoundError('找不到 hourly_q2_score.csv，请在参数 --hourly 中指定完整路径。')


def main():
    parser = argparse.ArgumentParser(description='Q3 Stage5: pre-event case replay; no graphics')
    parser.add_argument('--hourly', default=None, help='Stage1 hourly_q2_score.csv complete file path')
    parser.add_argument('--out', default=None, help='output folder')
    args = parser.parse_args()
    source = paths(args.hourly)
    out = Path(args.out).expanduser() if args.out else Path(__file__).resolve().parent / 'Q3_stage5_results'
    out.mkdir(parents=True, exist_ok=True)
    print('[1/4] 读取:', source, flush=True)
    df = pd.read_csv(source, encoding='utf-8-sig')
    expected = {'Timestamp', 'P72', 'D72', 'score'}
    if not expected.issubset(df.columns):
        raise ValueError(f'缺少列: {expected - set(df.columns)}')
    df['Timestamp'] = pd.to_datetime(df['Timestamp'], errors='raise')
    if df['Timestamp'].duplicated().any():
        raise ValueError('时间戳重复，停止处理。')
    df = df.sort_values('Timestamp').set_index('Timestamp')
    for col in ['P72', 'D72', 'score']:
        df[col] = pd.to_numeric(df[col], errors='coerce')
    # Use score, not cached alarm flags, to avoid nullable-bool CSV ambiguity.
    records, windows, hourly_cases = [], [], []
    print('[2/4] 回放历史案例（只读取参考时间之前的小时）', flush=True)
    for case in CASES:
        event = pd.Timestamp(case['reference'])
        history = df.loc[(df.index >= event - pd.Timedelta(hours=72)) & (df.index < event)].copy()
        valid = history['score'].notna()
        alarms = valid & (history['score'] >= THRESHOLD)
        if history.empty:
            raise ValueError(f'{case["id"]} 未找到灾前数据。')
        # Context for determining whether a new 0->1 transition happened in the 72-hour window.
        prior = df.loc[df.index < history.index[0]].tail(1)
        pval = float(prior['score'].iloc[0]) if len(prior) and pd.notna(prior['score'].iloc[0]) else np.nan
        state = bool(pval >= THRESHOLD) if pd.notna(pval) else None
        new_onsets = []
        for t, sc in history['score'].items():
            if pd.isna(sc):
                state = None
                continue
            flag = bool(sc >= THRESHOLD)
            if state is False and flag:
                new_onsets.append(t)
            state = flag
        last = history.loc[valid].tail(1)
        last_t = last.index[0] if len(last) else pd.NaT
        last_score = float(last['score'].iloc[0]) if len(last) else None
        alarm_t = history.index[alarms]
        first = alarm_t.min() if len(alarm_t) else pd.NaT
        latest = alarm_t.max() if len(alarm_t) else pd.NaT
        records.append(dict(
            case_id=case['id'], event_type=case['event_type'], reference_time=str(event),
            label_uncertainty_minutes_each_side=case['time_uncertainty_minutes'],
            reference_time_is_approximate=True,
            used_for_debris_trigger_validation=case['use_for_debris_trigger_validation'],
            valid_hours_72=int(valid.sum()), hours_in_72=len(history),
            valid_fraction_72=round(float(valid.mean()), 4),
            last_available_hour=str(last_t) if pd.notna(last_t) else '',
            last_score=last_score, last_above_threshold=bool(last_score >= THRESHOLD) if last_score is not None else None,
            any_alarm_72=bool(alarms.any()),
            first_above_threshold_72=str(first) if pd.notna(first) else '',
            lead_from_first_above_threshold_hours=round((event-first).total_seconds()/3600,3) if pd.notna(first) else None,
            last_above_threshold_72=str(latest) if pd.notna(latest) else '',
            lead_from_last_above_threshold_hours=round((event-latest).total_seconds()/3600,3) if pd.notna(latest) else None,
            new_crossings_within_72=len(new_onsets),
            first_confirmed_new_crossing=str(new_onsets[0]) if new_onsets else '',
            note=case['caveat']
        ))
        for h in WINDOWS:
            w = history.loc[history.index >= event - pd.Timedelta(hours=h)]
            v = w['score'].notna()
            a = v & (w['score'] >= THRESHOLD)
            windows.append(dict(case_id=case['id'], lookback_hours=h,
                                observations=int(len(w)), valid_hours=int(v.sum()),
                                complete_window=bool(len(w) == h and v.all()),
                                n_above_threshold=int(a.sum()), any_above_threshold=bool(a.any()),
                                max_score=float(w['score'].max()) if v.any() else None,
                                mean_score=float(w['score'].mean()) if v.any() else None,
                                first_hour_above=str(w.index[a].min()) if a.any() else '',
                                earliest_alarm_lead_hours=round((event - w.index[a].min()).total_seconds()/3600,3) if a.any() else None))
        temp = history.reset_index()[['Timestamp', 'P72', 'D72', 'score']].copy()
        temp['case_id'] = case['id']
        temp['hours_before_reference'] = (event - temp['Timestamp']).dt.total_seconds()/3600
        temp['above_threshold'] = np.where(temp['score'].isna(), pd.NA, temp['score'] >= THRESHOLD)
        hourly_cases.append(temp)
        print(f'  {case["id"]}: last_score={last_score}, hours_with_alarm={int(alarms.sum())}, '
              f'new_crossings={len(new_onsets)}', flush=True)

    print('[3/4] 写入结果', flush=True)
    pd.DataFrame(records).to_csv(out/'case_replay_summary.csv', index=False, encoding='utf-8-sig')
    pd.DataFrame(windows).to_csv(out/'case_windows.csv', index=False, encoding='utf-8-sig')
    pd.concat(hourly_cases, ignore_index=True).to_csv(out/'case_hourly_before_events.csv', index=False, encoding='utf-8-sig')
    summary = {
        'stage': '5 / retrospective risk replay',
        'input_file': str(source), 'fixed_q2_score_threshold': THRESHOLD,
        'cases': records, 'windows': WINDOWS,
        'method': 'Only stage1 scores timestamped before each reference time; hourly score uses prior 72h observations (shift 1 in stage1).',
        'important_limits': [
            'No future weather forecasts and no calibrated hourly debris-flow hazard are used.',
            'Alarm presence before known events is a retrospective indicator, not proof of timely operational warning.',
            'The 2026 reference time denotes approximate ice-collapse onset, not verified exact debris-flow initiation.',
            'The 2025 flood is auxiliary, not a debris-flow trigger positive sample.',
            'Only two selected cases: no estimate of sensitivity, 95% trigger-time interval, or coverage.',
            'First alarm inside the lookback may be part of an older persistent alarm; confirmed threshold transitions are reported separately.',
            'Reference clock times need verification against primary sources; this script does not validate source reliability.',
            'Weather Timestamp semantics and station coverage remain subject to independent audit.'
        ]
    }
    (out/'stage5_summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2, default=str), encoding='utf-8')
    (out/'README_results.txt').write_text(
        'Q3 Stage 5: case replay / 2026 ice collapse and 2025 flood.\n'
        'case_replay_summary.csv: one row per case; alarms and bounds.\n'
        'case_windows.csv: 1/6/12/24/48/72-hour windows.\n'
        'case_hourly_before_events.csv: hourly score for 72 hours before each reference.\n'
        'All scores are retrospective and do not constitute a validated 95% trigger-time prediction.\n',
        encoding='utf-8-sig')
    print('[4/4] 完成:', out.resolve(), flush=True)
    print(json.dumps({'cases': records, 'output': str(out.resolve())}, ensure_ascii=False, indent=2))

if __name__ == '__main__':
    main()
