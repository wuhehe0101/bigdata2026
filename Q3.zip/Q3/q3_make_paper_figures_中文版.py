# -*- coding: utf-8 -*-
"""Q3 manuscript figures. Place alongside Q3_*_results folders; run directly."""
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from matplotlib.patches import Patch

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'Q3_paper_figures_中文';OUT.mkdir(exist_ok=True)
from matplotlib import font_manager as fm
_fonts = {f.name for f in fm.fontManager.ttflist}
_cn_font = next((f for f in ['Microsoft YaHei','SimHei','Noto Sans CJK SC','Noto Sans CJK JP','PingFang SC'] if f in _fonts), 'DejaVu Sans')
plt.rcParams.update({'font.family':'sans-serif','font.sans-serif':[_cn_font],'axes.unicode_minus':False,'figure.dpi':130,'savefig.dpi':220,'font.size':10})
COL={'blue':'#2563eb','orange':'#ea580c','green':'#16a34a','gray':'#64748b','red':'#dc2626','purple':'#7c3aed'}
def save(fig,name):
 fig.savefig(OUT/name,bbox_inches='tight',facecolor='white');plt.close(fig);print('saved',name)

def required(p):
 fp=ROOT/p
 if not fp.exists():raise FileNotFoundError(f'Missing {fp}. Place script in the Q3 directory with results folders.')
 return pd.read_csv(fp)

def required_any(filename, preferred_dirs):
    """Locate real output files irrespective of old test vs local folder names."""
    for folder in preferred_dirs:
        candidate = ROOT / folder / filename
        if candidate.is_file():
            print('reading', candidate)
            return pd.read_csv(candidate, encoding='utf-8-sig')
    matches = sorted(p for p in ROOT.glob(f'Q3_*/{filename}') if p.is_file())
    if len(matches) == 1:
        print('reading', matches[0])
        return pd.read_csv(matches[0], encoding='utf-8-sig')
    if len(matches) > 1:
        print('Multiple files exist, using:', matches[0])
        return pd.read_csv(matches[0], encoding='utf-8-sig')
    raise FileNotFoundError(
        f'Cannot find {filename} under {ROOT}. '
        f'Check the stage 4/7 output directories or copy the corresponding CSV into Q3_stage4_results / Q3_stage7_results.'
    )

forecast=required('Q3_final_validation_results/issued_forecasts.csv')
forecast['issue_time']=pd.to_datetime(forecast['issue_time']); test=forecast[forecast.split=='test'].copy().sort_values('issue_time'); threshold=.216337
# Figure 1 - test risk and sustained warnings
fig,ax=plt.subplots(figsize=(12,4.8));ax.plot(test.issue_time,test.p48,color=COL['blue'],lw=2,label='未来48小时风险情景值')
ax.axhline(threshold,color=COL['red'],ls='--',lw=1.4,label='训练期预警阈值：0.216337')
ax.fill_between(test.issue_time,0,test.p48,where=test.warning.astype(bool),color=COL['orange'],alpha=.13,label='预警发布日')
for date in ['2021-08-18','2021-08-25','2021-09-02']:
 d=pd.Timestamp(date);ax.axvline(d,color=COL['gray'],ls=':',alpha=.8);ax.annotate(date[5:],(d,.93),xycoords=('data','axes fraction'),ha='center',fontsize=9)
ax.set(ylabel='48小时风险情景值',xlabel='预报发布日期',title='图1  测试期48小时风险及预警决策');ax.set_ylim(bottom=0);ax.legend(loc='upper left',fontsize=9);ax.grid(alpha=.18);fig.autofmt_xdate();save(fig,'fig01_48h_risk_warning.png')
# Figure2 - model comparison from validated logs
fig,axs=plt.subplots(1,2,figsize=(10.8,4.1));labels=['原始冻结模型','动态特征增强模型'];x=np.arange(2)
for ax,vals,title in [(axs[0],[.6792,.6625],'测试期48小时窗口AUC'),(axs[1],[.325,.45],'背景窗口报警比例')]:
 bars=ax.bar(x,vals,color=[COL['blue'],COL['orange']],width=.52);ax.set_xticks(x,labels);ax.set_ylim(0,max(vals)*1.3);ax.set_title(title);ax.grid(axis='y',alpha=.17)
 for b,v in zip(bars,vals):ax.text(b.get_x()+b.get_width()/2,v+.012,f'{v:.3f}',ha='center',fontsize=11,weight='bold')
fig.suptitle('图2  原始模型与动态特征增强模型比较');fig.tight_layout();save(fig,'fig02_model_comparison.png')
# Figure3 - event dates and warning segments
fig,ax=plt.subplots(figsize=(12,3.8));epi=required('Q3_final_numeric_audit_results/warning_episodes_final.csv')
for _,r in epi.iterrows():
 a=pd.Timestamp(r.first_issue_time);b=pd.Timestamp(r.last_issue_time)+pd.Timedelta(days=1)
 ax.barh(0,(b-a).total_seconds()/86400,left=mdates.date2num(a),height=.3,color=COL['orange'],alpha=.72)
for j,d in enumerate(['2021-08-18','2021-08-25','2021-09-02']):
 dt=pd.Timestamp(d);ax.axvline(dt,color=COL['green'] if j<2 else COL['red'],lw=1.8,ls='--');ax.text(dt,.44,dt.strftime('%m-%d'),rotation=0,ha='center',fontsize=9)
ax.set_xlim(pd.Timestamp('2021-08-14'),pd.Timestamp('2021-09-13'));ax.set_ylim(-.55,.7);ax.set_yticks([0],['预警状态']);ax.set_title('图3  连续预警片段与三个独立历史事件日期');ax.xaxis.set_major_formatter(mdates.DateFormatter('%m-%d'));ax.grid(axis='x',alpha=.2);fig.tight_layout();save(fig,'fig03_warning_episodes.png')
# Fig4 interval censoring illustrative from actual test rows
interval=required('Q3_interval_censored_results/event_level_interval_censoring.csv');rows=interval[(interval.split=='test') & (interval.prediction_available.astype(str).str.lower()=='true')].sort_values('event_date')
fig,ax=plt.subplots(figsize=(11.6,4.5));
for i,(_,r) in enumerate(rows.iterrows()):
 d0=pd.Timestamp(r.event_day_start);d1=pd.Timestamp(r.event_day_end_exclusive);p0=pd.Timestamp(r.predicted_interval_start);p1=pd.Timestamp(r.predicted_interval_end_exclusive)
 y=i;ax.plot([mdates.date2num(p0),mdates.date2num(p1)],[y+.11,y+.11],color=COL['blue'],lw=9,solid_capstyle='butt')
 ax.plot([mdates.date2num(d0),mdates.date2num(d1)],[y-.13,y-.13],color=COL['orange'],lw=9,solid_capstyle='butt')
 ax.text(mdates.date2num(d1)+.15,y,f'重叠 {r.overlap_hours:.0f}/24小时',va='center',fontsize=9)
ax.set_yticks(np.arange(len(rows)),[str(x)[5:] for x in rows.event_date]);ax.invert_yaxis();ax.set_xlabel('日期（2021年）');ax.set_title('图4  名义95%条件时间区间与历史事件日期的重叠');ax.legend(handles=[Patch(facecolor=COL['blue'],label='模型名义95%条件区间'),Patch(facecolor=COL['orange'],label='事件日期不确定区间（24小时）')],loc='lower right');ax.xaxis.set_major_formatter(mdates.DateFormatter('%m-%d'));ax.grid(axis='x',alpha=.14);fig.tight_layout();save(fig,'fig04_interval_censoring.png')
# fig5 paths in UTM and port marker
paths=required_any('d8_path_points.csv', ['Q3_stage4_results','Q3_stage4_validation','Q3_stage4_fixed_test']);fig,ax=plt.subplots(figsize=(8.4,7.1))
for s,c in [('A',COL['blue']),('B',COL['orange'])]:
 d=paths[paths.source==s].sort_values('sequence');ax.plot(d.x_utm/1000,d.y_utm/1000,color=c,lw=2,label=f'候选源区{s} D8汇流路径');ax.scatter(d.x_utm.iloc[0]/1000,d.y_utm.iloc[0]/1000,color=c,s=60,marker='^',zorder=4)
ax.scatter(340.5,3129.5,color=COL['red'],marker='*',s=170,label='近似口岸参考点')
ax.set(xlabel='UTM 45N 东坐标（公里）',ylabel='UTM 45N 北坐标（公里）',title='图5  D8候选汇流通道（非实测运移路径）');ax.set_aspect('equal',adjustable='datalim');ax.grid(alpha=.15);ax.legend(fontsize=9);fig.tight_layout();save(fig,'fig05_d8_candidate_paths.png')
# fig6 glacier relative score scatter georeferenced
px=required_any('glacier_pixels_screen.csv', ['Q3_stage7_results','Q3_stage7_test']);fig,ax=plt.subplots(figsize=(8.6,6.6));sc=ax.scatter(px.x_utm_m/1000,px.y_utm_m/1000,c=px.relative_score,cmap='viridis',s=4,rasterized=True,vmin=0,vmax=1)
for s,xx,yy in [('A',355,3130.5),('B',356,3129.5)]:ax.scatter(xx,yy,s=150,marker='x',color=COL['red'],linewidths=2);ax.annotate(' '+s,(xx,yy),fontsize=12,weight='bold')
fig.colorbar(sc,ax=ax,label='经验百分位相对筛查评分');ax.set(xlabel='UTM 45N 东坐标（公里）',ylabel='UTM 45N 北坐标（公里）',title='图6  冰川静态相对危险性筛查（非冰崩概率）');ax.set_aspect('equal',adjustable='box');ax.grid(alpha=.10);fig.tight_layout();save(fig,'fig06_glacier_screen.png')
print('全部6张中文图已生成:',OUT)
