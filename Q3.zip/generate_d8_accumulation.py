# -*- coding: utf-8 -*-
"""从原始 DEM 生成 D8 流向、上游汇流累积像元数及预览图。
安装依赖：pip install numpy rasterio pysheds matplotlib
"""
from pathlib import Path
import numpy as np
# 兼容新版NumPy与旧版pysheds
if not hasattr(np, "in1d"):
    np.in1d = np.isin
import rasterio
from rasterio.enums import Resampling
from rasterio.warp import calculate_default_transform, reproject
from pysheds.grid import Grid
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

# ========== 按需修改 ===========
INPUT_DEM = Path(r'D:\pythonProjects\mother_model\问题三\Q3\DEM.tif')
OUTPUT_DIR = Path(r'D:\pythonProjects\mother_model\问题三\Q3')
TARGET_CRS = 'EPSG:32645'
TARGET_RESOLUTION_M = 30
STREAM_THRESHOLD_CELLS = 1000  # 示例阈值：上游汇流像元数 >= 1000
# ==============================

# pysheds 的 D8 编码：N, NE, E, SE, S, SW, W, NW
D8_MAP = (64, 128, 1, 2, 4, 8, 16, 32)


def save_raster(path, arr, profile, dtype, nodata, description):
    meta = profile.copy()
    meta.update(driver='GTiff', count=1, dtype=dtype, nodata=nodata,
                compress='deflate', tiled=True, BIGTIFF='IF_SAFER')
    with rasterio.open(path, 'w', **meta) as ds:
        ds.write(np.asarray(arr, dtype=dtype), 1)
        ds.set_band_description(1, description)
    print('已保存:', path)


def main():
    if not INPUT_DEM.exists():
        raise FileNotFoundError(f'找不到DEM：{INPUT_DEM}。请修改脚本顶部 INPUT_DEM。')
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    projected_path = OUTPUT_DIR / 'DEM_UTM45N_30m.tif'
    filled_path = OUTPUT_DIR / 'DEM_填洼后.tif'
    direction_path = OUTPUT_DIR / 'D8流向.tif'
    accumulation_path = OUTPUT_DIR / '汇流累积_像元数.tif'
    stream_path = OUTPUT_DIR / '汇流沟道_阈值1000像元.tif'
    figure_path = OUTPUT_DIR / '水文分析预览.png'

    print('[1/5] 投影DEM到米制坐标系...')
    with rasterio.open(INPUT_DEM) as src:
        if src.crs is None:
            raise ValueError('DEM缺少CRS信息，请先确认其真实坐标系。')
        transform, width, height = calculate_default_transform(
            src.crs, TARGET_CRS, src.width, src.height, *src.bounds,
            resolution=TARGET_RESOLUTION_M)
        meta = src.profile.copy()
        meta.update(driver='GTiff', crs=TARGET_CRS, transform=transform,
                    width=width, height=height, count=1, dtype='float32',
                    nodata=-9999.0, compress='deflate')
        with rasterio.open(projected_path, 'w', **meta) as dst:
            reproject(source=rasterio.band(src, 1), destination=rasterio.band(dst, 1),
                      src_transform=src.transform, src_crs=src.crs,
                      src_nodata=src.nodata, dst_transform=transform,
                      dst_crs=TARGET_CRS, dst_nodata=-9999.0,
                      resampling=Resampling.bilinear)
    print('已保存:', projected_path)

    print('[2/5] 填洼与平坦区处理（较大的DEM可能需要几分钟）...')
    grid = Grid.from_raster(str(projected_path))
    dem = grid.read_raster(str(projected_path))
    valid = np.isfinite(np.asarray(dem)) & (np.asarray(dem) != -9999.0)
    if not valid.any():
        raise ValueError('重投影后没有有效DEM像元。')
    pit_filled = grid.fill_pits(dem)
    depression_filled = grid.fill_depressions(pit_filled)
    inflated = grid.resolve_flats(depression_filled)
    # 保存实际用于流向计算的处理后DEM，避免名称暗示仅做了填洼
    filled_arr = np.where(valid, np.asarray(inflated), -9999.0)
    save_raster(filled_path, filled_arr, meta, 'float32', -9999.0,
                'Hydrologically conditioned DEM (pits/depressions/flats)')

    print('[3/5] 计算D8流向...')
    fdir = grid.flowdir(inflated, dirmap=D8_MAP)
    dir_arr = np.where(valid, np.asarray(fdir), 0).astype('uint8')
    save_raster(direction_path, dir_arr, meta, 'uint8', 0,
                'D8 flow direction: E=1 SE=2 S=4 SW=8 W=16 NW=32 N=64 NE=128')

    print('[4/5] 计算汇流累积...')
    acc = grid.accumulation(fdir, dirmap=D8_MAP)
    acc_arr = np.where(valid, np.asarray(acc), 0).astype('uint32')
    save_raster(accumulation_path, acc_arr, meta, 'uint32', 0,
                'Upstream contributing cell count (pysheds accumulation)')
    streams = np.where(valid & (acc_arr >= STREAM_THRESHOLD_CELLS), 1, 0).astype('uint8')
    save_raster(stream_path, streams, meta, 'uint8', 0,
                f'Stream candidates: accumulation >= {STREAM_THRESHOLD_CELLS} cells')

    print('[5/5] 生成预览图...')
    fig, axes = plt.subplots(1, 3, figsize=(16, 5), constrained_layout=True)
    dem_plot = np.ma.masked_where(~valid, np.asarray(dem))
    axes[0].imshow(dem_plot, cmap='terrain')
    axes[0].set_title('DEM (UTM 45N, 30 m)')
    axes[1].imshow(np.ma.masked_where(~valid, dir_arr), cmap='tab20', vmin=0, vmax=128)
    axes[1].set_title('D8 flow direction')
    axes[2].imshow(np.ma.masked_where(~valid, np.log10(acc_arr.astype(float) + 1)), cmap='Blues')
    axes[2].set_title('log10(flow accumulation + 1)')
    for ax in axes:
        ax.set_xticks([])
        ax.set_yticks([])
    fig.savefig(figure_path, dpi=220, bbox_inches='tight')
    plt.close(fig)
    print('已保存:', figure_path)
    print('\n完成！有效像元:', int(valid.sum()), '最大汇流累积:', int(acc_arr.max()))
    print('D8编码: E=1, SE=2, S=4, SW=8, W=16, NW=32, N=64, NE=128')
    print('注意：这是地形水文汇流路径，不是经过力学计算的泥石流运动轨迹。')


if __name__ == '__main__':
    main()
