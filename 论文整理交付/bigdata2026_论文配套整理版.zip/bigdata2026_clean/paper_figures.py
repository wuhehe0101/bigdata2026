"""从本次计算表生成论文插图；所有绘图源数据同时导出。"""
from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from sklearn.metrics import roc_curve,precision_recall_curve
R=Path(__file__).resolve().parent;O=R/'outputs/figures';O.mkdir(parents=True,exist_ok=True)
plt.rcParams.update({'font.sans-serif':['Noto Sans CJK JP','DejaVu Sans'],'axes.unicode_minus':False,'font.size':10,'axes.spines.top':False,'axes.spines.right':False})
CAT=[]
def save(fig,name,caption):
 fig.tight_layout();fig.savefig(O/(name+'.png'),dpi=300,bbox_inches='tight');fig.savefig(O/(name+'.pdf'),bbox_inches='tight');plt.close(fig);CAT.append((name,caption))
def main():
 # Overall pipeline: methods and distinctions follow the submitted manuscript.
 fig,ax=plt.subplots(figsize=(11,3));ax.axis('off')
 texts=['多源观测与质量核查\nMET / RADM / SOIL / FLUX','Q1 多窗口异常\n同期与暖季背景','Q2 日级风险评分\n训练—隔离—测试','Q3 条件时间区间\n日期删失 / D8通道','Q4 深度平均动力学\nVoellmy / 侵蚀沉积']
 for i,t in enumerate(texts):
  ax.text(.1+i*.2,.55,t,ha='center',va='center',transform=ax.transAxes,bbox=dict(boxstyle='round,pad=.6',fc='#e7f0f5',ec='#49738b'),fontsize=9)
  if i<4:ax.annotate('',xy=(.18+i*.2,.55),xytext=(.155+i*.2,.55),xycoords='axes fraction',arrowprops={'arrowstyle':'->'})
 save(fig,'00_研究流程','各部分结论分别限于统计关联、经验评分、条件区间和数值情景。')
 d=pd.read_csv(R/'weather_q1.csv',index_col=0,parse_dates=True)
 x=pd.DataFrame(index=d.index)
 x['正积温24h (℃·日)']=d['MET_Ta_2m(degree C)'].clip(lower=0).rolling(24,min_periods=24).sum()/24
 for n,c in [('VPD (hPa)','FLUX_VPD(hPa)'),('感热通量 (W/m²)','FLUX_H(W/m2)'),('土壤热通量 (W/m²)','SOIL_G_0.1m(W/m2)'),('降水 (mm)','MET_Precip(mm)')]:x[n]=d[c]
 x['净辐射 (W/m²)']=d['RADM_Rsd(W/m2)']-d['RADM_Rsu(W/m2)']+d['RADM_Rld(W/m2)']-d['RADM_Rlu(W/m2)']
 end=pd.Timestamp('2026-08-26 10:00');event=x.loc[end-pd.Timedelta(hours=71):end]
 fig,axs=plt.subplots(3,2,figsize=(11,8))
 for ax,c in zip(axs.flat,x):ax.plot(event.index,event[c],color='#216682');ax.set_title(c);ax.tick_params(axis='x',rotation=25);ax.grid(alpha=.2)
 save(fig,'01_灾前72小时序列','事件窗口截至2026-08-26 10:00；正积温由℃·小时除24转为℃·日。缺失段不跨越截止时刻插值。')
 rows=[]
 def stat(s,n,c):
  return s.sum() if c=='降水 (mm)' and s.notna().sum()>=np.ceil(.8*n) else (s.mean() if c!='降水 (mm)' and s.notna().sum()>=np.ceil(.8*n) else np.nan)
 for n in [6,24,48,72]:
  for c in x:
   value=stat(x.loc[end-pd.Timedelta(hours=n-1):end,c],n,c);hist=[];warm=[]
   for year in range(2021,2026):
    t=end.replace(year=year);hist.append(stat(x.loc[t-pd.Timedelta(hours=n-1):t,c],n,c))
    s=x.loc[f'{year}-06-01':f'{year}-09-30',c];rolling=s.rolling(n,min_periods=int(np.ceil(n*.8)))
    warm.extend((rolling.sum() if c=='降水 (mm)' else rolling.mean()).dropna())
   h=np.array(hist);w=np.array(warm);med=np.nanmedian(h);mad=np.nanmedian(abs(h-med))
   rows.append(dict(variable=c,hours=n,value=value,historical_median=med,historical_years=int(np.isfinite(h).sum()),robust_z=(value-med)/(1.4826*mad) if mad else np.nan,percentile=100*np.mean(w<value) if np.isfinite(value) and len(w) else np.nan,warm_windows=len(w),event_coverage=x.loc[end-pd.Timedelta(hours=n-1):end,c].notna().mean()))
 a=pd.DataFrame(rows);a.to_csv(O/'q1_window_statistics.csv',index=False)
 fig,axs=plt.subplots(1,2,figsize=(12,4))
 for ax,key,title in zip(axs,['percentile','robust_z'],['暖季经验百分位（非概率）','严格同期稳健异常（描述性）']):
  tab=a.pivot(index='variable',columns='hours',values=key);im=ax.imshow(tab,cmap='RdBu_r' if key=='robust_z' else 'YlOrRd',aspect='auto');ax.set_yticks(range(len(tab)),tab.index);ax.set_xticks(range(4),['6h','24h','48h','72h']);ax.set_title(title);fig.colorbar(im,ax=ax)
 save(fig,'02_多窗口双背景对照','2021—2025年同期与6—9月暖季比较；暖季按每小时滑动，窗口重叠，至少80%覆盖。')
 warm=x[(x.index.year<2026)&x.index.month.isin([6,7,8,9])];res=warm-warm.groupby(warm.index.hour).transform('median');corr=res.corr(method='spearman');corr.to_csv(O/'q1_deseasoned_spearman.csv')
 fig,ax=plt.subplots(figsize=(7,6));im=ax.imshow(corr,vmin=-1,vmax=1,cmap='RdBu_r');ax.set_xticks(range(len(corr)),corr.columns,rotation=65,ha='right');ax.set_yticks(range(len(corr)),corr.index);fig.colorbar(im,ax=ax);save(fig,'03_去日变化相关性','每小时减历史暖季同小时中位数；相关不等同于因果，未用来补造缺失的V8评分。')
 quality=d.groupby(d.index.year).agg(lambda s:s.notna().mean());quality.to_csv(O/'quality_by_year.csv')
 fig,ax=plt.subplots(figsize=(9,4));groups=pd.DataFrame({g:quality[[c for c in quality if c.startswith(g+'_')]].mean(axis=1) for g in ['MET','RADM','SOIL','FLUX']});groups.plot.bar(ax=ax);ax.set_ylabel('处理后有效值比例');ax.set_ylim(0,1.05);save(fig,'04_年度数据覆盖','各组内列有效率的均值，不表示仪器QC已完整执行。')
 audit=json.loads((R/'question2/results_modified.json').read_text());m=audit['comparisons']['P72_D72'];samples=pd.read_csv(R/'question2/model_samples.csv',index_col=0,parse_dates=True)
 fig,ax=plt.subplots(figsize=(8,4));tr=samples.index<=pd.Timestamp('2021-07-31');te=samples.index>=pd.Timestamp('2021-08-16')
 for mask,label,col in [(tr,'训练期','#367d9c'),(te,'测试期','#da7844')]:ax.scatter(samples.index[mask],samples.loc[mask,'y'],label=label,c=col,s=24)
 ax.axvspan(pd.Timestamp('2021-08-01'),pd.Timestamp('2021-08-15 23:59'),color='grey',alpha=.2,label='15天隔离');ax.set_yticks([0,1],['无记录背景日','记录事件日']);ax.legend();save(fig,'05_时间前向划分','相同完整样本比较不同降雨窗口；背景日不等于经核实无灾日。')
 fig,ax=plt.subplots(figsize=(7,5));xx,yy=np.meshgrid(np.linspace(0,max(25,samples.P72.max()),150),np.linspace(samples.D72.min()-1,samples.D72.max()+1,150));eta=m['intercept_standardized']+m['coefficients_standardized'][0]*(xx-m['scaler_mean'][0])/m['scaler_scale'][0]+m['coefficients_standardized'][1]*(yy-m['scaler_mean'][1])/m['scaler_scale'][1];z=1/(1+np.exp(-eta));im=ax.contourf(xx,yy,z,levels=np.linspace(0,1,21),cmap='YlOrRd');ax.contour(xx,yy,z,levels=[m['threshold_from_training']],colors='black');
 for y,marker,label in [(0,'o','背景日'),(1,'*','记录事件日')]:
  s=samples[samples.y==y];ax.scatter(s.P72,s.D72,marker=marker,s=20 if y==0 else 90,edgecolors='black',label=label)
 ax.set(xlabel='P72 / mm',ylabel='D72 / ℃·日');ax.legend();fig.colorbar(im,ax=ax,label='模型评分（非校准概率）');save(fig,'06_联合经验判别边界','边界由训练期阈值确定；全部样本叠加只为展示分布，不参与重新拟合。')
 fig,axs=plt.subplots(1,2,figsize=(10,4))
 for name in audit['comparisons']:
  t=pd.read_csv(R/f'question2/temporal_holdout_{name}.csv');fpr,tpr,_=roc_curve(t.y,t.score);precision,recall,_=precision_recall_curve(t.y,t.score);axs[0].plot(fpr,tpr,label=name);axs[1].plot(recall,precision,label=name)
 axs[0].plot([0,1],[0,1],'k--');axs[0].set(xlabel='背景日报警比例',ylabel='记录事件日检出比例',title='测试集 ROC');axs[1].set(xlabel='Recall',ylabel='Precision',title='测试集 PR');axs[0].legend();axs[1].legend();save(fig,'07_时间测试ROC_PR','仅3个测试事件日；曲线用于回溯比较，不表明稳定泛化。')
 f=pd.read_csv(R/'q3/Q3_final_validation_results/issued_forecasts.csv',parse_dates=['issue_time','ci95_conditional_start','ci95_conditional_end_exclusive']);f=f[f.split=='test'];summary=json.loads((R/'q3/Q3_final_validation_results/final_validation_summary.json').read_text())
 fig,ax=plt.subplots(figsize=(10,4));ax.plot(f.issue_time,f.p48,'o-',markersize=3);ax.axhline(summary['policy']['threshold'],color='#c55a3b',ls='--',label='训练期确定阈值');ax.set_ylabel('48h条件情景评分');ax.legend();save(fig,'08_每日发布预警回测','风险持续情景只使用发布时可得信息；不是未来48h真实天气预报。')
 e=pd.read_csv(R/'q3/Q3_stage1_results/event_date_audit.csv');dates=pd.to_datetime(e.event_date);testdates=dates[(dates>='2021-08-16')&(dates<='2021-09-30')]
 fig,ax=plt.subplots(figsize=(9,4))
 for i,t in enumerate(testdates):
  a=f[f.issue_time==t-pd.Timedelta(days=1)]
  ax.barh(i,24,left=24,color='grey',alpha=.3,height=.5)
  if len(a):
   row=a.iloc[0];lo=(row.ci95_conditional_start-row.issue_time).total_seconds()/3600;hi=(row.ci95_conditional_end_exclusive-row.issue_time).total_seconds()/3600;ax.plot([lo,hi],[i,i],lw=4,color='#367d9c');ax.text(hi+1,i,'报警' if row.warning else '未报警',va='center')
 ax.set_yticks(range(len(testdates)),testdates.dt.strftime('%Y-%m-%d'));ax.set(xlabel='相对前一日00:00的小时数',xlim=(0,57),title='蓝：名义95%条件区间；灰：未知真实小时所在日');save(fig,'09_日期删失区间评价','条件区间不等于小时级95%覆盖；灰带是日期记录给定的整日区间，不捏造真实起动时刻。')
 import rasterio
 with rasterio.open(R/'q3/data/DEM_UTM45N_30m.tif') as ds:
  dem=ds.read(1,masked=True);extent=(ds.bounds.left,ds.bounds.right,ds.bounds.bottom,ds.bounds.top)
 paths=pd.read_csv(R/'q3/Q3_stage4_results/d8_path_points.csv');fig,axs=plt.subplots(1,2,figsize=(12,5));axs[0].imshow(dem,cmap='terrain',extent=extent)
 for source,g in paths.groupby('source'):axs[0].plot(g.x_utm,g.y_utm,label=source);axs[1].plot(g.cum_distance_m/1000,g.elevation_m,label=source)
 axs[0].scatter([340500],[3129500],marker='*',color='red',label='近似口岸');axs[0].set(xlabel='UTM东坐标/m',ylabel='UTM北坐标/m');axs[1].set(xlabel='候选通道距离/km',ylabel='DEM高程/m');axs[0].legend();axs[1].legend();save(fig,'10_D8通道与纵剖面','UTM45N；候选汇流路径不是验证后的泥石流轨迹，端点受DEM覆盖约束。')
 grid=pd.read_csv(R/'q4/grid_sensitivity.csv');fig,ax=plt.subplots(figsize=(6,4));ax.bar(grid.grid_m.astype(str),grid.arrival_s,color=['#367d9c','#da7844']);ax.set(xlabel='计算网格/m',ylabel='首个进入口岸300m邻域保存时刻/s');save(fig,'11_网格敏感性','两组网格使用相同物理参数与600秒时长；保存间隔10秒。')
 # Export three model surfaces using actual newly simulated frames.
 from rasterio.transform import xy
 with rasterio.open(R/'q4/results_90/最大流深_m.tif') as ds:shape=ds.shape;transform=ds.transform
 from rasterio.warp import reproject,Resampling
 with rasterio.open(R/'q4/data/elevation_utm45n.tif') as src:
  z=np.empty(shape,dtype=float);reproject(src.read(1),z,src_transform=src.transform,src_crs=src.crs,dst_transform=transform,dst_crs='EPSG:32645',src_nodata=src.nodata,dst_nodata=np.nan,resampling=Resampling.bilinear)
 arr=np.load(R/'q4/results_90/基准情景逐帧.npz');rr,cc=np.indices(shape);xx,yy=xy(transform,rr,cc);xx=np.asarray(xx).reshape(shape);yy=np.asarray(yy).reshape(shape)
 fig=plt.figure(figsize=(15,5));step=5
 for j,t in enumerate([0,240,480]):
  k=int(np.argmin(abs(arr['times']-t)));h=arr['frames'][k];ax=fig.add_subplot(1,3,j+1,projection='3d');ax.plot_surface(xx[::step,::step]/1000,yy[::step,::step]/1000,z[::step,::step],cmap='gist_earth',alpha=.65,linewidth=0,rcount=150,ccount=150);flow=np.where(h>.1,z+h,np.nan);ax.plot_surface(xx[::step,::step]/1000,yy[::step,::step]/1000,flow[::step,::step],color='#b84b24',linewidth=0);ax.set(title=f'{arr["times"][k]:.0f} s',xlabel='UTM E/km',ylabel='UTM N/km',zlabel='高程/m');ax.view_init(50,-65);ax.set_zlim(1500,7500);ax.set_box_aspect((1, .65, .45),zoom=.78);ax.set_zlabel('高程/m',labelpad=2)
 save(fig,'12_三维运动演化','从本次90m仿真提取0、240、480秒，显示地形上的模型流动层；渲染采样与计算网格分开。')
 (O/'图表索引.md').write_text('# 本次重算图表\n\n'+ '\n\n'.join(f'## {n}\n{c}\n\n![{n}]({n}.png)' for n,c in CAT),encoding='utf-8')
if __name__=='__main__':main()
