# 吉隆泥石流论文配套精简项目

依据 `docs/原始论文.docx` 整理，保留四问的方法主线。原工程保存在相邻目录 `bigdata2026`，本目录是可独立复制的交付工程，不依赖原工程和审计临时目录。

## 运行

建议 Python 3.12。在本目录执行：

```bash
python -m venv .venv
# Linux/macOS
source .venv/bin/activate
# Windows PowerShell 用 .venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python run_all.py
python -m pytest tests q4/tests -q
```

中文图需要安装 Noto Sans CJK 字体；当前验证环境已经提供。首次运行 Numba 会编译，完整运行含90m、60m两次600秒仿真。失败即停止，查看 `outputs/logs/`；`outputs/run_status.json` 记录各步骤退出码与耗时。所有数据已包含，无需在线数据服务、密钥或GIS桌面软件。

## 文件结构

- `data/`：24个年度原始观测CSV及历史灾害矢量配套文件。
- `preprocess.py`：原始表合并、哨兵值处理、Q1短缺测处理和质量审计。
- `question2/analyze.py`：日级逻辑回归、15天隔离、同样本窗口比较；同时保存参数。
- `q3/`：从Q2参数计算评分，训练期校准、48小时条件区间、日期删失、D8空间敏感性及静态冰川筛查。
- `q4/`：深度平均守恒求解器、Voellmy阻力、侵蚀沉积、两个网格情景、离线三维动画。
- `paper_figures.py`、`supplement_figures.py`：从本次结果生成PNG/PDF图表与底表。
- `outputs/figures/图表索引.md`：插图及解释边界；Q4原生图位于 `q4/results_90`，60m对照在 `q4/results_60`。
- `docs/整理与论文核对.md`：删留理由、已修复内容、不能隐瞒的论文与数据缺口。
- `docs/retained_manifest.json`：初始选取文件的来源和SHA256；`docs/delivery_manifest.csv`：最终交付文件哈希。

## 已验证结果

Q2训练81日（9个事件日）、测试46日（3个事件日）；P72+D72 AUC=0.713178，事件日检出2/3。Q3测试背景窗口报警13/40，2026年案例条件情景值0.234617，区间为8月25日11:00至8月27日09:00。Q4的90m/60m网格进入口岸300m邻域的保存时刻分别为440s/400s；90m峰值速度86.9898m/s，体积收支残差约−2.97e−9。8项测试通过。

## 必须保留的解释

第一问原稿最终评分的V8输入分量生成源码缺失，无法声称从原始数据完整复现旧评分。图14、15仅核算原稿历史表，图中已明确标识。FLUX缺QC_LE、QC_H；代码不虚构仪器质量标记。原始表覆盖至2026年底，与论文“截至8月27日”不一致，未来观测不参与目标事件特征、历史背景或训练。论文中10:30与10:52是不同参考时刻，图表按各章定义保留，需核实。任何情景或历史区间都不能当作实测95%预报可靠度。
