from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import shapefile,rasterio
from pyproj import Transformer,CRS
R=Path(__file__).resolve().parent;O=R/'outputs/figures'
plt.rcParams.update({'font.sans-serif':['Noto Sans CJK JP','DejaVu Sans'],'axes.unicode_minus':False})
def main():
 path=next((R/'data/spatial').glob('*.shp'));reader=shapefile.Reader(str(path),encoding='gb18030')
 source=CRS.from_wkt(path.with_suffix('.prj').read_text());proj=Transformer.from_crs(source,'EPSG:32645',always_xy=True)
 with rasterio.open(R/'q3/data/DEM_UTM45N_30m.tif') as ds:
  dem=ds.read(1,masked=True);extent=(ds.bounds.left,ds.bounds.right,ds.bounds.bottom,ds.bounds.top)
  fig,ax=plt.subplots(figsize=(8,7));ax.imshow(dem,cmap='terrain',extent=extent)
  rows=[]
  for i,shape in enumerate(reader.shapes()):
   a=np.array(shape.points);x,y=proj.transform(a[:,0],a[:,1]);parts=list(shape.parts)+[len(x)]
   for start,end in zip(parts[:-1],parts[1:]):ax.plot(x[start:end],y[start:end],color='#a33132',lw=.7)
   # Explicit representative-point metric; avoid silently equating polygon intersection with centroid coverage.
   cx,cy=float(np.mean(x)),float(np.mean(y));row,col=ds.index(cx,cy)
   covered=0<=row<ds.height and 0<=col<ds.width and not np.ma.getmaskarray(dem)[row,col]
   rows.append({'record':i,'vertex_mean_x':cx,'vertex_mean_y':cy,'representative_point_in_valid_dem':covered})
  pd.DataFrame(rows).to_csv(O/'spatial_coverage_audit.csv',index=False)
  ax.set(xlabel='UTM45N东坐标/m',ylabel='UTM45N北坐标/m',title=f'历史灾害范围与DEM空间支持（{len(rows)}条）');fig.tight_layout()
  for ext in ['png','pdf']:fig.savefig(O/f'13_研究区覆盖.{ext}',dpi=300,bbox_inches='tight')
  plt.close(fig)
 # Retained evidence is explicitly historical; only arithmetic is checked, not raw-data reproducibility.
 s=pd.read_csv(R/'docs/legacy_evidence/q1_original_scores.csv');s['recomputed_sum']=.25*s['Q_数据质量']+.25*s['P_方向修正']+.20*s['C_多窗口一致性']+.15*s['I_修正']+.15*s['M_物理解释']
 assert np.allclose(s.recomputed_sum,s['S_修正'])
 chosen=s.set_index('变量').loc[['正积温24h','VPD','净辐射','感热通量','土壤热通量']]
 fig,ax=plt.subplots(figsize=(9,4));left=np.zeros(len(chosen))
 for col,weight in [('Q_数据质量',.25),('P_方向修正',.25),('C_多窗口一致性',.20),('I_修正',.15),('M_物理解释',.15)]:
  values=chosen[col]*weight;ax.barh(chosen.index,values,left=left,label=col);left+=values
 ax.set(xlabel='历史评分分量加权值',title='原稿五因素评分核算（旧表证据，非本次原始数据重算）');ax.legend(fontsize=8,bbox_to_anchor=(1,1));fig.tight_layout()
 for ext in ['png','pdf']:fig.savefig(O/f'14_历史评分核算_非重算.{ext}',dpi=300,bbox_inches='tight')
 plt.close(fig);s.to_csv(O/'historical_score_arithmetic_audit.csv',index=False)
 # Weight sensitivity is also restricted to the frozen component table.
 rng=np.random.default_rng(42);components=chosen[['Q_数据质量','P_方向修正','C_多窗口一致性','I_修正','M_物理解释']].values
 weights=np.array([.25,.25,.2,.15,.15])*rng.uniform(.8,1.2,(1000,5));weights/=weights.sum(axis=1,keepdims=True);scores=components@weights.T
 fig,ax=plt.subplots(figsize=(8,4));ax.boxplot(scores.T,tick_labels=chosen.index);ax.set(ylabel='加权评分',title='历史分量权重±20%敏感性（不代表新数据验证）');fig.tight_layout()
 for ext in ['png','pdf']:fig.savefig(O/f'15_历史评分权重敏感性.{ext}',dpi=300,bbox_inches='tight')
 pd.DataFrame(weights).to_csv(O/'historical_weight_draws.csv',index=False)
 with (O/'图表索引.md').open('a') as f:f.write('\n\n## 补充图13—15\n13：历史灾害范围与DEM覆盖。覆盖审计采用顶点均值代表点，非论文质心/面相交覆盖率，不能替代23/84。\n14—15：历史评分算术核对和权重敏感性。缺V8分量生成代码，禁止标为原始数据重算图。\n')

 g=pd.read_csv(R/'q3/Q3_stage7_results/glacier_pixels_screen.csv')
 fig,axs=plt.subplots(1,3,figsize=(13,4))
 for ax,key,label in zip(axs,['thickness','v','relative_score'],['冰厚/m','冰流速度/(m/年)','静态相对筛查评分']):
  im=ax.scatter(g.x_utm_m,g.y_utm_m,c=g[key],s=2,cmap='viridis');ax.set_title(label);ax.set_aspect('equal');fig.colorbar(im,ax=ax,shrink=.7)
 fig.tight_layout()
 for ext in ['png','pdf']:fig.savefig(O/f'16_静态冰川筛查.{ext}',dpi=300,bbox_inches='tight')
 plt.close(fig)
 import sys
 sys.path.insert(0,str(R/'q3'))
 import q3_final_warning_validation as q
 cal=json.loads((R/'q3/Q3_stage2_results/stage2_summary.json').read_text())['calibration'];q.B0=cal['intercept'];q.B1=cal['coef']
 h=pd.read_csv(R/'q3/Q3_stage1_results/hourly_q2_score.csv',index_col=0,parse_dates=True)
 issue=pd.Timestamp('2026-08-25 10:00');p24,p48,lo,hi=q.forecast(h.loc[issue,'score'],issue)
 result={'issue':str(issue),'p48':p48,'start':str(lo),'end_exclusive':str(hi),'reference_time':'2026-08-26 10:52','note':'参考时刻与论文问题一10:30不同，均来自论文，未做独立事件核验'}
 (O/'case_2026.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
 fig,ax=plt.subplots(figsize=(10,3));ax.plot([lo,hi],[1,1],lw=10,color='#367d9c',label='名义95%条件区间');ax.axvline(issue,color='grey',label='发布时刻');ax.axvline(pd.Timestamp(result['reference_time']),color='#b7472b',ls='--',label='论文参考时刻');ax.set_yticks([]);ax.set_title(f'2026案例回溯：48h条件情景值 {p48:.6f}');ax.legend(fontsize=8);fig.autofmt_xdate();fig.tight_layout()
 for ext in ['png','pdf']:fig.savefig(O/f'17_2026条件区间回溯.{ext}',dpi=300,bbox_inches='tight')
 plt.close(fig)

if __name__=='__main__':main()
