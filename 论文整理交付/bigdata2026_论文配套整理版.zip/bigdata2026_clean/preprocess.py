"""原始年度表合并；Q1历史描述性QC，Q2/Q3仍使用未插值MET。"""
from pathlib import Path
import json
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parent

def short_interpolate(s):
    missing=s.isna(); runs=missing.groupby((missing!=missing.shift()).cumsum()).transform('sum')
    filled=s.interpolate(limit_area='inside')
    return s.where(~(missing & (runs<=3)),filled)

def main():
    frames=[];audit={}
    for group in ['MET','RADM','SOIL','FLUX']:
        d=pd.concat([pd.read_csv(p) for p in sorted((ROOT/'data').glob(group+'_*.csv'))],ignore_index=True)
        d.index=pd.to_datetime(d.pop('Timestamp'),format='mixed',errors='raise')
        if d.index.duplicated().any():raise ValueError(f'{group}: duplicate timestamps')
        d=d.sort_index().apply(pd.to_numeric,errors='coerce').replace([9999.9,9999,-9999,-9999.9],np.nan)
        audit[group]={'rows':len(d),'columns':list(d.columns)}
        frames.append(d.add_prefix(group+'_'))
    raw=pd.concat(frames,axis=1).sort_index().asfreq('h');raw.index.name='Timestamp'
    raw.to_csv(ROOT/'weather_raw.csv')
    # Historical Q1 may interpolate within a segment; split at event cutoff to avoid future leakage.
    q=raw.copy(); flags=[]
    for v in ['LE','H']:
        col=f'FLUX_{v}(W/m2)';bad=pd.Series(False,index=q.index)
        qc=f'FLUX_QC_{v}'
        if qc in q:bad|=q[qc]>=8
        else:flags.append(f'{qc} absent: sensor QC cannot be verified')
        for name,threshold in [('FLUX_USTAR(m/s)',.1),('FLUX_FETCH_90(m)',50)]:
            if name in q:bad|=q[name]<threshold
            else:flags.append(name+' absent')
        q.loc[bad,col]=np.nan
    cutoff=pd.Timestamp('2026-08-26 10:00')
    q=pd.concat([q.loc[:cutoff].apply(short_interpolate),q.loc[q.index>cutoff].apply(short_interpolate)])
    q.to_csv(ROOT/'weather_q1.csv');audit['merged_rows']=len(q);audit['warnings']=flags
    audit['interpolation']='Q1 only, bounded complete missing runs <=3h, split at event cutoff; Q2/Q3 use raw'
    (ROOT/'outputs').mkdir(exist_ok=True)
    (ROOT/'outputs/data_audit.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
