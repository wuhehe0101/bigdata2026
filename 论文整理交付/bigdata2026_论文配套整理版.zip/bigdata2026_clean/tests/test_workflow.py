import json
from pathlib import Path
import numpy as np
import pandas as pd
from preprocess import short_interpolate
R=Path(__file__).resolve().parents[1]
def test_short_gaps_only():
 s=pd.Series([1.,np.nan,np.nan,4.,np.nan,np.nan,np.nan,np.nan,9.]);v=short_interpolate(s)
 assert v.iloc[1:3].notna().all()
 assert v.iloc[4:8].isna().all()
def test_midnight_features_exclude_same_day():
 raw=pd.read_csv(R/'weather_raw.csv',index_col=0,parse_dates=True)
 features=pd.read_csv(R/'question2/daily_features.csv',index_col=0,parse_dates=True)
 t=pd.Timestamp('2021-07-01');p=raw.loc[t-pd.Timedelta(hours=72):t-pd.Timedelta(hours=1),'MET_Precip(mm)']
 assert len(p)==72
 assert abs(features.loc[t,'P72']-p.sum())<1e-8
 modified=raw.copy();modified.loc[t:,'MET_Precip(mm)']=999
 assert modified.loc[t-pd.Timedelta(hours=72):t-pd.Timedelta(hours=1),'MET_Precip(mm)'].equals(p)
def test_fitted_model_passed_to_q3():
 m=json.loads((R/'question2/results_modified.json').read_text())['comparisons']['P72_D72']
 hourly=pd.read_csv(R/'q3/Q3_stage1_results/hourly_q2_score.csv')
 valid=hourly.dropna(subset=['P72','D72','score'])
 eta=m['intercept_standardized']+((valid[['P72','D72']].values-np.array(m['scaler_mean']))/np.array(m['scaler_scale'])@np.array(m['coefficients_standardized']))
 assert np.allclose(valid.score,1/(1+np.exp(-eta)))
def test_splits_and_interval_semantics():
 m=json.loads((R/'question2/results_modified.json').read_text());assert m['train_positive_days']==9 and m['test_positive_days']==3
 f=pd.read_csv(R/'q3/Q3_final_validation_results/issued_forecasts.csv',parse_dates=['issue_time','ci95_conditional_start','ci95_conditional_end_exclusive'])
 assert f[f.split=='train'].issue_time.max()<pd.Timestamp('2021-08-01')
 assert f[f.split=='test'].issue_time.min()>=pd.Timestamp('2021-08-16')
 assert (f.ci95_conditional_start>=f.issue_time).all()
 assert (f.ci95_conditional_end_exclusive<=f.issue_time+pd.Timedelta(hours=48)).all()
