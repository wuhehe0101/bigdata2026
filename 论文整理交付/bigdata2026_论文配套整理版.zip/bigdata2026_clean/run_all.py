"""一键运行全部保留的分析；每一步失败即停止，旧结果不作为成功证据。"""
from pathlib import Path
import os,sys,subprocess,json,time
R=Path(__file__).resolve().parent
os.environ['MPLBACKEND']='Agg';os.environ['MPLCONFIGDIR']=str(R/'.cache/matplotlib');os.environ['NUMBA_CACHE_DIR']=str(R/'.cache/numba')
steps=[['preprocess.py'],['question2/analyze.py'],
['q3/q3_stage1_audit_fixed.py','--weather','weather_raw.csv','--events','吉隆县历史灾害_干净版.csv'],
['q3/q3_stage2_interval_model.py'],['q3/q3_final_warning_validation.py'],['q3/q3_interval_censored_validation.py'],
['q3/q3_stage4_spatial_validation_safe_v2.py','--dem','q3/data/DEM_UTM45N_30m.tif','--d8','q3/data/D8流向.tif','--acc','q3/data/汇流累积_像元数.tif'],
['q3/q3_stage7_glacier_screen.py','--nc','glacier.nc'],['q4/run.py'],['paper_figures.py'],['supplement_figures.py']]
if __name__=='__main__':
 (R/'outputs/logs').mkdir(parents=True,exist_ok=True); report=[]
 for i,args in enumerate(steps):
  print('RUN',*args,flush=True);t=time.time()
  with (R/f'outputs/logs/{i:02}.log').open('w') as f:
   p=subprocess.run([sys.executable,*args],cwd=R,stdout=f,stderr=subprocess.STDOUT)
  report.append({'command':args,'returncode':p.returncode,'seconds':time.time()-t})
  (R/'outputs/run_status.json').write_text(json.dumps(report,indent=2))
  if p.returncode:raise SystemExit(f'Failed: {args}; see outputs/logs/{i:02}.log')
