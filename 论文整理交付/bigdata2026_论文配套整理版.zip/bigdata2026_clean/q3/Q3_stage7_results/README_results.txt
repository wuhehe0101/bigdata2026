﻿第七阶段：基于冰川掩膜内四项变量的静态相对排序。
glacier_pixels_screen.csv 每个共同有效冰川像元及指标。
glacier_variable_stats.csv 指标描述统计。
source_neighborhood_audit.csv 近似源区A/B与冰川栅格的邻近比较。
重要：相对等级不等于真实冰崩概率，不能据此预测触发小时。
