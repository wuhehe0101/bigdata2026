# -*- coding: utf-8 -*-
"""第三问收尾：固定日00:00发布 + 前向测试 + 条件95%区间审计。
输入：Q3_stage1_results/{hourly_q2_score.csv,event_date_audit.csv,test_daily_scores.csv}
      Q3_stage2_results/train_daily_calibration.csv
仅依赖 pandas/numpy；无 matplotlib/rasterio。直接放在Q3目录运行。
"""
from pathlib import Path
import argparse, json
import numpy as np
import pandas as pd

B0=-2.070474371019093; B1=0.4419896098872232
H=48; TARGET_BURDEN=0.35

def forecast(score, issue):
    v=np.clip(float(score),1e-10,1-1e-10)
    p24=float(1/(1+np.exp(-np.clip(B0+B1*np.log(v/(1-v)),-30,30))))
    h=1-(1-p24)**(1/24)
    pm=h*(1-h)**np.arange(H)
    prob=float(pm.sum()); cdf=np.cumsum(pm)/prob
    lo=int(np.searchsorted(cdf,.025)); hi=int(np.searchsorted(cdf,.975))
    return p24,prob,issue+pd.Timedelta(hours=lo),issue+pd.Timedelta(hours=hi+1)

def interval_audit(a,b,d):
    e=d+pd.Timedelta(days=1)
    if a<=d and b>=e:return 'certain_covered'
    if b<=d or a>=e:return 'certain_not_covered'
    return 'unknown_partial_overlap'

def main():
    global B0, B1
    ap=argparse.ArgumentParser(); root=Path(__file__).resolve().parent
    ap.add_argument('--root',default=str(root)); args=ap.parse_args(); root=Path(args.root)
    s1=root/'Q3_stage1_results'; s2=root/'Q3_stage2_results'; out=root/'Q3_final_validation_results';out.mkdir(exist_ok=True)
    fn=[s1/'hourly_q2_score.csv',s1/'event_date_audit.csv',s1/'test_daily_scores.csv',s2/'train_daily_calibration.csv']
    for f in fn:
        if not f.exists():raise FileNotFoundError(f'缺少必要文件: {f}')
    calibration=json.loads((s2/'stage2_summary.json').read_text())['calibration']
    B0=calibration['intercept']; B1=calibration['coef']
    hourly=pd.read_csv(fn[0],parse_dates=['Timestamp']).set_index('Timestamp').sort_index()
    ev=pd.read_csv(fn[1]);events={pd.Timestamp(x).normalize() for x in ev['event_date'].dropna()}
    train=pd.read_csv(fn[3]);test=pd.read_csv(fn[2]);
    # Keep both training and test release grids strictly within their original splits.
    def build(df,split):
        rows=[]
        for _,r in df.iterrows():
            d=pd.Timestamp(r['date']).normalize()
            if d not in hourly.index or pd.isna(hourly.at[d,'score']):continue
            p24,p48,a,b=forecast(hourly.at[d,'score'],d)
            matching=sorted([e for e in events if d<=e<d+pd.Timedelta(hours=H)])
            rows.append(dict(split=split,issue_time=d,score=float(hourly.at[d,'score']),p24=p24,p48=p48,
                label_event_day_within_48h=int(bool(matching)),events_in_window=';'.join(str(x.date()) for x in matching),
                ci95_conditional_start=a,ci95_conditional_end_exclusive=b))
        return pd.DataFrame(rows)
    tr=build(train,'train');te=build(test,'test')
    # Explicitly select threshold with TRAIN ONLY. Candidate thresholds from train projected 48-hour scenario risks.
    thresholds=np.unique(np.r_[tr.p48.to_numpy(),tr.p48.max()+1e-9])
    choices=[]
    for th in thresholds:
        alarm=tr.p48>=th; bg=tr.label_event_day_within_48h==0; pos=~bg
        burden=float(alarm[bg].mean()) if bg.sum() else np.nan
        recall=float(alarm[pos].mean()) if pos.sum() else np.nan
        choices.append(dict(threshold=float(th),train_event_window_recall=recall,train_background_window_alarm_fraction=burden,
                            train_alarm_fraction=float(alarm.mean())))
    ch=pd.DataFrame(choices)
    feasible=ch[ch.train_background_window_alarm_fraction<=TARGET_BURDEN+1e-12]
    candidates=feasible if len(feasible) else ch
    selected=candidates.sort_values(['train_event_window_recall','train_background_window_alarm_fraction','threshold'],ascending=[False,True,False]).iloc[0]
    th=float(selected.threshold)
    for df in (tr,te):df['warning']=df.p48>=th
    # Metrics window-level and event-day-level (nonindependence explicit).
    def metrics(df):
        pos=df.label_event_day_within_48h.astype(bool);neg=~pos;w=df.warning
        return dict(n_issued=len(df),n_positive_windows=int(pos.sum()),n_background_windows=int(neg.sum()),
            recall_positive_windows=float(w[pos].mean()) if pos.sum() else None,
            alarm_fraction_background_windows=float(w[neg].mean()) if neg.sum() else None,
            overall_warning_fraction=float(w.mean()) if len(df) else None,
            tp=int((w&pos).sum()),fp=int((w&neg).sum()),fn=int((~w&pos).sum()),tn=int((~w&neg).sum()))
    # Distinct event dates in TEST only, find earliest issued warning in prior 48h, excluding issues on event date
    test_dates=sorted(pd.to_datetime(test['date']).dt.normalize().unique())
    evtest=sorted(e for e in events if e in set(test_dates))
    erows=[]
    for e in evtest:
        preceding=te[(te.issue_time<e)&(te.issue_time+pd.Timedelta(hours=H)>e)&te.warning]
        # Note boundary condition: event might occur at any point during its recorded day.
        earliest=preceding.issue_time.min() if len(preceding) else pd.NaT
        # The earlier issue can be 24-48h ahead of date start; unknown true event hour adds [0,24)h.
        if pd.isna(earliest):
            erows.append(dict(event_date=e,any_prior_warning=False,earliest_prior_warning='',lead_lower_hours='',lead_upper_exclusive_hours='',coverage_status='no_warning'))
        else:
            p=preceding[preceding.issue_time==earliest].iloc[0]
            min_lead=(e-earliest).total_seconds()/3600
            erows.append(dict(event_date=e,any_prior_warning=True,earliest_prior_warning=earliest,
                              lead_lower_hours=min_lead,lead_upper_exclusive_hours=min_lead+24,
                              coverage_status=interval_audit(pd.Timestamp(p.ci95_conditional_start),pd.Timestamp(p.ci95_conditional_end_exclusive),e)))
    ea=pd.DataFrame(erows)
    # Audit every event mention by issue to keep coverage bounds conservative.
    coverage=[]
    for _,r in te.iterrows():
        if not r.events_in_window:continue
        for es in r.events_in_window.split(';'):
            e=pd.Timestamp(es)
            coverage.append(dict(issue_time=r.issue_time,event_date=e,warning=bool(r.warning),
                                 status=interval_audit(pd.Timestamp(r.ci95_conditional_start),pd.Timestamp(r.ci95_conditional_end_exclusive),e)))
    cov=pd.DataFrame(coverage)
    counts=cov.status.value_counts().to_dict() if len(cov) else {}
    total=len(cov); lower=counts.get('certain_covered',0)/total if total else None
    upper=(counts.get('certain_covered',0)+counts.get('unknown_partial_overlap',0))/total if total else None
    # Daily warning streak lengths in test (not hourly 1442h run).
    te=te.sort_values('issue_time').reset_index(drop=True)
    groups=(te.issue_time.diff().dt.days.ne(1)|te.warning.ne(te.warning.shift())).cumsum()
    runs=[]
    for _,g in te.groupby(groups):
        if bool(g.warning.iloc[0]):runs.append(dict(start=str(g.issue_time.iloc[0]),end_inclusive=str(g.issue_time.iloc[-1]),n_daily_issues=len(g)))
    pd.DataFrame(runs,columns=['start','end_inclusive','n_daily_issues']).to_csv(out/'warning_runs_test.csv',index=False,encoding='utf-8-sig')
    pd.concat([tr,te]).to_csv(out/'issued_forecasts.csv',index=False,encoding='utf-8-sig')
    ch.to_csv(out/'train_threshold_candidates.csv',index=False,encoding='utf-8-sig')
    ea.to_csv(out/'test_distinct_event_audit.csv',index=False,encoding='utf-8-sig')
    cov.to_csv(out/'date_interval_coverage_audit.csv',index=False,encoding='utf-8-sig')
    result=dict(policy=dict(issue='daily 00:00',horizon_hours=48,threshold=th,train_background_alarm_fraction_target=TARGET_BURDEN,
            selected_on='2021 train only',warning_semantics='issue-specific decision, not new crossing; warning if p48 >= threshold'),
            train=metrics(tr),test=metrics(te),n_test_distinct_event_days=len(ea),
            n_event_days_with_prior_warning=int(ea.any_prior_warning.sum()) if len(ea) else 0,
            n_test_daily_warning_runs=len(runs),maximum_test_consecutive_warning_days=max([x['n_daily_issues'] for x in runs],default=0),
            conditional_95_interval_date_coverage_lower_bound=lower,conditional_95_interval_date_coverage_upper_bound=upper,
            n_overlapping_event_window_mentions=total,coverage_status_counts=counts,
            warnings=['日期级事件起始小时不明确；上下界不是95%覆盖率的估计。','48h重叠窗口不独立；不要把窗口数当作独立灾害次数。',
              '事件日可能漏报；背景窗口报警比例不是正式误报率。',
              '天气使用风险持续情景，并非真实历史天气预报。',
              '风险校准基于少量训练日，预测区间是条件分布，不代表真实95%可靠度。',
              '2026年冰崩链式事件不作为泥石流精确触发时间的校准标签。'])
    (out/'final_validation_summary.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    print('[完成] 输出:',out)
    print('训练期选定p48阈值:',round(th,6),'训练窗口指标:',metrics(tr))
    print('测试窗口指标:',metrics(te))
    print('独立事件日期:',len(ea),'事前至少一次报警:',result['n_event_days_with_prior_warning'])
    print('时间区间日期可判定覆盖上下界:',lower,upper,'注意重叠窗口不独立。')
    print('时间小时级95%覆盖率未获验证。')
if __name__=='__main__':main()
