# -*- coding: utf-8 -*-
"""第三问：日期区间删失的95%条件时间预测区间评价。
用法：将脚本置于 Q3 文件夹，直接 PyCharm 运行。
或 python q3_interval_censored_validation.py --root "D:\\...\\Q3"
要求已有 Q3_final_validation_results/issued_forecasts.csv 和
Q3_stage1_results/event_date_audit.csv。
不重训、不调整阈值、不使用事件未来信息构造预测。
"""
from pathlib import Path
import argparse
import json
import math
import re
import pandas as pd
import numpy as np


def read_csv(path):
    for enc in ('utf-8-sig', 'gb18030', 'utf-8'):
        try:
            return pd.read_csv(path, encoding=enc, low_memory=False)
        except UnicodeDecodeError:
            continue
    raise RuntimeError(f'无法解码: {path}')


def dt(v):
    return pd.to_datetime(v, errors='coerce')


def hours(a, b):
    return max(0., (min(a[1], b[1]) - max(a[0], b[0])).total_seconds() / 3600.)


def classify(date_start, date_end, pred_start, pred_end):
    day_len = (date_end-date_start).total_seconds()/3600.
    overlap = hours((date_start,date_end), (pred_start,pred_end))
    if overlap <= 1e-9:
        tag='definitely_not_covered'
    elif overlap >= day_len-1e-9:
        tag='definitely_covered'
    else:
        tag='partially_overlaps_unknown'
    return tag, overlap, overlap/day_len


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--root', default=str(Path(__file__).resolve().parent), help='Q3项目路径')
    ap.add_argument('--forecasts', default='', help='事前预报CSV（默认：Q3_final_validation_results/issued_forecasts.csv）')
    ap.add_argument('--events', default='', help='事件日期CSV（默认：Q3_stage1_results/event_date_audit.csv）')
    ap.add_argument('--supplement', default='', help='可选：泥石流(2).csv，仅做吉隆相关日期交叉核对')
    args=ap.parse_args()
    root=Path(args.root)
    fp=Path(args.forecasts) if args.forecasts else root/'Q3_final_validation_results'/'issued_forecasts.csv'
    ep=Path(args.events) if args.events else root/'Q3_stage1_results'/'event_date_audit.csv'
    out=root/'Q3_interval_censored_results';out.mkdir(parents=True, exist_ok=True)
    if not fp.exists(): raise FileNotFoundError(f'找不到事前预测文件: {fp}')
    if not ep.exists(): raise FileNotFoundError(f'找不到历史事件文件: {ep}')
    f=read_csv(fp); e=read_csv(ep)
    required_f=['split','issue_time','ci95_conditional_start','ci95_conditional_end_exclusive','warning']
    required_e=['event_date']
    for c in required_f:
        if c not in f.columns: raise ValueError(f'预测文件缺少列: {c}；实际列: {list(f.columns)}')
    for c in required_e:
        if c not in e.columns: raise ValueError(f'事件文件缺少列: {c}')
    for c in ['issue_time','ci95_conditional_start','ci95_conditional_end_exclusive']:
        f[c]=dt(f[c])
    f['split']=f['split'].astype(str).str.lower().str.strip()
    f['warning']=f['warning'].astype(str).str.lower().isin(['true','1','yes'])
    f=f.dropna(subset=['issue_time','ci95_conditional_start','ci95_conditional_end_exclusive'])
    if f['issue_time'].duplicated().any(): raise ValueError('预测发布时间重复，无法唯一选择事前预测')
    f=f.sort_values('issue_time').copy()
    f['issue_date']=f['issue_time'].dt.normalize()
    split_date_bounds=f.groupby('split')['issue_date'].agg(['min','max']).to_dict('index')
    e['event_date']=dt(e['event_date']).dt.normalize()
    e=e.dropna(subset=['event_date']).drop_duplicates(subset=['event_date']).sort_values('event_date')
    e['event_date_str']=e['event_date'].dt.strftime('%Y-%m-%d')
    # 只选择事件前一天零点发行的那一条：此规则预先固定，不比较多个窗口选择最优结果。
    records=[]
    for _, er in e.iterrows():
        day=er['event_date']; start=day;end=day+pd.Timedelta(days=1)
        intended=day-pd.Timedelta(days=1)
        cand=f.loc[f['issue_time'].eq(intended)]
        if cand.empty:
            records.append(dict(event_date=er['event_date_str'],split='outside_or_missing',
                prespecified_issue_time=str(intended), prediction_available=False,
                warning=None, coverage_status='not_evaluable_no_forecast',
                overlap_hours=np.nan, fuzzy_uniform_coverage=np.nan,
                lower_cover=np.nan, upper_cover=np.nan, note='不计入覆盖率分母'))
            continue
        r=cand.iloc[0]; ps=r['ci95_conditional_start'];pe=r['ci95_conditional_end_exclusive']
        b=split_date_bounds.get(r['split'])
        if b is None or not(b['min'] <= day <= b['max']):
            records.append(dict(event_date=er['event_date_str'],split='boundary_excluded',
                prespecified_issue_time=str(intended), prediction_available=False,
                warning=None, coverage_status='event_outside_split_dates',
                overlap_hours=np.nan,fuzzy_uniform_coverage=np.nan,
                lower_cover=np.nan,upper_cover=np.nan,
                note='该事件日位于发行预测所属分组的日期范围外，不纳入分组覆盖率'))
            continue
        # 条件95%区间须包含在该预测的预报时域之内，空区间非法。
        if not ps < pe: raise ValueError(f'无效时间区间: {r.issue_time}')
        status, overlap, fuzzy=classify(start,end,ps,pe)
        records.append(dict(event_date=er['event_date_str'],split=r['split'],
            prespecified_issue_time=str(intended),prediction_available=True,
            warning=bool(r['warning']),predicted_interval_start=str(ps),
            predicted_interval_end_exclusive=str(pe),
            event_day_start=str(start),event_day_end_exclusive=str(end),
            coverage_status=status,overlap_hours=round(overlap,6),
            fuzzy_uniform_coverage=round(fuzzy,8),
            lower_cover=int(status=='definitely_covered'),
            upper_cover=int(status!='definitely_not_covered'),
            note='仅条件于预报时域内有事件；fuzzy假设日期内均匀，不是实测覆盖率'))
    result=pd.DataFrame(records)
    result.to_csv(out/'event_level_interval_censoring.csv',index=False,encoding='utf-8-sig')
    summary={}
    for split in ['train','test']:
        s=result[(result['split']==split)&result['prediction_available'].eq(True)].copy()
        n=len(s)
        lo=float(s.lower_cover.mean()) if n else None
        hi=float(s.upper_cover.mean()) if n else None
        fuzzy=float(s.fuzzy_uniform_coverage.mean()) if n else None
        summary[split]={
            'n_distinct_event_dates':n,
            'n_full_cover':int((s.coverage_status=='definitely_covered').sum()),
            'n_partial':int((s.coverage_status=='partially_overlaps_unknown').sum()),
            'n_no_overlap':int((s.coverage_status=='definitely_not_covered').sum()),
            'coverage_lower_bound':lo,'coverage_upper_bound':hi,
            'uniform_within_day_fuzzy_weighted_coverage':fuzzy,
            'n_prior_warning':int(s.warning.sum()) if n else 0,
            'warning_rate_for_event_dates':float(s.warning.mean()) if n else None,
        }
    pd.DataFrame([dict(split=k,**v) for k,v in summary.items()]).to_csv(out/'coverage_summary.csv',index=False,encoding='utf-8-sig')
    # 窗口级另附描述性审计，不纳入事件级覆盖率计算，防止重复事件计数。
    rows=[]
    dates=set(e['event_date'])
    for _, r in f.iterrows():
        issued=r.issue_time; ps=r.ci95_conditional_start; pe=r.ci95_conditional_end_exclusive
        for day in sorted(d for d in dates if issued < d+pd.Timedelta(days=1) and d < issued+pd.Timedelta(hours=48)):
            status, overlap, fuzzy=classify(day,day+pd.Timedelta(days=1),ps,pe)
            rows.append(dict(split=r['split'],issue_time=str(issued),event_date=str(day.date()),
                status=status,overlap_hours=overlap,uniform_weight=fuzzy,
                warning=bool(r.warning)))
    pd.DataFrame(rows).to_csv(out/'overlapping_issue_windows_descriptive_only.csv',index=False,encoding='utf-8-sig')
    # 新上传的全国道路清单，只用于吉隆日期交叉核对，不能直接并入独立事件/训练标签。
    supp=Path(args.supplement) if args.supplement else root/'泥石流(2).csv'
    extra={'available':False}
    if supp.exists():
        z=read_csv(supp)
        extra['available']=True;extra['rows_total']=len(z)
        if '最近发生时间' in z.columns:
            x=dt(z['最近发生时间'])
            extra['rows_with_parsable_date']=int(x.notna().sum())
            extra['rows_with_explicit_hour']=int(z['最近发生时间'].astype(str).str.contains(r'\d{1,2}:\d{2}',regex=True).sum())
        gc=z.astype(str).apply(lambda s:s.str.contains('吉隆',na=False)).any(axis=1)
        q=z.loc[gc].copy();extra['rows_mentioning_gyirong']=len(q)
        if '最近发生时间' in q.columns:
            q['parsed_event_date']=dt(q['最近发生时间']).dt.strftime('%Y-%m-%d')
        q.to_csv(out/'supplement_gyirong_records_for_audit.csv',index=False,encoding='utf-8-sig')
    meta={'method':'event-level interval censoring, previous-day 00:00 prespecified issued forecast',
          'interval_end':'exclusive', 'summary':summary,'supplement':extra,
          'warnings':[
              '本方法是条件于48小时内有事件的95%区间，不能解释为无条件95%置信/覆盖保证',
              '模糊加权值假设事件在所记日期内均匀分布，不能作为已验证的小时级覆盖率',
              '只选事件前一天00:00预测以避免同一事件被重复计数；事件日期是事后用于评分，不参与预测计算',
              '测试期事件数极少；不能用测试事件调整区间或校准参数',
              '历史最近发生日期和吉隆道路清单不能直接视作完整独立发生时间标签']}
    (out/'method_and_summary.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding='utf-8')
    print('[完成]',out)
    for split,v in summary.items():
        print(f"{split} | 事件日期 {v['n_distinct_event_dates']} | 确定覆盖 {v['n_full_cover']} | 部分重叠 {v['n_partial']} | 确定未覆盖 {v['n_no_overlap']}")
        print('  覆盖率界限:',v['coverage_lower_bound'],v['coverage_upper_bound'],'均匀日内加权(假设):',v['uniform_within_day_fuzzy_weighted_coverage'])
    print('注意：上述模糊加权值不是真实小时级覆盖率。')

if __name__=='__main__':
    main()
