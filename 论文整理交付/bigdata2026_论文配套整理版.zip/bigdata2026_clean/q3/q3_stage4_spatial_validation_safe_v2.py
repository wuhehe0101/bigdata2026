# -*- coding: utf-8 -*-
"""Q3 Stage 4 (safe V2): D8 path and spatial sensitivity, UTM CSV only.
No Matplotlib, scipy, pyproj Transformer, or CRS conversion.
Put this script and three rasters together in Q3 and click Run in PyCharm.
"""
from pathlib import Path
import argparse
import csv
import json
import math
import numpy as np
import rasterio

SITES = {'A': (355000.0, 3130500.0), 'B': (356000.0, 3129500.0)}
PORT = (340500.0, 3129500.0)
D8 = {64:(-1,0), 128:(-1,1), 1:(0,1), 2:(1,1), 4:(1,0), 8:(1,-1), 16:(0,-1), 32:(-1,-1)}
THRESHOLDS=(300,500,1000,2000)
BUFFERS=(100,200,300,500,1000)

def locate(base, explicit, names):
    if explicit:
        p=Path(explicit)
        if not p.is_file(): raise FileNotFoundError(str(p))
        return p
    for folder in (base,base.parent):
        for name in names:
            p=folder/name
            if p.is_file(): return p
    raise FileNotFoundError(f'没有找到文件 {names}。请放到 {base} 或使用命令行路径参数。')

def center(t,r,c):
    # Affine pixel-center conversion using only Python arithmetic.
    return (float(t.c + (c+0.5)*t.a + (r+0.5)*t.b),
            float(t.f + (c+0.5)*t.d + (r+0.5)*t.e))

def snap(t,shape,acc,valid,point,threshold,radius):
    # Invert affine using 2x2 arithmetic, no rasterio.index/transform helper.
    det=t.a*t.e-t.b*t.d
    if det==0: raise ValueError('栅格仿射变换无法求逆')
    dx,dy=point[0]-t.c,point[1]-t.f
    col=int(math.floor((t.e*dx-t.b*dy)/det))
    row=int(math.floor((-t.d*dx+t.a*dy)/det))
    if not (0<=row<shape[0] and 0<=col<shape[1]): raise ValueError(f'源区位置不在D8栅格内：{point}')
    px=min(abs(t.a),abs(t.e))
    span=int(math.ceil(radius/max(px,1e-8)))+2
    best=None
    for r in range(max(0,row-span),min(shape[0],row+span+1)):
        for c in range(max(0,col-span),min(shape[1],col+span+1)):
            if not valid[r,c] or acc[r,c]<threshold: continue
            x,y=center(t,r,c)
            dist=math.hypot(x-point[0],y-point[1])
            if dist<=radius and (best is None or dist<best[2]): best=(r,c,dist)
    return best

def trace(flow,valid,start,maxsteps=250000):
    r,c=start
    seen=set(); path=[]
    height,width=flow.shape
    for _ in range(maxsteps):
        if not (0<=r<height and 0<=c<width): return path,'outside_raster'
        if not valid[r,c]: return path,'invalid_dem'
        if (r,c) in seen: return path,'flow_cycle'
        seen.add((r,c));path.append((r,c))
        code=int(flow[r,c]);step=D8.get(code)
        if step is None:return path,'invalid_or_sink_direction_'+str(code)
        nr,nc=r+step[0],c+step[1]
        if not (0<=nr<height and 0<=nc<width):return path,'raster_boundary'
        if not valid[nr,nc]:return path,'edge_nodata'
        r,c=nr,nc
    return path,'max_steps'

def write_csv(path,rows,headers):
    with open(path,'w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=headers,extrasaction='ignore');w.writeheader();w.writerows(rows)

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--dem');ap.add_argument('--d8');ap.add_argument('--acc');ap.add_argument('--out')
    ap.add_argument('--snap-radius',type=float,default=500.0)
    args=ap.parse_args();base=Path(__file__).resolve().parent
    out=Path(args.out) if args.out else base/'Q3_stage4_results'
    out.mkdir(parents=True,exist_ok=True)
    demfile=locate(base,args.dem,['DEM_UTM45N_30m.tif','DEM_UTM45N.tif'])
    d8file=locate(base,args.d8,['D8流向.tif'])
    accfile=locate(base,args.acc,['汇流累积_像元数.tif'])
    print('[1/6] 读取栅格',flush=True)
    with rasterio.open(d8file) as ds, rasterio.open(accfile) as ac, rasterio.open(demfile) as el:
        if ds.crs is None or ds.crs.to_epsg()!=32645:raise ValueError('D8需为EPSG:32645')
        if (ds.width,ds.height,ds.transform,ds.crs)!=(ac.width,ac.height,ac.transform,ac.crs):raise ValueError('D8与汇流累积网格不一致')
        if (ds.width,ds.height,ds.transform,ds.crs)!=(el.width,el.height,el.transform,el.crs):
            raise ValueError('DEM与D8网格不一致。安全版不自动重投影；请使用与D8同源的DEM_UTM45N_30m.tif')
        transform=ds.transform
        flow=ds.read(1);acc=ac.read(1);dem=el.read(1)
        valid=np.isfinite(dem)
        if el.nodata is not None:valid &= dem!=el.nodata
        valid &= np.isfinite(acc)
        vals,counts=np.unique(flow,return_counts=True)
        print('D8编码计数:',dict(zip([int(v) for v in vals],[int(c) for c in counts])),flush=True)
        print('[2/6] 栅格和坐标已核对；以下不调用坐标投影库',flush=True)
    audits=[];sensitivity=[];buffers=[];path_rows=[];primary_paths={}
    for site,point in SITES.items():
        for threshold in THRESHOLDS:
            print(f'[3/6] 源区{site} / 阈值{threshold}: 正在吸附',flush=True)
            start=snap(transform,flow.shape,acc,valid,point,threshold,args.snap_radius)
            if start is None:
                sensitivity.append({'source':site,'threshold':threshold,'status':'no_channel_within_radius'})
                print('      半径内无候选沟道',flush=True)
                continue
            r,c,snapdistance=start
            print(f'      起点行列: {r},{c}; 偏移 {snapdistance:.2f}m；正在追踪D8',flush=True)
            cells,reason=trace(flow,valid,(r,c))
            print(f'      追踪完成: {len(cells)}个像元, 终止={reason}; 正在计算距离',flush=True)
            if not cells:continue
            distance_sum=0.0;closest=float('inf');closest_idx=None;prev=None
            for index,(rr,cc) in enumerate(cells):
                x,y=center(transform,rr,cc)
                if prev is not None:distance_sum+=math.hypot(x-prev[0],y-prev[1])
                dist=math.hypot(x-PORT[0],y-PORT[1]);prev=x,y
                if dist<closest:closest=dist;closest_idx=index
                if threshold==1000:
                    path_rows.append({'source':site,'sequence':index,'row':rr,'col':cc,'x_utm':round(x,2),
                      'y_utm':round(y,2),'cum_distance_m':round(distance_sum,2),
                      'elevation_m':round(float(dem[rr,cc]),2),'accumulation_cells':int(acc[rr,cc]),
                      'distance_to_port_m':round(dist,2),'d8_code':int(flow[rr,cc])})
            sx,sy=center(transform,r,c)
            ex,ey=center(transform,*cells[-1])
            info={'source':site,'threshold':threshold,'status':'traced','start_x':round(sx,2),'start_y':round(sy,2),
              'start_to_approx_source_m':round(snapdistance,2),'start_accumulation_cells':int(acc[r,c]),
              'path_pixels':len(cells),'length_m':round(distance_sum,2),'min_distance_to_port_m':round(closest,2),
              'nearest_path_index':closest_idx,'end_reason':reason,'end_x':round(ex,2),'end_y':round(ey,2)}
            sensitivity.append(info)
            if threshold==1000:audits.append(info);primary_paths[site]=cells
            for radius in BUFFERS:buffers.append({'source':site,'threshold':threshold,'buffer_radius_m':radius,
              'intersects_buffer':closest<=radius,'min_distance_m':round(closest,2)})
            print(f'      路径 {distance_sum/1000:.3f}km；最近口岸 {closest:.2f}m',flush=True)
    print('[4/6] 保存CSV',flush=True)
    info_cols=['source','threshold','status','start_x','start_y','start_to_approx_source_m','start_accumulation_cells',
       'path_pixels','length_m','min_distance_to_port_m','nearest_path_index','end_reason','end_x','end_y']
    write_csv(out/'spatial_path_audit.csv',audits,info_cols)
    write_csv(out/'threshold_sensitivity.csv',sensitivity,info_cols)
    write_csv(out/'buffer_sensitivity.csv',buffers,['source','threshold','buffer_radius_m','intersects_buffer','min_distance_m'])
    write_csv(out/'d8_path_points.csv',path_rows,['source','sequence','row','col','x_utm','y_utm','cum_distance_m','elevation_m','accumulation_cells','distance_to_port_m','d8_code'])
    overlap=len(set(primary_paths['A'])&set(primary_paths['B'])) if all(k in primary_paths for k in SITES) else None
    summary={'stage':'4 / safe UTM-only spatial audit','inputs':{'dem':str(demfile),'d8':str(d8file),'acc':str(accfile)},
      'primary_audit':audits,'overlap_pixels_A_B_primary':overlap,'thresholds_cells':THRESHOLDS,'buffer_m':BUFFERS,
      'notes':['候选源区和口岸坐标均为近似值','仅输出UTM EPSG:32645 CSV，无WGS84 GeoJSON',
        'D8代表地形候选水文通道，不等于泥石流真实传播路径或灾害范围',
        '缓冲相交不等于口岸受灾，网格边缘终止不等于自然水文终点']}
    (out/'stage4_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
    print('[5/6] 写入完成',flush=True)
    print(json.dumps({'primary_audit':audits,'overlap_pixels_A_B_primary':overlap},ensure_ascii=False,indent=2),flush=True)
    print('[6/6] 完成：',out,flush=True)

if __name__=='__main__':
    main()
