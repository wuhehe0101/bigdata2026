# -*- coding: utf-8 -*-
"""MathorCup Q3 Stage 2: interval-censored daily event model.
Run directly in PyCharm. Only reads Stage 1 outputs; NO fabricated event hour.
Requirements: numpy, pandas, scikit-learn, matplotlib (optional figures).
"""
from pathlib import Path
import argparse
import json
import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score, average_precision_score, confusion_matrix

HERE = Path(__file__).resolve().parent
TRAIN_START, TRAIN_END = '2021-04-01', '2021-07-31'
TEST_START, TEST_END = '2021-08-16', '2021-09-30'
Q2_THRESHOLD = 0.5193085227


def resolve_input(folder):
    candidates = ([Path(folder)] if folder else []) + [HERE/'Q3_stage1_results', HERE/'Q3_stage1_fixed_validation', HERE.parent/'Q3_stage1_results']
    for path in candidates:
        if (path/'daily_score_and_labels.csv').is_file() and (path/'event_date_audit.csv').is_file():
            return path
    raise FileNotFoundError('找不到第一阶段结果，请确认 Q3_stage1_results 与脚本同目录，或传入 --stage1 完整路径。')


def to_float(v):
    return None if not np.isfinite(v) else float(v)


def conditional_quantile_hours(p, q):
    """Condition on event within 24 h, assume constant hourly hazard during day.
    F(t|event in day) = [1-(1-p)^(t/24)] / p, 0<=t<=24.
    """
    p = float(np.clip(p, 1e-10, 1-1e-10))
    return float(24 * np.log1p(-q*p) / np.log1p(-p))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--stage1', default=None, help='第一阶段结果目录')
    ap.add_argument('--out', default=None, help='输出目录')
    args = ap.parse_args()
    inp = resolve_input(args.stage1)
    out = Path(args.out) if args.out else HERE/'Q3_stage2_results'
    out.mkdir(parents=True, exist_ok=True)
    print('读取第一阶段结果：', inp.resolve())

    daily = pd.read_csv(inp/'daily_score_and_labels.csv', encoding='utf-8-sig', parse_dates=['date'])
    daily = daily.set_index('date').sort_index()
    audit = pd.read_csv(inp/'event_date_audit.csv', encoding='utf-8-sig')
    audit_dates = set(pd.to_datetime(audit['event_date']).dt.normalize())
    if not {'score', 'event_label'}.issubset(daily.columns):
        raise ValueError('第一阶段 daily_score_and_labels.csv 缺少 score/event_label 列')
    if daily.index.duplicated().any():
        raise ValueError('每日日期重复，请先检查第一阶段输出。')
    train = daily.loc[TRAIN_START:TRAIN_END].dropna(subset=['score']).copy()
    test = daily.loc[TEST_START:TEST_END].dropna(subset=['score']).copy()
    if len(train) == 0 or len(test) == 0 or train['event_label'].nunique() < 2:
        raise ValueError('训练或测试样本不足，不能拟合模型。')
    # IMPORTANT: the 93 training complete cases differ from the Q2 common 81-day comparison.
    # Frozen Q2 score is NOT refit. New daily probability calibration is exploratory.
    x_train = np.log(np.clip(train['score'].to_numpy(float),1e-8,1-1e-8) /
                     (1-np.clip(train['score'].to_numpy(float),1e-8,1-1e-8))).reshape(-1,1)
    x_test = np.log(np.clip(test['score'].to_numpy(float),1e-8,1-1e-8) /
                    (1-np.clip(test['score'].to_numpy(float),1e-8,1-1e-8))).reshape(-1,1)
    y_train = train['event_label'].to_numpy(int)
    y_test = test['event_label'].to_numpy(int)
    # Equivalent to a discrete-time 24h constant-hazard interval-censored Bernoulli likelihood.
    # Background dates are assumed event-free only for this EXPLORATORY sensitivity fit.
    clf = LogisticRegression(C=0.1, class_weight=None, solver='lbfgs', max_iter=3000)
    clf.fit(x_train, y_train)
    train['p_day_exploratory'] = clf.predict_proba(x_train)[:,1]
    test['p_day_exploratory'] = clf.predict_proba(x_test)[:,1]
    # Threshold for DAILY event classification determined on TRAIN ONLY.
    from sklearn.metrics import roc_curve
    fpr, tpr, thresholds = roc_curve(y_train, train['p_day_exploratory'])
    j = tpr - fpr
    valid = np.where(np.isfinite(thresholds))[0]
    thr = float(thresholds[valid[np.argmax(j[valid])]])
    test['predicted_event_day'] = (test['p_day_exploratory'] >= thr).astype(int)
    test['q2_midnight_alarm'] = (test['score'] >= Q2_THRESHOLD).astype(int)
    tn, fp, fn, tp = [int(v) for v in confusion_matrix(y_test,test['predicted_event_day'], labels=[0,1]).ravel()]

    # For each day, a prospective forecast issued at 00:00 uses ONLY the 00:00 score.
    # Assumed constant within-day hazard: NO post-issue meteorology is read.
    test['p_event_in_24h'] = test['p_day_exploratory']
    test['conditional_q025_hour'] = test['p_event_in_24h'].apply(lambda p:conditional_quantile_hours(p,.025))
    test['conditional_q975_hour'] = test['p_event_in_24h'].apply(lambda p:conditional_quantile_hours(p,.975))
    test['conditional_95_interval_start'] = [str(t+pd.Timedelta(hours=float(h))) for t,h in zip(test.index,test['conditional_q025_hour'])]
    test['conditional_95_interval_end'] = [str(t+pd.Timedelta(hours=float(h))) for t,h in zip(test.index,test['conditional_q975_hour'])]
    # Real event time lies somewhere in 00:00..24:00, cannot check exact cover.
    test['coverage_certain'] = 0
    test['coverage_possible'] = test['event_label'].astype(int)
    test['event_time_verified'] = False
    test['event_date_source_verified'] = False
    test['warning'] = '区间仅是恒定小时危险率假设下、以当日发生为条件的探索性分位数；不是已验证95%时间预测区间。'
    test.to_csv(out/'test_interval_forecasts.csv', encoding='utf-8-sig', index_label='date')
    train.to_csv(out/'train_daily_calibration.csv', encoding='utf-8-sig', index_label='date')

    # Time label audit. A 00:00 alarm at best leads event within [0,24) h.
    original = audit.copy()
    original['event_date'] = pd.to_datetime(original['event_date']).dt.normalize()
    keep = test[['p_event_in_24h','conditional_95_interval_start','conditional_95_interval_end','predicted_event_day']].copy()
    keep.index.name = 'event_date'
    events_test = original.merge(keep.reset_index(), on='event_date', how='left')
    events_test['test_date_in_scope'] = events_test['event_date'].between(pd.Timestamp(TEST_START),pd.Timestamp(TEST_END))
    events_test['midnight_alarm_lead_lower_hours'] = np.where(
        events_test['test_date_in_scope'] & events_test['midnight_score_available'] &
        (events_test['midnight_score'] >= Q2_THRESHOLD),0.0,np.nan)
    events_test['midnight_alarm_lead_upper_hours'] = np.where(
        events_test['test_date_in_scope'] & events_test['midnight_score_available'] &
        (events_test['midnight_score'] >= Q2_THRESHOLD),24.0,np.nan)
    events_test.to_csv(out/'event_lead_time_audit.csv', encoding='utf-8-sig', index=False)

    n_event_test = int(y_test.sum())
    # Conditional interval is strict subset of all 24 hours for p in (0,1), so no certain coverage.
    summary = {
      'stage':'2 / exploratory interval-censored time model',
      'stage1_input':str(inp.resolve()),
      'n_train_complete_days':int(len(train)),
      'train_event_days':int(y_train.sum()),
      'n_test_complete_days':int(len(test)),
      'test_event_days':n_event_test,
      'q2_frozen_model_unchanged':True,
      'calibration':{'name':'daily_event_logistic_on_frozen_Q2_logit','C':0.1,
                     'coef':float(clf.coef_[0,0]),'intercept':float(clf.intercept_[0]),
                     'training_threshold':thr},
      'test_exploratory_metrics':{
          'auc':to_float(roc_auc_score(y_test,test['p_day_exploratory'])) if len(set(y_test))==2 else None,
          'ap':to_float(average_precision_score(y_test,test['p_day_exploratory'])) if n_event_test else None,
          'tn':tn,'fp':fp,'fn':fn,'tp':tp},
      'test_interval_coverage_lower_bound':0.0 if n_event_test else None,
      'test_interval_coverage_upper_bound':1.0 if n_event_test else None,
      '95_percent_coverage_verified':False,
      'hourly_event_time_identifiable':False,
      'interval_definition':'Conditional on event in forecast 24h; constant hazard within day (UNVERIFIED assumption).',
      'limitations':[
        'Historical timestamps have day-level precision; each event hour is unknown.',
        'Dates without records are not verified no-event days; daily calibration assumes otherwise and is exploratory.',
        'Within-day hazard shape is not identifiable from day-only event labels. Do not interpret quantiles as independently validated.',
        'The 2021 test sample has only three recorded event days; coverage bounds [0,1] are uninformative.',
        'Forecasts use midnight Q2 score and constant future 24-hour hazard, not actual future observations or weather forecasts.',
        'Training 93 complete P72/D72 days differs from Q2 81 common-feature days.',
        'No causal inference about 2026 ice-collapse event follows from this daily rainfall-temperature model.'
      ]}
    (out/'stage2_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
    notes = '''第三问第二阶段：日期区间删失探索性校准\n\n模型：冻结第二问 P72+D72 每日00:00评分，拟合训练期事件日概率。\n假设：每个自然日内部恒定条件危险率；预测当日未来24h的条件触发时刻分位数。\n这只是无法从日期标签识别小时分布时采用的演示性假设，不是可靠的小时级95%预报。\n测试集中只有3个事件日，真实触发小时全部未知，故日期区间下的预测覆盖下界0、上界1，不能证明95%。\n无记录日期不保证无灾，故每日概率校准仍是探索性。\n结果文件：test_interval_forecasts.csv / event_lead_time_audit.csv / train_daily_calibration.csv / stage2_summary.json\n'''
    (out/'README_results.txt').write_text(notes,encoding='utf-8-sig')
    print(json.dumps(summary,ensure_ascii=False,indent=2))
    print('输出：',out.resolve())

if __name__ == '__main__':
    main()
