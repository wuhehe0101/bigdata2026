# -*- coding: utf-8 -*-
"""Q3 Stage 7 — exploratory static glacier screening (no plotting / GDAL).
Put this script and the glacier .nc in the Q3 folder; run it directly in PyCharm.
Dependencies: numpy, pandas, h5py. Install: python -m pip install h5py pandas numpy
"""
from pathlib import Path
import argparse, json
import numpy as np
import pandas as pd
import h5py

SOURCES = {'A': (355000.0, 3130500.0), 'B': (356000.0, 3129500.0)}
VARIABLES = ('dem','slope','thickness','v','v_amp')
# Equal weights are an explicit exploratory choice, NOT learned/calibrated probabilities.
WEIGHTS = {'slope': 0.25, 'thickness': 0.25, 'v': 0.25, 'v_amp': 0.25}

def find_nc(arg, root):
    if arg:
        p=Path(arg)
        if not p.is_file(): raise FileNotFoundError(f'未找到 NetCDF: {p}')
        return p
    matches = sorted(root.glob('*.nc'))
    if not matches: matches = sorted(root.parent.glob('*.nc'))
    if not matches: raise FileNotFoundError('Q3及其上一级没有.nc文件；用 --nc 指定完整路径')
    if len(matches)>1: raise ValueError(f'发现多个nc文件，请用 --nc 明确指定：{matches}')
    return matches[0]

def rank_percentiles(values, valid):
    vals=values[valid]
    # Empirical mid-rank percentile, bounded in [0,1]
    s=pd.Series(vals)
    ranks=s.rank(method='average', pct=True).to_numpy(dtype=float)
    result=np.full(values.shape,np.nan,dtype=float)
    result[valid]=ranks
    return result

def nearest_valid(x,y,xx,yy,mask):
    rr,cc=np.where(mask)
    if len(rr)==0:return None
    d2=(xx[cc]-x)**2+(yy[rr]-y)**2
    j=int(np.argmin(d2)); return int(rr[j]),int(cc[j]),float(np.sqrt(d2[j]))

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--nc',default=None,help='NetCDF完整路径；不指定则自动在Q3寻找')
    parser.add_argument('--out',default=None,help='结果目录')
    parser.add_argument('--near-radius',type=float,default=500.0,help='源区附近筛查半径(m)')
    a=parser.parse_args()
    root=Path(__file__).resolve().parent
    nc=find_nc(a.nc,root)
    out=Path(a.out) if a.out else root/'Q3_stage7_results'
    out.mkdir(parents=True,exist_ok=True)
    print('[1/5] 读取:',nc,flush=True)
    with h5py.File(nc,'r') as f:
        needed=VARIABLES+('x','y','glacier_mask')
        absent=[k for k in needed if k not in f]
        if absent: raise ValueError('NC缺少字段：'+','.join(absent))
        arrays={k:np.asarray(f[k][()],dtype=float) for k in needed}
        crs=f['spatial_ref'].attrs.get('spatial_ref','') if 'spatial_ref' in f else ''
    if '32645' not in str(crs): raise ValueError('NetCDF坐标系不是预期UTM EPSG:32645，停止坐标比较')
    xx,yy=arrays['x'],arrays['y']
    shape=(len(yy),len(xx))
    if any(arrays[k].shape!=shape for k in VARIABLES+('glacier_mask',)):
        raise ValueError('变量维度与x/y不一致')
    print('[2/5] 校验掩膜及有效像元',flush=True)
    gm=arrays['glacier_mask']
    print('glacier_mask unique:',np.unique(gm[np.isfinite(gm)])[:20],flush=True)
    # Support only finite positive mask; do not assume nodata=0 means glacier.
    glacier=np.isfinite(gm)&(gm>0)
    physical=(np.isfinite(arrays['thickness'])&(arrays['thickness']>=0)&
              np.isfinite(arrays['v'])&(arrays['v']>=0)&
              np.isfinite(arrays['v_amp'])&(arrays['v_amp']>=0)&
              np.isfinite(arrays['slope'])&(arrays['slope']>=0)&(arrays['slope']<=90))
    valid=glacier & physical
    if np.count_nonzero(valid)==0:raise ValueError('冰川掩膜与四项物理变量没有共同有效像元，请检查glacier_mask取值')
    print('共同有效冰川像元：',int(valid.sum()),flush=True)
    print('[3/5] 计算经验百分位综合指标',flush=True)
    pct={k:rank_percentiles(arrays[k],valid) for k in WEIGHTS}
    score=np.full(shape,np.nan)
    score[valid]=sum(WEIGHTS[k]*pct[k][valid] for k in WEIGHTS)
    # only valid glacier pixel rank classes, no claims of physical stability thresholds
    ranks=pd.Series(score[valid]).rank(pct=True,method='average').to_numpy()
    risk=np.full(shape,np.nan)
    risk[valid]=np.where(ranks>=0.9,3,np.where(ranks>=0.75,2,1))
    rr,cc=np.where(valid)
    pixels=pd.DataFrame({'x_utm_m':xx[cc],'y_utm_m':yy[rr],
                         **{k:arrays[k][valid] for k in VARIABLES},
                         'relative_score':score[valid],
                         'relative_class':risk[valid].astype(int)})
    pixels.to_csv(out/'glacier_pixels_screen.csv',index=False,encoding='utf-8-sig')
    stats=[]
    for key in VARIABLES:
        z=arrays[key][valid]
        stats.append({'variable':key,'n_common_valid':len(z),'min':float(np.min(z)),
                      'p10':float(np.percentile(z,10)),'median':float(np.median(z)),
                      'p90':float(np.percentile(z,90)),'max':float(np.max(z))})
    pd.DataFrame(stats).to_csv(out/'glacier_variable_stats.csv',index=False,encoding='utf-8-sig')
    print('[4/5] 源区附近比较',flush=True)
    summaries=[]
    for name,(sx,sy) in SOURCES.items():
        distance=np.hypot(xx[None,:]-sx, yy[:,None]-sy)
        nearby=valid&(distance<=a.near_radius)
        best=nearest_valid(sx,sy,xx,yy,valid)
        row={'source':name,'source_x_utm_m':sx,'source_y_utm_m':sy,
             'search_radius_m':a.near_radius,'nearby_glacier_pixels':int(nearby.sum()),
             'nearby_score_median':float(np.median(score[nearby])) if nearby.any() else None,
             'nearby_score_p90':float(np.percentile(score[nearby],90)) if nearby.any() else None,
             'nearby_top10pct_pixels':int(((risk==3)&nearby).sum()),
             'nearest_valid_glacier_distance_m':best[2] if best else None}
        if best:
            r,c,_=best
            row.update({'nearest_x_utm_m':float(xx[c]),'nearest_y_utm_m':float(yy[r]),
                        'nearest_score':float(score[r,c]),
                        'nearest_class':int(risk[r,c])})
        summaries.append(row)
        print(f'  {name}: {int(nearby.sum())}个有效像元，最近有效像元距近似源区{best[2]:.1f}m' if best else f'  {name}: 无有效像元',flush=True)
    pd.DataFrame(summaries).to_csv(out/'source_neighborhood_audit.csv',index=False,encoding='utf-8-sig')
    counts=pd.Series(risk[valid].astype(int)).value_counts().sort_index()
    summary={'stage':7,'nc_file':str(nc),'grid_shape':list(shape),'crs':'EPSG:32645',
             'glacier_mask_positive_pixels':int(glacier.sum()),'common_valid_pixels':int(valid.sum()),
             'weights':WEIGHTS,'classes':{'1':'lower relative rank (<75th percentile)',
              '2':'higher relative rank (75–90th percentile)','3':'top relative 10% (>=90th percentile)'},
             'class_counts':{str(int(k)):int(v) for k,v in counts.items()},
             'source_neighborhoods':summaries,
             'cautions':['纯静态经验相对指标，不是冰崩发生概率或物理失稳阈值。',
                         '气候态速度及季节振幅不是2026年灾前逐小时速度。',
                         '源区A/B仅是近似位置，不能等同于真实冰崩释放区。',
                         '本阶段不计算触发时间95%置信区间或预警提前量。']}
    (out/'stage7_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
    (out/'README_results.txt').write_text('第七阶段：基于冰川掩膜内四项变量的静态相对排序。\n'
      'glacier_pixels_screen.csv 每个共同有效冰川像元及指标。\n'
      'glacier_variable_stats.csv 指标描述统计。\n'
      'source_neighborhood_audit.csv 近似源区A/B与冰川栅格的邻近比较。\n'
      '重要：相对等级不等于真实冰崩概率，不能据此预测触发小时。\n',encoding='utf-8-sig')
    print('[5/5] 完成:',out,flush=True)
    print(json.dumps({'valid':summary['common_valid_pixels'],'class_counts':summary['class_counts'],
                      'source_neighborhoods':summaries},ensure_ascii=False,indent=2),flush=True)
if __name__=='__main__':main()
