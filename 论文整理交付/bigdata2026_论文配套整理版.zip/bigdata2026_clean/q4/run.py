from pathlib import Path
from dataclasses import replace
import pandas as pd
from q4_solver import Config,load_terrain,simulate
from q4_viz import save_all
R=Path(__file__).resolve().parent
if __name__=='__main__':
 rows=[]
 for grid in [90,60]:
  cfg=Config(grid_m=grid,duration_s=600,snapshot_s=10,initial_volume_m3=1.75e8,mu=.060,mu_late=.010,xi_mps2=5000,erosion_k=.000678,deposit_k_per_s=.0003,fluidization_after_s=100)
  terrain=load_terrain(R/'data/elevation_utm45n.tif',cfg)
  result=simulate(terrain,cfg,max_steps=15000,progress=lambda x:print(grid,round(x,2),flush=True))
  save_all(terrain,result,R/f'results_{grid}',html=grid==90)
  rows.append({'grid_m':grid,'arrival_s':result['first_port_frame_s'],**result['records'][-1]})
 pd.DataFrame(rows).to_csv(R/'grid_sensitivity.csv',index=False)
