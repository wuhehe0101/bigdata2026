# -*- coding: utf-8 -*-
"""命令行批量仿真，并生成中文论文图、CSV、栅格、离线HTML。"""
import argparse
import time
from pathlib import Path
from dataclasses import replace
import pandas as pd
from q4_solver import Config,load_terrain,simulate,OBSERVATIONS,PORT,PAPER_REFERENCE
from q4_viz import save_all

ROOT=Path(__file__).resolve().parent
DEFAULT_DEM=ROOT/'data'/'elevation_utm45n.tif'

def main():
    parser=argparse.ArgumentParser(description='2026年吉隆8·26文献约束二维动力学+三维动画，参数为情景假设')
    parser.add_argument('--dem',type=Path,default=DEFAULT_DEM)
    parser.add_argument('--output',type=Path,default=ROOT/'results')
    parser.add_argument('--grid',type=float,default=90)
    parser.add_argument('--duration',type=float,default=600)
    parser.add_argument('--snapshot',type=float,default=30)
    parser.add_argument('--volume',type=float,default=1.1e8)
    parser.add_argument('--mu',type=float,default=.20,help='初始库仑摩擦系数')
    parser.add_argument('--xi',type=float,default=1800,help='假设的Voellmy参数，单位m/s^2')
    parser.add_argument('--erosion-k',type=float,default=.003,help='经验侵蚀系数（非论文实测）')
    parser.add_argument('--deposit-k',type=float,default=.0003)
    parser.add_argument('--fluidize-after',type=float,default=100)
    parser.add_argument('--late-mu',type=float,default=.05)
    parser.add_argument('--sensitivity',action='store_true',help='额外运行多组假设情景')
    parser.add_argument('--fast',action='store_true',help='仅计算，不生成3D动画和论文图（测试用）')
    args=parser.parse_args()
    if args.grid<45 or args.duration<=0 or args.snapshot<=0 or args.volume<=0 or args.xi<=0:
        parser.error('网格≥45米，时间/体积/xi必须为正数')
    p=Config(grid_m=args.grid,duration_s=args.duration,snapshot_s=args.snapshot,
      initial_volume_m3=args.volume,mu=args.mu,xi_mps2=args.xi,
      erosion_k=args.erosion_k,deposit_k_per_s=args.deposit_k,
      fluidization_after_s=args.fluidize_after,mu_late=args.late_mu)
    print('1/4 加载EPSG:32645的真实DEM...')
    T=load_terrain(args.dem,p)
    print(f'格网 {T.z0.shape}，单元尺寸 {T.dx:.2f}×{T.dy:.2f}米；源区参考点：{PAPER_REFERENCE}')
    start=time.time()
    print('2/4 运行600秒等效仿真（时长以参数为准）...')
    R=simulate(T,p)
    print('基准情景完成，步数',R['steps'],'耗时',round(time.time()-start,2),'秒')
    scenarios=[]
    if args.sensitivity:
        print('3/4 计算不同摩擦与侵蚀参数（不代表已完成真实参数标定）...')
        plans=[('文献约束增强',p),
            ('固定μ0.20无侵蚀',replace(p,xi_mps2=500,fluidization_after_s=0,erosion_k=0,deposit_k_per_s=0)),
            ('流态化无侵蚀',replace(p,erosion_k=0,deposit_k_per_s=0)),
            ('较大后期摩擦',replace(p,mu_late=.12)),
            ('较低侵蚀系数',replace(p,erosion_k=.0015))]
        for label,pp in plans:
            r=R if pp==p else simulate(T,pp)
            last=r['records'][-1]
            scenarios.append({'情景名称':label,'初期mu':pp.mu,'后期mu':pp.mu_late if pp.fluidization_after_s>0 else pp.mu,
                'xi_m每s2':pp.xi_mps2,'侵蚀参数k':pp.erosion_k,
                '最大直线距离_km':last['最大累计直线距离_km'],
                '累计影响面积_km2':last['累计影响面积_km2'],
                '累计侵蚀_百万m3':last['累计侵蚀体积_m3']/1e6,
                '累计沉积_百万m3':last['累计沉积体积_m3']/1e6,
                '峰值流速_mps':last['全程峰值速度_mps'],
                '口岸300m内':last['口岸300米邻域是否达到'],
                '物质量误差百分比':last['物质量平衡相对误差']*100,
                '计算边界受影响':r['edge_wet_cells']})
            print(f'    {label}: 最大直线距{last["最大累计直线距离_km"]:.2f}km; 累计侵蚀{last["累计侵蚀体积_m3"]/1e6:.1f}百万m³')
    print('4/4 保存图片、GeoTIFF、表格和交互网页...')
    if args.fast:
        args.output.mkdir(parents=True,exist_ok=True)
        pd.DataFrame(R['records']).to_csv(args.output/'模拟过程时序.csv',index=False,encoding='utf-8-sig')
    else:
        info=save_all(T,R,args.output,scenarios=scenarios,html=True)
        import json
        obs=info['参考观测'];m=R['records'][-1]
        comparison=[
          ('初始体积_m3',obs['体积_m3'],p.initial_volume_m3,'输入值，直接使用论文估计'),
          ('初始平均厚度_m',obs['文献平均厚度_m'],info['初始格网平均厚度_m'],'论文为源区平均厚度，模型为初始均匀流层厚度'),
          ('峰值速度_mps',obs['文献撞击峰值速度_mps'],m['全程峰值速度_mps'],'论文为撞击附近峰速，模型为全域任一网格峰速；仅量级参照'),
          ('两段河谷侵蚀总量_m3',obs['文献两段河谷侵蚀体积_m3'],m['累计侵蚀体积_m3'],'论文限定两河段，模型是全计算域；范围不完全一致'),
          ('至口岸时间_约s',obs['文献到口岸时间_约s'],R['first_port_frame_s'],'未到达则留空，不能强制匹配'),
          ('口岸速度_mps',obs['文献口岸平均速度_mps'],None,'当前网格若未到达口岸，不能填入模拟口岸速度'),
          ('沿沟道传播距离_m',obs['文献沿程运动距离_m'],None,'模型报告最大平面直线距离，不与沿程距离直接作差'),
        ]
        pd.DataFrame(comparison,columns=['指标','论文参考值','模拟值','比较适用性']).to_csv(args.output/'文献观测与模拟结果对照.csv',index=False,encoding='utf-8-sig')
    print('结果路径：',args.output.resolve())
    print('最终结果：',R['records'][-1])
    print('触及域边界的格网数：',R['edge_wet_cells'])
    print('注意：实测源区轮廓、摩擦参数、三维冲击和冰水相变尚未标定；不能声称复现了真实灾害。')
if __name__=='__main__':main()
