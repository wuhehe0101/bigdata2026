# -*- coding: utf-8 -*-
"""生成自包含样式的离线结果门户；3D动画作为同目录子网页引入。"""
from pathlib import Path
import json
from html import escape
base=Path(__file__).resolve().parent
report=json.loads((base/'results'/'模型参数和结果.json').read_text(encoding='utf-8'))
r=report['最终结果']
html=f'''<!DOCTYPE html>
<html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>吉隆8·26 | 文献约束泥石流三维情景模拟</title>
<style>
:root{{--bg:#101724;--panel:#1a2536;--ink:#eef4fc;--muted:#9daec2;--accent:#58c4d1;--orange:#ffab63;}}
*{{box-sizing:border-box}}body{{margin:0;background:var(--bg);color:var(--ink);font-family:'Microsoft YaHei','PingFang SC',system-ui,sans-serif}}
nav{{height:62px;display:flex;align-items:center;justify-content:space-between;max-width:1500px;margin:auto;padding:0 28px;border-bottom:1px solid #25384b}}
nav .mark{{font-weight:750;letter-spacing:.6px}}nav a{{color:#9dd9e0;text-decoration:none;font-size:13px}}
main{{max-width:1500px;padding:20px 26px 80px;margin:auto}}
h1{{font-size:clamp(24px,3.2vw,36px);margin:16px 0 10px}}p{{line-height:1.75;color:var(--muted)}}.eyebrow{{color:var(--accent);font-size:13px;letter-spacing:2px;font-weight:700}}
.lead{{max-width:980px}}.note{{padding:15px 19px;border:1px solid #75573e;border-left:4px solid var(--orange);border-radius:10px;background:#332c28;color:#fbdabf;font-size:14px;line-height:1.7;margin:18px 0}}
.cards{{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:12px;margin:20px 0}}.card{{background:var(--panel);border:1px solid #2b3d52;border-radius:13px;padding:18px}}
.card .metric{{font-size:clamp(20px,2.2vw,31px);font-weight:760;letter-spacing:-.8px;color:#f4f9ff}}.card label{{display:block;margin-top:8px;font-size:12px;color:var(--muted)}}
.panel{{background:var(--panel);padding:18px;border:1px solid #2b3d52;border-radius:14px;margin:18px 0}}h2{{font-size:19px;margin:4px 0 14px}}
.viewer{{background:#fff;border-radius:10px;overflow:hidden}}iframe{{width:100%;height:770px;border:0;display:block}}
.tools{{display:flex;flex-wrap:wrap;gap:10px;margin:12px 0}}.tools a{{color:var(--ink);background:#2b4058;border:1px solid #42607a;text-decoration:none;padding:10px 15px;border-radius:8px;font-size:13px}}.tools a:hover{{background:#3a5a76}}
.images{{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px}}figure{{padding:0;margin:0;background:#fff;border-radius:8px;overflow:hidden}}figure img{{width:100%;display:block}}figcaption{{color:#415063;font-size:12px;padding:10px 14px}}
.tablebox{{overflow-x:auto}}table{{width:100%;border-collapse:collapse;min-width:610px}}td,th{{padding:12px;border-bottom:1px solid #32435a;text-align:left;font-size:13px;vertical-align:top}}th{{color:#a1d7df}}td{{color:#d3dfe9}}
small{{color:var(--muted);line-height:1.7}}footer{{margin-top:30px;color:var(--muted);font-size:12px}}
@media(max-width:1000px){{.cards{{grid-template-columns:repeat(3,1fr)}}iframe{{height:600px}}}}@media(max-width:700px){{.cards{{grid-template-columns:repeat(2,1fr)}}.images{{grid-template-columns:1fr}}nav{{padding:0 14px}}main{{padding:14px}}iframe{{height:520px}}}}
</style></head>
<body><nav><div class="mark">🏔️ 吉隆 · 8·26 | Q4 Simulation</div><a href="#method">模型说明 ↓</a></nav>
<main>
<div class="eyebrow">2026 MATHORCUP · 第四问 · 文献约束情景仿真</div>
<h1>高位冰岩崩—泥石流三维动力学模拟</h1>
<p class="lead">基于吉隆地区真实30米DEM、文献反演源区、1.1亿m³初始物源，使用二维深度平均守恒模型求解，在三维地形中展示600秒运动过程。网页无需网络可直接打开；如需修改参数和重新求解，请启动项目内的Streamlit程序。</p>
<div class="note"><b>真实性提示：</b>本展示不是2026年灾害的已验证复现。流态化与侵蚀参数是假设，真实源区范围尚未经遥感勾绘；当前模拟<b>没有</b>在600秒内到达口岸。论文的沿沟道23km与模型的最大平面直线距离不是相同指标。</div>
<div class="cards">
  <div class="card"><div class="metric">{r['最大累计直线距离_km']:.2f} km</div><label>最大平面直线扩展距离</label></div>
  <div class="card"><div class="metric">{r['全程峰值速度_mps']:.1f} m/s</div><label>计算域历史最大速度</label></div>
  <div class="card"><div class="metric">{r['累计影响面积_km2']:.2f} km²</div><label>累计经过区域面积</label></div>
  <div class="card"><div class="metric">{r['累计侵蚀体积_m3']/1e6:.2f} M m³</div><label>模型累计经验侵蚀量</label></div>
  <div class="card"><div class="metric">未到达</div><label>600秒内是否抵达口岸邻域</label></div>
</div>
<section class="panel"><h2>可旋转三维DEM · 逐帧播放 / 暂停 / 时间轴</h2><div class="viewer"><iframe title="吉隆8·26三维运动动画" src="results/三维运动动画_离线网页.html" loading="eager"></iframe></div>
<div class="tools"><a href="results/三维运动动画_离线网页.html" target="_blank">独立打开三维动画 ↗</a><a href="results/模拟过程时序.csv">下载时序CSV</a><a href="results/模型参数和结果.json">下载参数与结果JSON</a><a href="README_运行说明.md">查看README使用说明</a></div></section>
<section class="panel"><h2>计算结果 · 中文论文图片</h2><div class="images">
<figure><img alt="真实地形与文献源区" src="results/图01_真实地形与文献源区.png"><figcaption>图1 真实地形、文献反演源区及口岸位置</figcaption></figure>
<figure><img alt="初始释放区及厚度" src="results/图02_初始源区与释放厚度.png"><figcaption>图2 源区矩形假设与初始释放厚度</figcaption></figure>
<figure><img alt="六时刻泥石流演化" src="results/图03_六时刻流深演化.png"><figcaption>图3 六时刻流深与运动路径变化</figcaption></figure>
<figure><img alt="速度流深峰值" src="results/图04_峰值流深与流速.png"><figcaption>图4 最大流深、最大流速分布</figcaption></figure>
<figure><img alt="动态指标与守恒" src="results/图05_时序与质量守恒.png"><figcaption>图5 动态指标与物质收支守恒</figcaption></figure>
<figure><img alt="摩擦与侵蚀敏感性" src="results/图07_参数敏感性.png"><figcaption>图7 多情景摩擦及侵蚀参数敏感性</figcaption></figure>
</div></section>
<section class="panel" id="method"><h2>观测约束与模型输出，分开解释</h2>
<div class="tablebox"><table><thead><tr><th>指标</th><th>论文报告的参考观测</th><th>本次数值情景</th></tr></thead><tbody>
<tr><td>源区</td><td>85°33′0″E、28°20′9″N（滑震初步反演）</td><td>按反演点居中的1000m×600m矩形，非真实源区边界</td></tr>
<tr><td>初始物源</td><td>约1.1亿m³；平均厚度约190m</td><td>输入1.1亿m³；初始平均流深约183.9m</td></tr>
<tr><td>侵蚀</td><td>两段河谷累计约5860万m³</td><td>全计算域经验侵蚀约{r['累计侵蚀体积_m3']/1e6:.2f}百万m³；空间范围不完全可比</td></tr>
<tr><td>传播</td><td>沿弯曲河谷约23km、7分多钟到达吉隆口岸</td><td>最大直线距离{r['最大累计直线距离_km']:.2f}km，600秒未达口岸；不是相同距离口径</td></tr>
<tr><td>速度</td><td>撞击峰速约67.6m/s；口岸平均约22m/s</td><td>全域峰速{r['全程峰值速度_mps']:.1f}m/s；没有可比较的模拟口岸速度</td></tr>
<tr><td>阻力</td><td>原论文未给出μ、ξ的数值标定</td><td>μ起始0.20、100秒后假设0.05、ξ=1800m/s²（非观测值）</td></tr>
</tbody></table></div><p><small>源论文：殷跃平等，《尼泊尔蓝塘里壤峰“8·26”冰岩崩致吉隆泥石流灾难研究》，2026年10月网络首发，DOI:10.16031/j.cghc.202610008。</small></p>
</section>
<footer>Q4文献约束情景仿真 · 结果由可复现Python程序计算 · EPSG:32645 · 完全离线浏览</footer>
</main></body></html>'''
(base/'index.html').write_text(html,encoding='utf-8')
print('Created',base/'index.html', 'chars',len(html))
