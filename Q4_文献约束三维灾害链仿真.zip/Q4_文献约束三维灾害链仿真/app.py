# -*- coding: utf-8 -*-
"""Streamlit可交互假设情景仿真，源区参考自2026文献，不代表经过标定的真实复现。"""
from pathlib import Path
import json
from dataclasses import replace
import streamlit as st
import pandas as pd
import numpy as np
import plotly.graph_objects as go
import streamlit.components.v1 as components
from q4_solver import Config,load_terrain,simulate,OBSERVATIONS,PAPER_REFERENCE,PORT
from q4_viz import plotly_scene,save_all

BASE=Path(__file__).resolve().parent
DEM=BASE/'data'/'elevation_utm45n.tif'
OUT=BASE/'results'

st.set_page_config(page_title='吉隆8·26 | 三维泥石流情景仿真',page_icon='🏔️',layout='wide')
st.markdown('''<style>
.block-container {padding-top:1.25rem;max-width:1600px}
.big {font-size:1.15rem;color:#586779}
section[data-testid="stSidebar"] {background:#f3f5f7}
</style>''',unsafe_allow_html=True)
st.title('🏔️ 吉隆“8·26”冰岩崩—泥石流三维情景仿真')
st.caption('真实30m DEM / 计算格网45–120m / 二维深度平均守恒方程 / 静水重构Rusanov / Voellmy摩擦 / 三维时间动画')
st.warning('**重要提示**：该程序是文献约束的假设情景，非2026年灾害的已验证复现。文献的源区坐标是初步反演点，不是实测释放多边形；摩擦和侵蚀参数均未在论文中直接给出。',icon='⚠️')

st.sidebar.header('⚙️ 物理参数控制台')
st.sidebar.markdown('**源区：** 文献反演参考点，85°33′E / 28°20′9″N')
st.sidebar.caption(f'EPSG:32645：({PAPER_REFERENCE[0]:.1f}, {PAPER_REFERENCE[1]:.1f}) m')
volume=st.sidebar.number_input('初始释放体积 / m³（文献约1.1亿）',min_value=1000000.,max_value=500000000.,value=110000000.,step=10000000.,format='%.0f')
mu=st.sidebar.slider('初期摩擦系数μ（假设）',.01,.40,.20,.01)
xi=st.sidebar.slider('Voellmy ξ / (m/s²)（假设）',200,4000,1800,100)
st.sidebar.markdown('**流态化情景（仍是假设）**')
staged=st.sidebar.checkbox('100秒后切换为较低摩擦',True)
after=st.sidebar.slider('流态化切换时刻 / s',30,250,100,10,disabled=not staged)
late=st.sidebar.slider('流态化后μ',.01,.30,.05,.01,disabled=not staged)
st.sidebar.markdown('**侵蚀夹带和沉积（经验源汇模型）**')
erosion=st.sidebar.slider('经验侵蚀系数 k',0.,.008,.003,.0005,format='%.4f')
dep=st.sidebar.slider('经验沉积系数 / s⁻¹',0.,.003,.0003,.0001,format='%.4f')
st.sidebar.markdown('**数值配置**')
duration=st.sidebar.slider('模拟时长 / s',120,1200,600,60)
grid=st.sidebar.selectbox('计算网格大小 / m（越细越慢）',[120,90,60,45],index=1)
snapshot=st.sidebar.selectbox('存储帧间隔 / s',[15,20,30,60],index=2)
stride=st.sidebar.selectbox('3D显示采样步长（不改变计算网格）',[1,2,3,4],index=1)
start=st.sidebar.button('🚀 重新计算并更新三维动画',type='primary',use_container_width=True)
st.sidebar.caption('数值测试：python -m unittest discover -s tests -v')

cfg=Config(initial_volume_m3=volume,mu=mu,xi_mps2=xi,
           fluidization_after_s=float(after) if staged else 0.,
           mu_late=late,erosion_k=erosion,deposit_k_per_s=dep,
           duration_s=duration,grid_m=grid,snapshot_s=snapshot)

@st.cache_resource(show_spinner='读取EPSG:32645地形……')
def get_terrain(cell_size):
    return load_terrain(DEM,Config(grid_m=cell_size))

if start:
    bar=st.progress(0.,text='正在求解二维动力学……')
    try:
        terr=get_terrain(grid)
        result=simulate(terr,cfg,progress=lambda ratio:bar.progress(ratio,text=f'动力计算 {ratio:.0%}'))
        st.session_state['T']=terr
        st.session_state['R']=result
        st.session_state['cfg']=cfg
        bar.empty();st.success('本次情景计算完成；结果已更新。')
    except Exception as ex:
        bar.empty();st.error(f'{type(ex).__name__}: {ex}')

R=st.session_state.get('R');T=st.session_state.get('T')
precomputed=OUT/'三维运动动画_离线网页.html'
summaryfile=OUT/'模型参数和结果.json'
if R is not None:
    metrics=R['records'][-1]
elif summaryfile.exists():
    info=json.loads(summaryfile.read_text(encoding='utf-8'))
    metrics=info['最终结果']
else:metrics=None

if metrics:
    cs=st.columns(5)
    cs[0].metric('最大直线扩展距离',f'{metrics["最大累计直线距离_km"]:.2f} km')
    cs[1].metric('全程峰值流速',f'{metrics["全程峰值速度_mps"]:.1f} m/s')
    cs[2].metric('累计侵蚀',f'{metrics["累计侵蚀体积_m3"]/1e6:.1f} 百万m³')
    cs[3].metric('覆盖面积',f'{metrics["累计影响面积_km2"]:.2f} km²')
    cs[4].metric('抵达口岸300m', '是' if metrics['口岸300米邻域是否达到'] else '否')

view,plot,comparison,reference=st.tabs(['🌐 三维演化动画','📈 数值结果与导出','🗺️ 平面分布','📚 文献与模型限制'])
with view:
    if R is not None:
        st.plotly_chart(plotly_scene(T,R,stride),use_container_width=True,config={'displaylogo':False})
        st.caption('动画显示真实UTM XY和原始DEM海拔，泥石流可见网格上抬10m仅用于渲染；颜色代表模拟流深。')
    elif precomputed.exists():
        st.info('当前展示压缩包自带的预计算情景。修改参数后请点击左侧「重新计算」才会更新。')
        components.html(precomputed.read_text(encoding='utf-8'),height=800,scrolling=False)
    else:
        st.info('请点击左侧「重新计算」以生成三维动画。')
with plot:
    if R is not None:
        df=pd.DataFrame(R['records'])
        st.dataframe(df,use_container_width=True,hide_index=True)
        st.line_chart(df.set_index('时间_s')[['最大累计直线距离_km','累计影响面积_km2']])
        st.line_chart(df.set_index('时间_s')[['物质量平衡相对误差']])
        st.download_button('下载当前CSV结果',df.to_csv(index=False).encode('utf-8-sig'),file_name='模拟过程时序.csv',mime='text/csv')
        html=plotly_scene(T,R,stride).to_html(include_plotlyjs=True,full_html=True)
        st.download_button('下载当前三维动画离线HTML',html.encode('utf-8'),file_name='三维泥石流仿真.html',mime='text/html')
        if st.button('💾 将当前情景保存为论文图、GeoTIFF和网页',use_container_width=True):
            try:
                save_all(T,R,OUT)
                st.success(f'已保存：{OUT}')
            except Exception as e:st.error(str(e))
    elif metrics:
        st.dataframe(pd.read_csv(OUT/'模拟过程时序.csv'),hide_index=True,use_container_width=True)
with comparison:
    if R is not None:
        i=st.slider('选择时刻（保存帧）',0,len(R['frames'])-1,0)
        h=R['frames'][i]
        plotdata=np.where(T.valid & (h>=R['cfg'].wet_threshold_m),h,np.nan)
        f=go.Figure(go.Heatmap(x=T.x,y=T.y,z=plotdata,colorscale='YlOrRd',colorbar=dict(title='流深/m')))
        f.update_yaxes(scaleanchor='x',scaleratio=1)
        f.update_layout(title=f'第{i}帧：t={R["times"][i]:.0f}s',height=630,xaxis_title='UTM X / m',yaxis_title='UTM Y / m')
        st.plotly_chart(f,use_container_width=True)
    else:
        img=OUT/'图03_六时刻流深演化.png'
        if img.exists():st.image(str(img),caption='预计算的六时刻平面流深图')
with reference:
    st.markdown('''### 文献约束（已公开的量）
- 源区参考位置：85°33′0″E，28°20′9″N（滑震初步反演；非精确滑塌边界）
- 初始冰岩物源体积：约1.1×10⁸ m³；源区尺度约1000m ×600m、平均厚度约190m
- 撞击速度峰值约67.6m/s；沿程至口岸约23km、历时7分多钟
- 口岸附近平均流速约22m/s；普热普藏布与东林藏布两段河谷累计侵蚀约5.86×10⁷m³

**来源：** 殷跃平等（2026），《尼泊尔蓝塘里壤峰“8·26”冰岩崩致吉隆泥石流灾难研究》，DOI:10.16031/j.cghc.202610008。

### 模型假设与局限
1. 文献没有提供Voellmy μ、ξ的实测标定值；所有摩擦参数、沉积和侵蚀系数是情景参数。
2. 源区采用以反演点为中心的约1000×600m均匀释放矩形，并非源区实际遥感边界；DEM参考点高程与文献约5200m描述存在偏差。
3. 这是深度平均单层浅流模型，未刻画块体凌空坠落、撞击/反弹、物质相变、孔隙水压力和泥石流—洪水级联过程。
4. 经验侵蚀在所有符合速度条件的格网开放，未使用实际沉积物分布和分段侵蚀测量区域，不应据此推断真实侵蚀空间范围。
5. 计算域边界封闭；若流动到达边界，反射可能影响预测结果。离线模型输出会报告边界受影响单元。
6. 模型最大直线距离不是文献的沿沟道23km。未达口岸则不得报告口岸到达时间或速度。
7. 2026附件DEM未确认是灾前DEM；如果属于灾后地形，会影响真实运动反演。
''')
    st.json({'文献参考':OBSERVATIONS,'当前可调假设':cfg.__dict__},expanded=False)
