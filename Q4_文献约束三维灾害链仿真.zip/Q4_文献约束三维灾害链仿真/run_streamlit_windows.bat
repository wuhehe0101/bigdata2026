@echo off
chcp 65001 >nul
cd /d "%~dp0"
call conda activate math_model
if errorlevel 1 (
    echo [错误] 当前终端无法执行conda activate。
    echo 请在Anaconda Prompt中激活math_model环境，再运行：streamlit run app.py
    pause
    exit /b 1
)
python -m streamlit run app.py
if errorlevel 1 pause
