# -*- coding: utf-8 -*-
"""
吉隆县问题一：土地覆盖分类编码核查 + 历史灾害多边形DEM覆盖诊断
运行前确认“附件”目录与本脚本中的 PROJECT_DIR 一致。
本脚本只读取原始数据，并在 Question1_CrossValidation 下生成新报告，不修改原始文件。
"""

from pathlib import Path
import warnings
import json
import re
import numpy as np
import pandas as pd
import rasterio
from rasterio.features import geometry_mask
from rasterio.windows import from_bounds
from shapely.geometry import shape, box
from shapely.ops import transform as shapely_transform
import geopandas as gpd

PROJECT_DIR = Path(r"D:\pythonProjects\mother_model\问题一")
ATTACH_DIR = Path(r"D:\pythonProjects\mother_model\附件")
OUT_DIR = PROJECT_DIR / "Question1_CrossValidation"
OUT_DIR.mkdir(parents=True, exist_ok=True)

def find_file(folder_prefix, suffixes, preferred_contains=None):
    folders = [p for p in ATTACH_DIR.iterdir() if p.is_dir() and p.name.startswith(folder_prefix)]
    if not folders:
        raise FileNotFoundError(f"找不到附件目录前缀：{folder_prefix}，请检查：{ATTACH_DIR}")
    candidates = []
    for folder in folders:
        for p in folder.rglob("*"):
            if p.is_file() and p.suffix.lower() in suffixes:
                candidates.append(p)
    if preferred_contains:
        preferred = [p for p in candidates if preferred_contains.lower() in p.name.lower()]
        if preferred:
            candidates = preferred
    if not candidates:
        raise FileNotFoundError(f"在 {folders[0]} 下找不到扩展名 {suffixes} 的文件")
    # Prefer exact DEM / 2023 / shp where possible; deterministic choice
    candidates.sort(key=lambda p: (len(p.parts), len(p.name), p.name.lower()))
    return candidates[0]

def safe_num(x):
    try:
        return float(x)
    except Exception:
        return np.nan

def read_text_file(path):
    for enc in ("utf-8-sig", "utf-8", "gb18030", "gbk", "latin1"):
        try:
            return path.read_text(encoding=enc, errors="strict")
        except Exception:
            pass
    return ""

def main():
    dem_path = find_file("（7）", {".tif", ".tiff"}, "dem")
    lc_path = find_file("（5）", {".tif", ".tiff"}, "2023")
    shp_path = find_file("（6）", {".shp"}, "历史灾点")
    print("DEM：", dem_path)
    print("土地覆盖：", lc_path)
    print("历史灾害矢量：", shp_path)

    # 1) DEM coverage diagnostics for each historical polygon
    gdf = gpd.read_file(shp_path)
    if gdf.crs is None:
        raise ValueError("历史灾害 Shapefile 没有 CRS，不能安全地进行坐标转换。")
    with rasterio.open(dem_path) as dem:
        dem_crs = dem.crs
        dem_bounds = box(*dem.bounds)
        dem_nodata = dem.nodata
        dem_transform = dem.transform
        dem_width, dem_height = dem.width, dem.height
        dem_res = dem.res
        dem_bounds_tuple = tuple(dem.bounds)
        dem_array = None  # avoid loading the whole raster into memory
        if gdf.crs != dem_crs:
            gdf_dem = gdf.to_crs(dem_crs)
        else:
            gdf_dem = gdf.copy()

        rows = []
        for idx, row in gdf_dem.iterrows():
            geom = row.geometry
            orig = gdf.loc[idx]
            rec = {
                "记录索引": int(idx),
                "Name": str(orig.get("Name", "")),
                "Code": str(orig.get("Code", "")),
                "原始CRS": str(gdf.crs),
                "DEM_CRS": str(dem_crs),
                "几何为空": bool(geom is None or geom.is_empty),
                "几何有效": bool(geom.is_valid) if geom is not None else False,
                "几何类型": geom.geom_type if geom is not None else "",
                "几何修复前面积": safe_num(geom.area) if geom is not None else np.nan,
                "DEM范围矩形相交": False,
                "几何与DEM精确相交": False,
                "DEM范围内几何面积比例": 0.0,
                "窗口像元数": 0,
                "窗口内有效DEM像元数": 0,
                "窗口内NoData像元数": 0,
                "DEM高程最小值_m": np.nan,
                "DEM高程中位数_m": np.nan,
                "DEM高程最大值_m": np.nan,
                "诊断分类": ""
            }
            if geom is None or geom.is_empty:
                rec["诊断分类"] = "空几何"
                rows.append(rec)
                continue

            if not geom.is_valid:
                try:
                    geom = geom.buffer(0)
                except Exception:
                    pass
            if geom is None or geom.is_empty:
                rec["诊断分类"] = "几何无效且修复失败"
                rows.append(rec)
                continue

            bbox_intersects = geom.intersects(dem_bounds)
            exact_intersects = geom.intersection(dem_bounds).area > 0
            rec["DEM范围矩形相交"] = bool(bbox_intersects)
            rec["几何与DEM精确相交"] = bool(exact_intersects)
            if geom.area > 0:
                rec["DEM范围内几何面积比例"] = float(geom.intersection(dem_bounds).area / geom.area)

            if not bbox_intersects:
                rec["诊断分类"] = "完全位于DEM范围外"
                rows.append(rec)
                continue

            # Read only the raster window intersecting the polygon bbox
            minx, miny, maxx, maxy = geom.bounds
            left = max(minx, dem.bounds.left)
            bottom = max(miny, dem.bounds.bottom)
            right = min(maxx, dem.bounds.right)
            top = min(maxy, dem.bounds.top)
            if right <= left or top <= bottom:
                rec["诊断分类"] = "仅边界接触或无面积交集"
                rows.append(rec)
                continue
            win = from_bounds(left, bottom, right, top, transform=dem.transform)
            win = win.round_offsets().round_lengths()
            win = win.intersection(rasterio.windows.Window(0, 0, dem.width, dem.height))
            if win.width <= 0 or win.height <= 0:
                rec["诊断分类"] = "范围相交但未覆盖任何像元窗口"
                rows.append(rec)
                continue

            arr = dem.read(1, window=win, masked=False)
            win_transform = dem.window_transform(win)
            inside = geometry_mask([geom.__geo_interface__], out_shape=arr.shape,
                                   transform=win_transform, invert=True, all_touched=False)
            # Include all_touched pixels as a separate check to diagnose tiny/narrow polygons
            inside_touch = geometry_mask([geom.__geo_interface__], out_shape=arr.shape,
                                          transform=win_transform, invert=True, all_touched=True)
            valid_data = np.isfinite(arr)
            if dem_nodata is not None:
                try:
                    if np.isnan(dem_nodata):
                        valid_data &= ~np.isnan(arr)
                    else:
                        valid_data &= arr != dem_nodata
                except TypeError:
                    valid_data &= arr != dem_nodata
            valid_center = inside & valid_data
            valid_touch = inside_touch & valid_data
            rec["窗口像元数"] = int(arr.size)
            rec["窗口内有效DEM像元数"] = int(valid_center.sum())
            rec["窗口内NoData像元数"] = int((inside & ~valid_data).sum())
            if valid_center.sum():
                vals = arr[valid_center].astype(float)
                rec["DEM高程最小值_m"] = float(np.min(vals))
                rec["DEM高程中位数_m"] = float(np.median(vals))
                rec["DEM高程最大值_m"] = float(np.max(vals))

            if valid_center.sum() > 0:
                rec["诊断分类"] = "正常提取到有效像元"
            elif valid_touch.sum() > 0:
                rec["诊断分类"] = "多边形过窄/过小：中心像元法无像元，但all_touched可提取"
            elif not exact_intersects:
                rec["诊断分类"] = "仅DEM范围矩形附近相交，几何实际无面积交集"
            elif rec["DEM范围内几何面积比例"] < 0.999:
                rec["诊断分类"] = "部分超出DEM范围，且范围内没有有效中心像元"
            elif inside.sum() > 0 and (inside & ~valid_data).sum() == inside.sum():
                rec["诊断分类"] = "落入DEM范围但像元均为NoData"
            else:
                rec["诊断分类"] = "范围内未取到像元：需检查几何/栅格分辨率"
            rows.append(rec)

    diag_df = pd.DataFrame(rows)
    diag_csv = OUT_DIR / "15_DEM覆盖问题逐多边形诊断.csv"
    diag_df.to_csv(diag_csv, index=False, encoding="utf-8-sig")

    summary = (diag_df["诊断分类"].value_counts(dropna=False)
               .rename_axis("诊断分类").reset_index(name="多边形数量"))
    summary.to_csv(OUT_DIR / "16_DEM覆盖问题诊断汇总.csv", index=False, encoding="utf-8-sig")

    # 2) Land-cover raster metadata / labels / auxiliary files
    lc_rows = []
    with rasterio.open(lc_path) as lc:
        # GeoTIFF 不一定带颜色表；rasterio 在无颜色表时会抛 ValueError("NULL color table")
        cmap = {}
        cmap_exists = False
        if lc.count >= 1:
            try:
                cmap = lc.colormap(1)
                cmap_exists = bool(cmap)
            except (ValueError, RuntimeError):
                cmap = {}
                cmap_exists = False
            except Exception:
                cmap = {}
                cmap_exists = False

        meta = {
            "文件": str(lc_path),
            "CRS": str(lc.crs),
            "宽度": lc.width,
            "高度": lc.height,
            "波段数": lc.count,
            "数据类型": str(lc.dtypes),
            "NoData": str(lc.nodata),
            "分辨率": str(lc.res),
            "边界": str(tuple(lc.bounds)),
            "数据集标签": json.dumps(lc.tags(), ensure_ascii=False),
            "波段1标签": json.dumps(lc.tags(1), ensure_ascii=False),
            "颜色表是否存在": str(cmap_exists),
        }
        if cmap:
            for code, rgba in cmap.items():
                lc_rows.append({"类别代码": int(code), "元数据颜色表_RGBA": str(rgba),
                                "分类名称线索": "", "来源文件": str(lc_path)})
        arr = lc.read(1, masked=True)
        vals, counts = np.unique(arr.compressed(), return_counts=True)
        freq = pd.DataFrame({"类别代码": vals.astype(int), "全图像元数": counts.astype(np.int64)})
        freq["元数据颜色表_RGBA"] = ""
        freq["分类名称线索"] = ""
        freq["来源文件"] = str(lc_path)
        # Merge colormap where available
        cmap_dict = {r["类别代码"]: r["元数据颜色表_RGBA"] for r in lc_rows}
        if cmap_dict:
            freq["元数据颜色表_RGBA"] = freq["类别代码"].map(cmap_dict).fillna("")
        freq.to_csv(OUT_DIR / "17_土地覆盖代码频数与颜色表.csv", index=False, encoding="utf-8-sig")

    pd.DataFrame([meta]).to_csv(OUT_DIR / "18_土地覆盖栅格元数据.csv", index=False, encoding="utf-8-sig")

    # Search sibling files and text sidecars for classification legend clues
    lc_folder = lc_path.parent
    search_roots = {lc_folder}
    # Include the full landcover dataset folder
    for p in ATTACH_DIR.iterdir():
        if p.is_dir() and p.name.startswith("（5）"):
            search_roots.add(p)
    candidates = []
    text_suffixes = {".txt", ".csv", ".json", ".xml", ".md", ".prj", ".qml", ".sld", ".aux.xml"}
    for root in search_roots:
        for p in root.rglob("*"):
            if p.is_file():
                lower = p.name.lower()
                if p.suffix.lower() in text_suffixes or any(k in lower for k in ("readme", "legend", "class", "label", "metadata", "说明", "分类", "编码", "图例")):
                    candidates.append(p)
    keyword_pat = re.compile(r"(land.?cover|分类|编码|图例|legend|class|label|1\s*[:：=]\s*\S|10\s*[:：=]\s*\S)", re.I)
    clue_rows = []
    for p in sorted(set(candidates)):
        if p.resolve() == lc_path.resolve():
            continue
        if p.suffix.lower() not in {".txt", ".csv", ".json", ".xml", ".md", ".qml", ".sld"}:
            clue_rows.append({"文件": str(p), "发现的编码说明线索": "发现可能相关的辅助文件；非文本文件，需人工打开确认"})
            continue
        content = read_text_file(p)
        if not content:
            continue
        lines = content.splitlines()
        matched = [line.strip() for line in lines if keyword_pat.search(line)]
        if matched:
            clue_rows.append({"文件": str(p), "发现的编码说明线索": " | ".join(matched[:30])[:5000]})
    clue_df = pd.DataFrame(clue_rows, columns=["文件", "发现的编码说明线索"])
    clue_df.to_csv(OUT_DIR / "19_土地覆盖分类说明文件线索.csv", index=False, encoding="utf-8-sig")

    # 3) Concise summary
    class_counts = diag_df["诊断分类"].value_counts().to_dict()
    summary_text = [
        "吉隆县问题一：空间数据诊断摘要",
        f"DEM 文件：{dem_path}",
        f"土地覆盖文件：{lc_path}",
        f"历史灾害矢量：{shp_path}",
        f"DEM CRS：{dem_crs}",
        f"DEM 边界：{dem_bounds_tuple}",
        f"DEM NoData：{dem_nodata}",
        "",
        "DEM多边形诊断分类计数："
    ]
    for k, v in class_counts.items():
        summary_text.append(f"- {k}: {v}")
    summary_text += [
        "",
        f"土地覆盖栅格标签：{meta['数据集标签']}",
        f"土地覆盖波段标签：{meta['波段1标签']}",
        f"发现分类说明线索的文件数：{len(clue_df)}",
        "",
        "注意：若分类说明文件线索为空，不能据此推断类别含义；需回到数据集说明文档/数据提供方核实。"
    ]
    (OUT_DIR / "20_本次检查摘要.txt").write_text("\n".join(summary_text), encoding="utf-8-sig")

    print("\nDEM诊断分类：")
    print(summary.to_string(index=False))
    print("\n土地覆盖栅格标签：", meta["数据集标签"])
    print("土地覆盖波段标签：", meta["波段1标签"])
    print("分类说明线索文件数：", len(clue_df))
    print("\n全部完成，输出目录：", OUT_DIR)
    print("请优先把以下文件发回：")
    print("15_DEM覆盖问题逐多边形诊断.csv")
    print("16_DEM覆盖问题诊断汇总.csv")
    print("19_土地覆盖分类说明文件线索.csv")
    print("20_本次检查摘要.txt")

if __name__ == "__main__":
    warnings.filterwarnings("ignore", category=UserWarning)
    main()
