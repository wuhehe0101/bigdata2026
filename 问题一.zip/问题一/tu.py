# -*- coding: utf-8 -*-
"""
问题一论文图片生成脚本
输出：Question1_Figures/
图1-1 灾前72小时关键变量时间序列
图1-2 最终五因素综合评分与方向修正
图1-3 五因素暖季经验百分位
图1-4 去日变化Spearman相关热图
图1-5 降水专项对照
图1-6 最终五因素三类覆盖
"""

from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

BASE_DIR = Path(__file__).resolve().parent
INPUT_FILE = BASE_DIR / "clead.csv"
V8_DIR = BASE_DIR / "Question1_Model_Results_V8"
V81_DIR = BASE_DIR / "Question1_Model_Results_V8_1"
FIG_DIR = BASE_DIR / "Question1_Figures"
FIG_DIR.mkdir(exist_ok=True)

EVENT_TIME = pd.Timestamp("2026-08-26 10:00:00")

plt.rcParams["font.sans-serif"] = [
    "Microsoft YaHei", "SimHei", "Arial Unicode MS", "DejaVu Sans"
]
plt.rcParams["axes.unicode_minus"] = False

CANDIDATES = {
    "气温2m": ["MET_Ta_2m(degree C)", "MET_Ta_2m", "Ta_2m"],
    "VPD": ["FLUX_VPD(hPa)", "FLUX_VPD", "VPD(hPa)"],
    "短波向下": ["RADM_Rsd(W/m2)", "RADM_Rsd", "Rsd(W/m2)"],
    "短波向上": ["RADM_Rsu(W/m2)", "RADM_Rsu", "Rsu(W/m2)"],
    "长波向下": ["RADM_Rld(W/m2)", "RADM_Rld", "Rld(W/m2)"],
    "长波向上": ["RADM_Rlu(W/m2)", "RADM_Rlu", "Rlu(W/m2)"],
    "感热通量": ["FLUX_H(W/m2)", "FLUX_H", "H(W/m2)"],
    "土壤热通量": ["SOIL_G_0.1m(W/m2)", "SOIL_G_0.1m", "G_0.1m"],
}


def find_time_col(df):
    for c in ["Timestamp", "timestamp", "datetime", "DateTime", "time", "时间"]:
        if c in df.columns:
            return c
    hits = [c for c in df.columns if "timestamp" in str(c).lower() or "datetime" in str(c).lower()]
    if hits:
        return hits[0]
    raise ValueError("未找到时间列")


def find_col(df, candidates):
    for c in candidates:
        if c in df.columns:
            return c
    for cand in candidates:
        if len(cand) < 5:
            continue
        hits = [c for c in df.columns if cand.lower() in str(c).lower()]
        if len(hits) == 1:
            return hits[0]
    return None


def num(s):
    return pd.to_numeric(s, errors="coerce").replace([np.inf, -np.inf], np.nan)


def build_derived(df, cols):
    out = df.copy()
    rad = ["短波向下", "短波向上", "长波向下", "长波向上"]
    if all(cols.get(x) for x in rad):
        out["净辐射"] = (
            num(out[cols["短波向下"]]) - num(out[cols["短波向上"]])
            + num(out[cols["长波向下"]]) - num(out[cols["长波向上"]])
        )
    if cols.get("气温2m"):
        t = num(out[cols["气温2m"]])
        out["正积温24h"] = t.clip(lower=0).rolling(24, min_periods=18).sum()
    return out


def main():
    # ================= 图1-1 灾前72小时时间序列 =================
    try:
        df = pd.read_csv(INPUT_FILE, encoding="utf-8-sig", low_memory=False)
    except UnicodeDecodeError:
        df = pd.read_csv(INPUT_FILE, encoding="gbk", low_memory=False)

    time_col = find_time_col(df)
    df["_time"] = pd.to_datetime(df[time_col], errors="coerce")
    df = df.dropna(subset=["_time"]).sort_values("_time").drop_duplicates("_time").reset_index(drop=True)

    event_end = EVENT_TIME
    if not (df["_time"] == EVENT_TIME).any():
        prior = df.loc[df["_time"] <= EVENT_TIME, "_time"]
        if len(prior):
            event_end = prior.max()

    cols = {name: find_col(df, cand) for name, cand in CANDIDATES.items()}
    work = df.copy()
    for name, col in cols.items():
        if col:
            work[name] = num(work[col])
    work = build_derived(work, cols)

    plot_vars = ["正积温24h", "VPD", "净辐射", "感热通量", "土壤热通量"]
    recent = work[
        (work["_time"] >= event_end - pd.Timedelta(hours=72))
        & (work["_time"] <= event_end)
    ].copy()

    fig, axes = plt.subplots(3, 2, figsize=(12, 9))
    axes = axes.ravel()
    for i, var in enumerate(plot_vars):
        ax = axes[i]
        if var in recent.columns and recent[var].notna().any():
            ax.plot(recent["_time"], recent[var], linewidth=1.2, color="steelblue")
            ax.axvline(event_end, linestyle="--", color="red", linewidth=1)
            ax.set_title(var)
            ax.grid(alpha=0.25)
            ax.tick_params(axis="x", rotation=30)
        else:
            ax.text(0.5, 0.5, f"{var} 数据不足", ha="center", va="center")
            ax.set_axis_off()
    axes[-1].set_axis_off()
    fig.suptitle("灾前72小时关键变量时间序列", fontsize=14)
    fig.tight_layout()
    fig.savefig(FIG_DIR / "图1-1_灾前72小时关键变量时间序列.png", dpi=300)
    plt.close(fig)

    # ================= 图1-2 五因素评分与方向修正 =================
    score = pd.read_csv(V81_DIR / "03_方向与独立性修正后综合评分.csv", encoding="utf-8-sig")
    final5 = pd.read_csv(V81_DIR / "04_方向修正后最终五因素.csv", encoding="utf-8-sig")
    vars_final = final5["变量"].tolist()
    score_sub = score.set_index("变量").reindex(vars_final)

    fig, ax = plt.subplots(figsize=(10, 4.8))
    x = np.arange(len(vars_final))
    width = 0.36
    ax.bar(x - width/2, score_sub["S_综合评分"], width, label="V8 原评分", color="#9ecae1")
    ax.bar(x + width/2, score_sub["S_修正"], width, label="方向与独立性修正评分", color="#3182bd")
    ax.set_xticks(x)
    ax.set_xticklabels(vars_final, rotation=20, ha="right")
    ax.set_ylabel("综合评分")
    ax.set_ylim(0, 1.0)
    ax.set_title("最终五因素综合评分与方向修正")
    ax.legend()
    ax.grid(axis="y", alpha=0.25)
    fig.tight_layout()
    fig.savefig(FIG_DIR / "图1-2_最终五因素综合评分与方向修正.png", dpi=300)
    plt.close(fig)

    # ================= 图1-3 五因素暖季经验百分位 =================
    season = pd.read_csv(V8_DIR / "05_暖季多窗口滚动分布摘要.csv", encoding="utf-8-sig")
    season72 = season[
        (season["版本"] == "范围筛查敏感性版本")
        & (season["窗口小时"] == 72)
        & (season["变量"].isin(vars_final))
    ].set_index("变量").reindex(vars_final)

    three = pd.read_csv(V81_DIR / "05_最终五因素三类覆盖.csv", encoding="utf-8-sig")
    cls_map = dict(zip(three["变量"], three["三类归属"]))
    color_map = {
        "天气过程": "#3182bd",
        "极端气象事件": "#e6550d",
        "大气边界层结构": "#31a354",
        "辅助/下垫面": "#756bb1",
    }
    colors = [color_map.get(cls_map.get(v, ""), "#999999") for v in vars_final]

    fig, ax = plt.subplots(figsize=(9, 4.6))
    y = np.arange(len(vars_final))
    vals = season72["暖季经验百分位_pct"].values
    ax.barh(y, vals, color=colors)
    ax.axvline(50, linestyle="--", color="gray", linewidth=1)
    ax.axvline(90, linestyle=":", color="red", linewidth=1)
    ax.axvline(10, linestyle=":", color="blue", linewidth=1)
    ax.set_yticks(y)
    ax.set_yticklabels(vars_final)
    ax.set_xlim(0, 100)
    ax.set_xlabel("暖季经验百分位（%）")
    ax.set_title("最终五因素在暖季72小时滚动窗口中的经验百分位")
    for yi, val in zip(y, vals):
        ax.text(val + 1, yi, f"{val:.1f}%", va="center", fontsize=9)
    ax.grid(axis="x", alpha=0.25)
    fig.tight_layout()
    fig.savefig(FIG_DIR / "图1-3_五因素暖季经验百分位.png", dpi=300)
    plt.close(fig)

    # ================= 图1-4 去日变化Spearman相关热图 =================
    corr = pd.read_csv(V81_DIR / "01_去日变化Spearman相关矩阵.csv", encoding="utf-8-sig", index_col=0)
    fig, ax = plt.subplots(figsize=(max(10, len(corr) * 0.55), max(8, len(corr) * 0.45)))
    im = ax.imshow(corr.values, cmap="RdBu_r", vmin=-1, vmax=1)
    ax.set_xticks(range(len(corr.columns)))
    ax.set_yticks(range(len(corr.index)))
    ax.set_xticklabels(corr.columns, rotation=75, ha="right", fontsize=8)
    ax.set_yticklabels(corr.index, fontsize=8)
    ax.set_title("去日变化后 Spearman 相关矩阵（2021—2025 暖季）")
    fig.colorbar(im, ax=ax, fraction=0.025, pad=0.02)
    fig.tight_layout()
    fig.savefig(FIG_DIR / "图1-4_去日变化Spearman相关热图.png", dpi=300)
    plt.close(fig)

    # ================= 图1-5 降水专项对照 =================
    precip = pd.read_csv(V81_DIR / "06_降水专项结论.csv", encoding="utf-8-sig")
    fig, ax = plt.subplots(figsize=(8.5, 4.2))
    x = np.arange(len(precip))
    width = 0.26
    ax.bar(x - width, precip["事件降水统计值"], width, label="事件窗口", color="#e6550d")
    ax.bar(x, precip["历史同期中位数"], width, label="严格同期中位数", color="#3182bd")
    ax.bar(x + width, precip["暖季中位数"], width, label="暖季中位数", color="#31a354")
    ax.set_xticks(x)
    ax.set_xticklabels([f"{int(h)} h" for h in precip["窗口小时"]])
    ax.set_xlabel("窗口长度")
    ax.set_ylabel("降水量（mm）")
    ax.set_title("灾前降水专项对照：各窗口事件降水均为0 mm")
    ax.legend()
    ax.grid(axis="y", alpha=0.25)
    fig.tight_layout()
    fig.savefig(FIG_DIR / "图1-5_降水专项对照.png", dpi=300)
    plt.close(fig)

    # ================= 图1-6 五因素三类覆盖 =================
    three_plot = three.sort_values("候选顺序", ascending=True).copy()
    colors2 = [color_map.get(c, "#999999") for c in three_plot["三类归属"]]
    fig, ax = plt.subplots(figsize=(9, 4.6))
    y = np.arange(len(three_plot))
    ax.barh(y, three_plot["S_修正"], color=colors2)
    ax.set_yticks(y)
    ax.set_yticklabels(three_plot["变量"])
    ax.set_xlabel("方向与独立性修正后评分 S")
    ax.set_title("最终五因素及其三类归属")
    for yi, (_, row) in zip(y, three_plot.iterrows()):
        ax.text(row["S_修正"] + 0.005, yi, row["三类归属"], va="center", fontsize=8)
    ax.grid(axis="x", alpha=0.25)
    fig.tight_layout()
    fig.savefig(FIG_DIR / "图1-6_最终五因素三类覆盖.png", dpi=300)
    plt.close(fig)

    print("图片已输出到：", FIG_DIR)
    for p in sorted(FIG_DIR.glob("*.png")):
        print(p.name)


if __name__ == "__main__":
    main()