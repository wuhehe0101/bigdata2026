# -*- coding: utf-8 -*-
"""
问题一模型建立 V6：VPD异常时段定位 + 关键因素稳健性核查 + 最终候选报告

输入：本脚本同目录下 clead.csv
输出：Question1_Model_Results_V6 文件夹

注意：
1. 不修改、不覆盖 clead.csv。
2. 可疑值只做标记；“严格质量版本”对超出宽松范围的值设为 NaN，
   仅用于敏感性对照，不代表这些值必然错误。
3. 本程序是单次灾害案例的异常识别与候选因素筛选，不是灾害概率预测或因果证明。
4. 运行前请核对列名、变量单位和降水列定义。
"""

from pathlib import Path
import warnings
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

warnings.filterwarnings("ignore", category=RuntimeWarning)

# ====================== 配置 ======================
BASE_DIR = Path(__file__).resolve().parent
INPUT_FILE = BASE_DIR / "clead.csv"
OUT_DIR = BASE_DIR / "Question1_Model_Results_V6"

EVENT_TIME = pd.Timestamp("2026-08-26 10:00:00")
HIST_YEARS = [2021, 2022, 2023, 2024, 2025]
WINDOWS = [6, 24, 48, 72]

plt.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei", "Arial Unicode MS", "DejaVu Sans"]
plt.rcParams["axes.unicode_minus"] = False

# 按已知字段名匹配；匹配失败会写入 00_变量识别结果.csv
CANDIDATES = {
    "气温2m": ["MET_Ta_2m(degree C)", "MET_Ta_2m", "Ta_2m"],
    "相对湿度": ["MET_RH_2m(%)", "MET_RH_2m", "RH_2m"],
    "降水": ["MET_Precip(mm)", "MET_Precip", "Precip(mm)"],
    "VPD": ["FLUX_VPD(hPa)", "FLUX_VPD", "VPD(hPa)"],
    "气压": ["FLUX_PA(kPa)", "FLUX_PA", "PA(kPa)"],
    "风速2m": ["MET_WS_2m(m/s)", "MET_WS_2m", "WS_2m"],
    "风速10m": ["MET_WS_10m(m/s)", "MET_WS_10m", "WS_10m"],
    "风速20m": ["MET_WS_20m(m/s)", "MET_WS_20m", "WS_20m"],
    "温度1m": ["MET_Ta_1m(degree C)", "MET_Ta_1m", "Ta_1m"],
    "温度10m": ["MET_Ta_10m(degree C)", "MET_Ta_10m", "Ta_10m"],
    "温度20m": ["MET_Ta_20m(degree C)", "MET_Ta_20m", "Ta_20m"],
    "感热通量": ["FLUX_H(W/m2)", "FLUX_H", "H(W/m2)"],
    "潜热通量": ["FLUX_LE(W/m2)", "FLUX_LE", "LE(W/m2)"],
    "湍流动能": ["FLUX_TKE(m2/s2)", "FLUX_TKE", "TKE"],
    "摩擦速度": ["FLUX_ustar(m/s)", "FLUX_u_star(m/s)", "FLUX_ustar"],
    "短波向下": ["RADM_Rsd(W/m2)", "RADM_Rsd", "Rsd(W/m2)"],
    "短波向上": ["RADM_Rsu(W/m2)", "RADM_Rsu", "Rsu(W/m2)"],
    "长波向下": ["RADM_Rld(W/m2)", "RADM_Rld", "Rld(W/m2)"],
    "长波向上": ["RADM_Rlu(W/m2)", "RADM_Rlu", "Rlu(W/m2)"],
    "土壤含水量": ["SOIL_VWC_0.8m(m3/m3)", "SOIL_VWC_0.8m", "VWC_0.8m"],
    "土壤热通量": ["SOIL_G_0.1m(W/m2)", "SOIL_G_0.1m", "G_0.1m"],
}

# 宽松范围用于敏感性分析，必须结合设备说明/数据字典最终确认
RANGES = {
    "气温2m": (-45, 45),
    "相对湿度": (0, 100),
    "降水": (0, 300),
    "VPD": (0, 100),
    "气压": (500, 750),       # 先按观测站常见 kPa/hPa 数值范围做标记；若单位是 kPa，请修改
    "风速2m": (0, 60), "风速10m": (0, 60), "风速20m": (0, 60),
    "温度1m": (-45, 45), "温度10m": (-45, 45), "温度20m": (-45, 45),
    "短波向下": (-20, 1600), "短波向上": (-20, 1600),
    "长波向下": (0, 800), "长波向上": (0, 800),
    "土壤含水量": (0, 1),
    "湍流动能": (0, 100), "摩擦速度": (0, 10),
    "感热通量": (-1000, 1000), "潜热通量": (-1000, 1000),
    "土壤热通量": (-1000, 1000),
}

CATEGORY = {
    "VPD": "天气过程",
    "气温2m": "天气过程",
    "相对湿度": "天气过程",
    "降水": "天气过程",
    "气温1小时变化": "天气过程",
    "正积温24h": "天气过程",
    "短波向下": "极端气象与能量条件",
    "短波向上": "极端气象与能量条件",
    "长波向下": "极端气象与能量条件",
    "长波向上": "极端气象与能量条件",
    "净辐射": "极端气象与能量条件",
    "温度梯度2-10m": "大气边界层结构",
    "温度梯度2-20m": "大气边界层结构",
    "风速差20-2m": "大气边界层结构",
    "感热通量": "大气边界层结构",
    "潜热通量": "大气边界层结构",
    "湍流动能": "大气边界层结构",
    "摩擦速度": "大气边界层结构",
    "土壤含水量": "辅助下垫面指标",
    "土壤热通量": "辅助下垫面指标",
}

# 最终因素按物理意义分组，避免气温不同高度重复占位
GROUPS = {
    "温度与融化背景": ["气温2m", "气温1小时变化", "正积温24h"],
    "水汽条件": ["VPD", "相对湿度"],
    "辐射与能量条件": ["净辐射", "短波向下", "长波向上", "长波向下", "短波向上"],
    "边界层结构与湍流": ["温度梯度2-10m", "温度梯度2-20m", "风速差20-2m", "湍流动能", "摩擦速度", "感热通量", "潜热通量"],
    "降水过程": ["降水"],
    "下垫面条件": ["土壤含水量", "土壤热通量"],
}


def find_time_col(df):
    for c in ["Timestamp", "timestamp", "datetime", "DateTime", "time", "时间", "日期时间"]:
        if c in df.columns:
            return c
    hits = [c for c in df.columns if "timestamp" in str(c).lower() or "datetime" in str(c).lower()]
    if hits:
        return hits[0]
    raise ValueError("未找到时间列，请检查是否存在 Timestamp。")


def find_col(df, candidates):
    for c in candidates:
        if c in df.columns:
            return c
    # 只在唯一命中时采用模糊匹配，防止把相似字段错配
    for cand in candidates:
        if len(cand) < 5:
            continue
        hits = [c for c in df.columns if cand.lower() in str(c).lower()]
        if len(hits) == 1:
            return hits[0]
    return None


def num(series):
    return pd.to_numeric(series, errors="coerce").replace([np.inf, -np.inf], np.nan)


def mean(x):
    x = num(x).dropna()
    return float(x.mean()) if len(x) else np.nan


def med(x):
    x = num(x).dropna()
    return float(x.median()) if len(x) else np.nan


def robust_z(value, ref):
    ref = num(pd.Series(ref)).dropna()
    if len(ref) < 3 or pd.isna(value):
        return np.nan
    m = ref.median()
    mad = np.median(np.abs(ref - m))
    if mad > 0:
        return float((value - m) / (1.4826 * mad))
    sd = ref.std(ddof=1)
    return float((value - m) / sd) if sd > 0 else np.nan


def get_window(df, end, hours):
    start = end - pd.Timedelta(hours=hours - 1)
    return df[(df["_time"] >= start) & (df["_time"] <= end)].copy()


def mapped_end(year, event_end):
    return pd.Timestamp(year=year, month=event_end.month, day=event_end.day, hour=event_end.hour)


def build_derived(df, cols):
    out = df.copy()
    # 净辐射：Rn = Rsd - Rsu + Rld - Rlu
    rad = ["短波向下", "短波向上", "长波向下", "长波向上"]
    if all(cols.get(x) for x in rad):
        out["净辐射"] = num(out[cols["短波向下"]]) - num(out[cols["短波向上"]]) + num(out[cols["长波向下"]]) - num(out[cols["长波向上"]])
    if cols.get("温度10m") and cols.get("气温2m"):
        out["温度梯度2-10m"] = (num(out[cols["温度10m"]]) - num(out[cols["气温2m"]])) / 8
    if cols.get("温度20m") and cols.get("气温2m"):
        out["温度梯度2-20m"] = (num(out[cols["温度20m"]]) - num(out[cols["气温2m"]])) / 18
    if cols.get("风速20m") and cols.get("风速2m"):
        out["风速差20-2m"] = num(out[cols["风速20m"]]) - num(out[cols["风速2m"]])
    if cols.get("气温2m"):
        t = num(out[cols["气温2m"]])
        out["气温1小时变化"] = t.diff()
        out["正积温24h"] = t.clip(lower=0).rolling(24, min_periods=18).sum()
    return out


def main():
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    if not INPUT_FILE.exists():
        raise FileNotFoundError(f"找不到 {INPUT_FILE}。请将脚本放在 clead.csv 同目录。")

    try:
        df = pd.read_csv(INPUT_FILE, encoding="utf-8-sig", low_memory=False)
    except UnicodeDecodeError:
        df = pd.read_csv(INPUT_FILE, encoding="gbk", low_memory=False)

    time_col = find_time_col(df)
    df["_time"] = pd.to_datetime(df[time_col], errors="coerce")
    df = df.dropna(subset=["_time"]).sort_values("_time").drop_duplicates("_time").reset_index(drop=True)

    event_end = EVENT_TIME
    if not (df["_time"] == event_end).any():
        prior = df.loc[df["_time"] <= EVENT_TIME, "_time"]
        if prior.empty:
            raise ValueError("数据中没有事件时刻之前的记录。")
        event_end = prior.max()
        print(f"注意：没有精确的事件时刻，使用最近的前序记录 {event_end}")

    cols = {name: find_col(df, cand) for name, cand in CANDIDATES.items()}
    # 保存变量识别结果
    pd.DataFrame([{
        "分析变量": k, "原始列名": v or "", "识别成功": bool(v),
        "候选列名": "；".join(CANDIDATES[k])
    } for k, v in cols.items()]).to_csv(OUT_DIR / "00_变量识别结果.csv", index=False, encoding="utf-8-sig")

    # 原始变量数值副本；原数据不修改
    work = df.copy()
    for name, col in cols.items():
        if col:
            work[name] = num(work[col])
    work = build_derived(work, cols)

    # 宽松范围标记和质量敏感性版本
    # 关键修正：先筛查基础观测变量，再从筛查后的基础变量重新计算净辐射、温度梯度等派生量。
    qc_rows = []
    strict_base = work.copy()
    derived_names = {"净辐射", "温度梯度2-10m", "温度梯度2-20m",
                     "风速差20-2m", "气温1小时变化", "正积温24h"}
    for name, (lo, hi) in RANGES.items():
        if name not in work.columns:
            continue
        s = num(work[name])
        bad = (s < lo) | (s > hi)
        qc_rows.append({
            "变量": name, "有效值数": int(s.notna().sum()), "缺失数": int(s.isna().sum()),
            "下限": lo, "上限": hi, "低于下限数": int((s < lo).sum()),
            "高于上限数": int((s > hi).sum()), "范围外总数": int(bad.sum()),
            "范围外占有效值_pct": round(100 * bad.sum() / max(1, s.notna().sum()), 4),
            "说明": "宽松筛查范围，需结合设备说明确认；范围外值仅用于敏感性分析，不代表必然错误"
        })
        if name not in derived_names:
            strict_base[name] = s.mask(bad)

    # 从经过筛查的基础观测变量重新生成派生特征，避免派生量继续保留异常原始值影响
    strict = build_derived(strict_base, cols)

    # 对比派生变量原始值与严格版本变化情况，便于审计敏感性分析影响
    for name in ["净辐射", "温度梯度2-10m", "温度梯度2-20m",
                 "风速差20-2m", "气温1小时变化", "正积温24h"]:
        if name in work.columns and name in strict.columns:
            a, b = num(work[name]), num(strict[name])
            qc_rows.append({
                "变量": name, "有效值数": int(a.notna().sum()), "缺失数": int(a.isna().sum()),
                "下限": np.nan, "上限": np.nan, "低于下限数": np.nan,
                "高于上限数": np.nan,
                "范围外总数": int((a.notna() & b.isna()).sum()),
                "范围外占有效值_pct": round(100 * (a.notna() & b.isna()).sum() / max(1, a.notna().sum()), 4),
                "说明": "派生变量已基于筛查后的基础观测重新计算；该数为筛查后新增缺失数"
            })

    pd.DataFrame(qc_rows).to_csv(OUT_DIR / "01_变量质量核查.csv", index=False, encoding="utf-8-sig")

    # V5新增：VPD分布/缺失时段诊断。这里不自动断言单位，只输出待核查证据。
    vpd_diag_rows = []
    if "VPD" in work.columns:
        vpd_raw = num(work["VPD"])
        vpd_strict = num(strict["VPD"]) if "VPD" in strict.columns else vpd_raw
        vpd_diag_rows.append({
            "变量": "VPD",
            "原始有效数": int(vpd_raw.notna().sum()),
            "原始缺失数": int(vpd_raw.isna().sum()),
            "原始缺失率_pct": round(100 * vpd_raw.isna().mean(), 3),
            "原始最小值": vpd_raw.min(),
            "原始P01": vpd_raw.quantile(.01),
            "原始中位数": vpd_raw.median(),
            "原始P99": vpd_raw.quantile(.99),
            "原始最大值": vpd_raw.max(),
            "小于0数量": int((vpd_raw < 0).sum()),
            "大于100数量": int((vpd_raw > 100).sum()),
            "筛查版有效数": int(vpd_strict.notna().sum()),
            "筛查版缺失数": int(vpd_strict.isna().sum()),
            "事件前72h原始有效数": int(vpd_raw.loc[(work["_time"] >= event_end-pd.Timedelta(hours=71)) & (work["_time"] <= event_end)].notna().sum()),
            "事件前72h筛查版有效数": int(vpd_strict.loc[(strict["_time"] >= event_end-pd.Timedelta(hours=71)) & (strict["_time"] <= event_end)].notna().sum()),
            "说明": "仅按当前宽松范围0-100进行敏感性标记；须核对传感器/数据字典，不能仅凭范围判断单位或真伪"
        })
    pd.DataFrame(vpd_diag_rows).to_csv(OUT_DIR / "10_VPD专项诊断.csv", index=False, encoding="utf-8-sig")

    # V5新增：净辐射与向上长波辐射的多窗口表现、有效率和相关性对照。
    rad_rows = []
    for version_name, source in [("原始清洗值", work), ("范围筛查敏感性版本", strict)]:
        for var in ["净辐射", "长波向上"]:
            if var not in source.columns:
                continue
            for h in WINDOWS:
                ew = get_window(source, event_end, h)
                evs = num(ew[var])
                hist_means = []
                for yr in HIST_YEARS:
                    hw = get_window(source, mapped_end(yr, event_end), h)
                    hist_means.append(mean(hw[var]))
                hist_means = pd.Series(hist_means, dtype="float64").dropna()
                rad_rows.append({
                    "版本": version_name, "变量": var, "窗口小时": h,
                    "事件有效值数": int(evs.notna().sum()),
                    "事件有效率_pct": round(100*evs.notna().mean(), 2) if len(evs) else np.nan,
                    "事件均值": mean(evs),
                    "历史有效年份数": int(hist_means.count()),
                    "历史同期均值中位数": hist_means.median() if len(hist_means) else np.nan,
                    "事件减历史中位数": mean(evs)-hist_means.median() if len(hist_means) and pd.notna(mean(evs)) else np.nan,
                    "历史经验百分位_pct": 100*(hist_means < mean(evs)).mean() if len(hist_means) and pd.notna(mean(evs)) else np.nan,
                    "稳健异常分数": robust_z(mean(evs), hist_means)
                })
        if "净辐射" in source.columns and "长波向上" in source.columns:
            pair = pd.DataFrame({"Rn": num(source["净辐射"]), "Rlu": num(source["长波向上"])})
            pair = pair.replace([np.inf, -np.inf], np.nan).dropna()
            corr = pair["Rn"].corr(pair["Rlu"]) if len(pair) >= 3 else np.nan
            rad_rows.append({
                "版本": version_name, "变量": "净辐射与向上长波辐射相关性", "窗口小时": "全时段",
                "事件有效值数": len(pair), "事件有效率_pct": np.nan,
                "事件均值": np.nan, "历史有效年份数": np.nan,
                "历史同期均值中位数": np.nan, "事件减历史中位数": np.nan,
                "历史经验百分位_pct": np.nan, "稳健异常分数": np.nan,
                "全时段Pearson相关系数": corr,
                "配对有效记录数": len(pair)
            })
    pd.DataFrame(rad_rows).to_csv(OUT_DIR / "11_净辐射与长波向上对照.csv", index=False, encoding="utf-8-sig")


    # 分析变量清单
    vars_to_analyze = []
    for name in [
        "气温2m", "相对湿度", "降水", "VPD", "气压", "风速2m", "风速10m", "风速20m",
        "感热通量", "潜热通量", "湍流动能", "摩擦速度", "短波向下", "短波向上",
        "长波向下", "长波向上", "土壤含水量", "土壤热通量", "净辐射",
        "温度梯度2-10m", "温度梯度2-20m", "风速差20-2m", "气温1小时变化", "正积温24h"
    ]:
        if name in work.columns and work[name].notna().sum() > 0:
            vars_to_analyze.append(name)

    # 事件窗口：原始版本与严格范围敏感性版本
    event_rows = []
    event_cache = {}
    for version_name, source in [("原始清洗值", work), ("范围筛查敏感性版本", strict)]:
        for h in WINDOWS:
            w = get_window(source, event_end, h)
            for var in vars_to_analyze:
                s = num(w[var])
                row = {
                    "版本": version_name, "窗口小时": h, "变量": var,
                    "类别": CATEGORY.get(var, "辅助指标"), "记录数": len(w),
                    "有效值数": int(s.notna().sum()), "均值": mean(s), "中位数": med(s),
                    "最大值": float(s.max()) if s.notna().any() else np.nan,
                    "最小值": float(s.min()) if s.notna().any() else np.nan,
                }
                if var == "降水":
                    row["求和_需确认降水列定义"] = float(s.sum()) if s.notna().any() else np.nan
                event_rows.append(row)
                event_cache[(version_name, h, var)] = row
    pd.DataFrame(event_rows).to_csv(OUT_DIR / "02_事件多窗口统计_含敏感性对照.csv", index=False, encoding="utf-8-sig")

    # 历史同期：每年同月日同小时的同长度窗口
    hist_rows = []
    for version_name, source in [("原始清洗值", work), ("范围筛查敏感性版本", strict)]:
        for h in WINDOWS:
            for year in HIST_YEARS:
                end = mapped_end(year, event_end)
                w = get_window(source, end, h)
                for var in vars_to_analyze:
                    s = num(w[var])
                    hist_rows.append({
                        "版本": version_name, "年份": year, "窗口小时": h, "变量": var,
                        "记录数": len(w), "有效值数": int(s.notna().sum()),
                        "均值": mean(s), "中位数": med(s),
                        "降水求和_需确认定义": float(s.sum()) if var == "降水" and s.notna().any() else np.nan
                    })
    hist_df = pd.DataFrame(hist_rows)
    hist_df.to_csv(OUT_DIR / "03_逐年同期窗口_含敏感性对照.csv", index=False, encoding="utf-8-sig")

    # 事件与同期比较：按版本输出，比较事件均值与历年窗口均值分布
    comp_rows = []
    for version_name in ["原始清洗值", "范围筛查敏感性版本"]:
        for h in WINDOWS:
            for var in vars_to_analyze:
                ev = event_cache[(version_name, h, var)]
                hs = hist_df[(hist_df["版本"] == version_name) & (hist_df["窗口小时"] == h) & (hist_df["变量"] == var)]
                refs = num(hs["均值"]).dropna()
                rz = robust_z(ev["均值"], refs)
                comp_rows.append({
                    "版本": version_name, "窗口小时": h, "变量": var,
                    "类别": CATEGORY.get(var, "辅助指标"), "事件窗口均值": ev["均值"],
                    "事件有效值数": ev["有效值数"], "历史有效年份数": int(refs.count()),
                    "历史窗口均值中位数": refs.median() if len(refs) else np.nan,
                    "历史Q25": refs.quantile(.25) if len(refs) else np.nan,
                    "历史Q75": refs.quantile(.75) if len(refs) else np.nan,
                    "事件减历史中位数": ev["均值"] - refs.median() if len(refs) and pd.notna(ev["均值"]) else np.nan,
                    "稳健异常分数": rz,
                    "历史经验百分位_pct": 100 * (refs < ev["均值"]).mean() if len(refs) and pd.notna(ev["均值"]) else np.nan
                })
    comp = pd.DataFrame(comp_rows)
    comp.to_csv(OUT_DIR / "04_事件与历史同期对照_含敏感性对照.csv", index=False, encoding="utf-8-sig")

    # V5新增：边界层结构指标独立小结，不与其他类别分数直接混为一谈。
    bl_vars = ["温度梯度2-10m", "温度梯度2-20m", "风速差20-2m", "湍流动能", "摩擦速度", "感热通量", "潜热通量"]
    bl_rows = []
    for version_name in ["原始清洗值", "范围筛查敏感性版本"]:
        for var in bl_vars:
            if var not in vars_to_analyze:
                continue
            for h in WINDOWS:
                cc = comp[(comp["版本"] == version_name) & (comp["变量"] == var) & (comp["窗口小时"] == h)]
                if cc.empty:
                    continue
                row = cc.iloc[0].to_dict()
                bl_rows.append({
                    "版本": version_name, "边界层指标": var, "窗口小时": h,
                    "事件窗口均值": row.get("事件窗口均值"),
                    "历史有效年份数": row.get("历史有效年份数"),
                    "历史窗口均值中位数": row.get("历史窗口均值中位数"),
                    "事件减历史中位数": row.get("事件减历史中位数"),
                    "稳健异常分数": row.get("稳健异常分数"),
                    "历史经验百分位_pct": row.get("历史经验百分位_pct"),
                    "解释限制": "边界层结构独立评价；小样本异常分数仅用于筛选，不代表显著性或因果"
                })
    pd.DataFrame(bl_rows).to_csv(OUT_DIR / "12_边界层结构独立评价.csv", index=False, encoding="utf-8-sig")

    # 暖季背景：构建2021-2025暖季的72h滚动均值，保证与事件窗口时间尺度相同
    season_rows = []
    for version_name, source in [("原始清洗值", work), ("范围筛查敏感性版本", strict)]:
        warm = source[source["_time"].dt.year.isin(HIST_YEARS) & source["_time"].dt.month.isin([6, 7, 8, 9])].copy()
        for var in vars_to_analyze:
            for year in HIST_YEARS:
                sub = warm[warm["_time"].dt.year == year].sort_values("_time")
                s = num(sub[var])
                rolling = s.rolling(72, min_periods=58).mean().dropna()
                for val in rolling:
                    season_rows.append({"版本": version_name, "年份": year, "变量": var, "72h滚动均值": float(val)})
    season_df = pd.DataFrame(season_rows)
    season_df.to_csv(OUT_DIR / "05_暖季72小时滚动背景.csv", index=False, encoding="utf-8-sig")

    season_sum_rows = []
    for version_name in ["原始清洗值", "范围筛查敏感性版本"]:
        for var in vars_to_analyze:
            ev = event_cache[(version_name, 72, var)]["均值"]
            vals = num(season_df[(season_df["版本"] == version_name) & (season_df["变量"] == var)]["72h滚动均值"]).dropna()
            season_sum_rows.append({
                "版本": version_name, "变量": var, "类别": CATEGORY.get(var, "辅助指标"),
                "事件72h均值": ev, "暖季滚动窗口数": len(vals),
                "暖季滚动均值中位数": vals.median() if len(vals) else np.nan,
                "暖季Q25": vals.quantile(.25) if len(vals) else np.nan,
                "暖季Q75": vals.quantile(.75) if len(vals) else np.nan,
                "暖季稳健异常分数": robust_z(ev, vals),
                "暖季经验百分位_pct": 100 * (vals < ev).mean() if len(vals) and pd.notna(ev) else np.nan
            })
    season_sum = pd.DataFrame(season_sum_rows)
    season_sum.to_csv(OUT_DIR / "06_事件与暖季同长度窗口对照_含敏感性对照.csv", index=False, encoding="utf-8-sig")

    # 物理分组内先选代表变量，避免温度变量重复占多个名额
    rank_rows = []
    for version_name in ["原始清洗值", "范围筛查敏感性版本"]:
        for var in vars_to_analyze:
            sub = comp[(comp["版本"] == version_name) & (comp["变量"] == var)]
            z = num(sub["稳健异常分数"]).dropna()
            seas = season_sum[(season_sum["版本"] == version_name) & (season_sum["变量"] == var)]
            sz = num(seas["暖季稳健异常分数"]).dropna()
            abs_hist = float(z.abs().median()) if len(z) else np.nan
            abs_season = float(sz.abs().median()) if len(sz) else np.nan
            diffs = num(sub["事件减历史中位数"]).dropna()
            consistency = max((diffs > 0).mean(), (diffs < 0).mean()) if len(diffs) else np.nan
            parts = [v for v in [abs_hist, abs_season] if np.isfinite(v)]
            score = float(np.mean(parts)) if parts else np.nan
            rank_rows.append({
                "版本": version_name, "变量": var, "类别": CATEGORY.get(var, "辅助指标"),
                "物理因素组": next((g for g, members in GROUPS.items() if var in members), "其他"),
                "同期多窗口绝对异常分数中位数": abs_hist,
                "暖季72h绝对异常分数": abs_season,
                "多窗口方向一致率": consistency,
                "综合候选分数_非概率": score,
                "历史有效窗口数": len(z)
            })
    ranks = pd.DataFrame(rank_rows)
    ranks.to_csv(OUT_DIR / "07_候选因素排名_原始与敏感性版本.csv", index=False, encoding="utf-8-sig")

    # 每个物理组内分别排序，再生成“不同物理组代表候选”，避免温度重复入选
    representative_rows = []
    for version_name in ["原始清洗值", "范围筛查敏感性版本"]:
        r = ranks[ranks["版本"] == version_name].copy()
        for group, gdf in r.groupby("物理因素组"):
            gdf = gdf.sort_values("综合候选分数_非概率", ascending=False, na_position="last")
            for idx, (_, row) in enumerate(gdf.iterrows(), start=1):
                representative_rows.append({**row.to_dict(), "组内排名": idx})
    rep = pd.DataFrame(representative_rows)
    rep.to_csv(OUT_DIR / "08_按物理因素分组排名.csv", index=False, encoding="utf-8-sig")

    # 最终候选建议：仅使用严格敏感性版本，优先保证物理过程覆盖。
    # 每个物理因素组最多选1个代表；若可用组不足5个，则如实输出少于5个，不跨组重复凑数。
    strict_rank = ranks[ranks["版本"] == "范围筛查敏感性版本"].copy()
    strict_rank = strict_rank.dropna(subset=["综合候选分数_非概率"])
    strict_rank = strict_rank.sort_values("综合候选分数_非概率", ascending=False)
    chosen = []
    for group, gdf in strict_rank.groupby("物理因素组", sort=False):
        gdf = gdf.sort_values("综合候选分数_非概率", ascending=False, na_position="last")
        if len(gdf) and group != "其他":
            chosen.append(gdf.iloc[0].to_dict())
    chosen = sorted(chosen, key=lambda x: x["综合候选分数_非概率"], reverse=True)[:5]
    final5 = pd.DataFrame(chosen)
    if not final5.empty:
        final5.insert(0, "候选顺序_待人工复核", range(1, len(final5) + 1))
        final5["解释限制"] = "按物理组取代表变量的候选名单；不是概率或因果排名，需结合数据质量与灾害过程复核"
    final5.to_csv(OUT_DIR / "09_五个候选因素_物理分组版初筛.csv", index=False, encoding="utf-8-sig")

    # V6新增：输出VPD可疑值的具体时间，方便对照仪器日志/原始数据字典。
    vpd_source_col = next((x for x in ["VPD"] if x in work.columns), None)
    if vpd_source_col:
        vpd_series = num(work[vpd_source_col])
        bad_vpd = (vpd_series < 0) | (vpd_series > 100)
        vpd_bad_rows = work.loc[bad_vpd, ["_time"]].copy()
        vpd_bad_rows["VPD原始值"] = vpd_series.loc[bad_vpd].values
        vpd_bad_rows["是否事件前72小时"] = (
            (vpd_bad_rows["_time"] >= event_end - pd.Timedelta(hours=71)) &
            (vpd_bad_rows["_time"] <= event_end)
        )
        vpd_bad_rows["是否事件前24小时"] = (
            (vpd_bad_rows["_time"] >= event_end - pd.Timedelta(hours=23)) &
            (vpd_bad_rows["_time"] <= event_end)
        )
        vpd_bad_rows["标记说明"] = "超出当前敏感性范围0-100；不是自动判定为错误，需核实单位和传感器记录"
        vpd_bad_rows.to_csv(OUT_DIR / "13_VPD可疑值时间定位.csv", index=False, encoding="utf-8-sig")

    # V6新增：将主要候选因素的事件窗口与历史窗口统计汇总成易读的审阅表。
    review_rows = []
    review_vars = ["VPD", "净辐射", "长波向上", "感热通量", "气温1小时变化",
                   "正积温24h", "温度梯度2-10m", "温度梯度2-20m", "湍流动能", "土壤热通量"]
    for version_name in ["原始清洗值", "范围筛查敏感性版本"]:
        for var in review_vars:
            if var not in vars_to_analyze:
                continue
            for h in WINDOWS:
                one = comp[(comp["版本"] == version_name) &
                           (comp["变量"] == var) &
                           (comp["窗口小时"] == h)]
                if one.empty:
                    continue
                r = one.iloc[0]
                review_rows.append({
                    "版本": version_name,
                    "因素": var,
                    "类别": CATEGORY.get(var, "其他"),
                    "物理因素组": GROUPS.get(var, "其他"),
                    "窗口小时": h,
                    "事件窗口均值": r.get("事件窗口均值"),
                    "历史有效年份数": r.get("历史有效年份数"),
                    "历史同期窗口均值中位数": r.get("历史窗口均值中位数"),
                    "事件减历史中位数": r.get("事件减历史中位数"),
                    "稳健异常分数_筛选用": r.get("稳健异常分数"),
                    "历史经验百分位_pct": r.get("历史经验百分位_pct"),
                    "限制": "历史年份少；结果为描述性异常对照，不等同于显著性或因果证据"
                })
    pd.DataFrame(review_rows).to_csv(OUT_DIR / "14_关键因素最终复核表.csv", index=False, encoding="utf-8-sig")

    # V6新增：可复核的结论说明，避免把单事件候选排名误写为因果结论。
    readme_v6 = """问题一 V6 输出说明

新增文件：
13_VPD可疑值时间定位.csv：列出VPD低于0或高于100的记录时间及数值。该范围仅用于筛查，需以仪器说明/数据字典确认。
14_关键因素最终复核表.csv：列出候选变量在6/24/48/72小时窗口下的事件与历史同期对照。

解释规则：
1. VPD、辐射、通量的单位必须以数据字典/仪器元数据为准，不能仅凭数值范围断言错误。
2. 净辐射与向上长波辐射可能相关，不能将两者当作相互独立的证据。
3. 事件窗口与少量历史年份对照仅用于异常筛选；历史经验百分位不是统计显著性。
4. 单次灾害样本不能据此证明因果，也不能直接训练可靠的灾害发生概率模型。
5. “前五候选因素”是待复核名单，应同时考虑数据质量、时间窗口稳定性、物理含义和因素间冗余。
"""
    (OUT_DIR / "README_V6_结果解释.txt").write_text(readme_v6, encoding="utf-8")

    # 图：分别绘制关键变量逐小时序列，不把不同量纲混在一张图里
    plot_vars = ["气温2m", "相对湿度", "VPD", "净辐射", "降水", "湍流动能"]
    for var in plot_vars:
        if var not in work.columns or work[var].notna().sum() == 0:
            continue
        recent = work[(work["_time"] >= event_end - pd.Timedelta(days=7)) & (work["_time"] <= event_end)]
        if recent.empty:
            continue
        fig, ax = plt.subplots(figsize=(10, 4))
        ax.plot(recent["_time"], num(recent[var]), linewidth=1.1)
        ax.axvline(event_end, linestyle="--", linewidth=1)
        ax.set_title(f"灾前7天{var}逐小时变化")
        ax.set_xlabel("时间")
        ax.set_ylabel(var)
        ax.grid(alpha=.25)
        fig.autofmt_xdate()
        fig.tight_layout()
        fig.savefig(OUT_DIR / f"图_灾前7天_{var}.png", dpi=180)
        plt.close(fig)

    (OUT_DIR / "README_结果说明.txt").write_text(
        "本次模型输出说明：\n"
        "00_变量识别结果.csv：自动匹配的变量和原始列名。\n"
        "01_变量质量核查.csv：宽松范围异常标记；范围需结合设备说明确认。\n"
        "02_事件多窗口统计_含敏感性对照.csv：事件窗口原始值/范围筛查版统计。\n"
        "03_逐年同期窗口_含敏感性对照.csv：2021-2025逐年严格同期窗口。\n"
        "04_事件与历史同期对照_含敏感性对照.csv：多窗口历史对照。\n"
        "05_暖季72小时滚动背景.csv：暖季同长度窗口分布。\n"
        "06_事件与暖季同长度窗口对照_含敏感性对照.csv：暖季背景比较。\n"
        "07_候选因素排名_原始与敏感性版本.csv：原始值与范围筛查版排名。\n"
        "08_按物理因素分组排名.csv：按物理因素组整理，减少重复因素。\n"
        "09_五个候选因素_物理分组版初筛.csv：按物理因素组取代表项，必须人工复核。\n"
        "10_VPD专项诊断.csv：VPD分布、缺失率及事件前72小时有效率。\n"
        "11_净辐射与长波向上对照.csv：不同窗口表现及两者全时段相关性。\n"
        "12_边界层结构独立评价.csv：边界层指标的独立对照表。\n\n"
        "重要限制：范围筛查版不是经过验证的真值版本；被标记值不一定错误。\n"
        "最终报告必须结合原始数据字典、设备说明、事件过程资料和专家判断。\n"
        "候选分数不是概率，不证明因果关系。降水求和需先确认原列定义。\n",
        encoding="utf-8"
    )

    print("V6模型运行完成。")
    print(f"输入：{INPUT_FILE}")
    print(f"事件截止：{event_end}")
    print(f"输出：{OUT_DIR}")
    print("\n优先查看：")
    print("01_变量质量核查.csv")
    print("04_事件与历史同期对照_含敏感性对照.csv")
    print("07_候选因素排名_原始与敏感性版本.csv")
    print("09_五个候选因素_物理分组版初筛.csv")
    print("10_VPD专项诊断.csv")
    print("11_净辐射与长波向上对照.csv")
    print("12_边界层结构独立评价.csv")
    print("13_VPD可疑值时间定位.csv")
    print("14_关键因素最终复核表.csv")
    print("README_V6_结果解释.txt")
    print("\n注意：09是初筛结果，不是已验证的因果排名。")

if __name__ == "__main__":
    main()
