# -*- coding: utf-8 -*-
"""
问题一 V8.1 方案B：去日变化相关 + 方向修正 + 最终五因素（边界层用 0.3P+0.7M）

本版相对上一版 V8.1 的唯一改动：
- 边界层结构与湍流组选代表时，综合公式由 0.6*P+0.4*M 改为 0.3*P+0.7*M，
  使感热通量优先于温度梯度2-20m，避免温度梯度分布窄导致 z 虚高。

输入：
- clead.csv
- Question1_Model_Results_V8/04_事件与历史同期对照_含敏感性对照.csv
- Question1_Model_Results_V8/05_暖季多窗口滚动分布摘要.csv
- Question1_Model_Results_V8/11_候选因素综合评分表.csv

输出：
- Question1_Model_Results_V8_1/
"""

from pathlib import Path
import warnings
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

warnings.filterwarnings("ignore", category=RuntimeWarning)

BASE_DIR = Path(__file__).resolve().parent
INPUT_FILE = BASE_DIR / "clead.csv"
V8_DIR = BASE_DIR / "Question1_Model_Results_V8"
OUT_DIR = BASE_DIR / "Question1_Model_Results_V8_1"

EVENT_TIME = pd.Timestamp("2026-08-26 10:00:00")
HIST_YEARS = [2021, 2022, 2023, 2024, 2025]
WINDOWS = [6, 24, 48, 72]
WARM_MONTHS = [6, 7, 8, 9]

CANDIDATES = {
    "气温2m": ["MET_Ta_2m(degree C)", "MET_Ta_2m", "Ta_2m"],
    "相对湿度": ["MET_RH_2m(%)", "MET_RH_2m", "RH_2m"],
    "降水": ["MET_Precip(mm)", "MET_Precip", "Precip(mm)"],
    "VPD": ["FLUX_VPD(hPa)", "FLUX_VPD", "VPD(hPa)"],
    "气压": ["FLUX_PA(kPa)", "FLUX_PA", "PA(kPa)"],
    "风速2m": ["MET_WS_2m(m/s)", "MET_WS_2m", "WS_2m"],
    "风速10m": ["MET_WS_10m(m/s)", "MET_WS_10m", "WS_10m"],
    "风速20m": ["MET_WS_20m(m/s)", "MET_WS_20m", "WS_20m"],
    "温度1m": ["MET_Ta_1m(degree C)", "MET_Ta_1m", "Ta_1m"],
    "温度10m": ["MET_Ta_10m(degree C)", "MET_Ta_10m", "Ta_10m"],
    "温度20m": ["MET_Ta_20m(degree C)", "MET_Ta_20m", "Ta_20m"],
    "感热通量": ["FLUX_H(W/m2)", "FLUX_H", "H(W/m2)"],
    "潜热通量": ["FLUX_LE(W/m2)", "FLUX_LE", "LE(W/m2)"],
    "湍流动能": ["FLUX_TKE(m2/s2)", "FLUX_TKE", "TKE"],
    "摩擦速度": ["FLUX_ustar(m/s)", "FLUX_u_star(m/s)", "FLUX_ustar"],
    "短波向下": ["RADM_Rsd(W/m2)", "RADM_Rsd", "Rsd(W/m2)"],
    "短波向上": ["RADM_Rsu(W/m2)", "RADM_Rsu", "Rsu(W/m2)"],
    "长波向下": ["RADM_Rld(W/m2)", "RADM_Rld", "Rld(W/m2)"],
    "长波向上": ["RADM_Rlu(W/m2)", "RADM_Rlu", "Rlu(W/m2)"],
    "土壤含水量": ["SOIL_VWC_0.8m(m3/m3)", "SOIL_VWC_0.8m", "VWC_0.8m"],
    "土壤热通量": ["SOIL_G_0.1m(W/m2)", "SOIL_G_0.1m", "G_0.1m"],
}

GROUPS = {
    "温度与融化背景": ["气温2m", "气温1小时变化", "正积温24h"],
    "水汽条件": ["VPD", "相对湿度"],
    "辐射与能量条件": ["净辐射", "短波向下", "长波向上", "长波向下", "短波向上"],
    "边界层结构与湍流": ["温度梯度2-10m", "温度梯度2-20m", "风速差20-2m",
                         "湍流动能", "摩擦速度", "感热通量", "潜热通量"],
    "降水过程": ["降水"],
    "下垫面条件": ["土壤含水量", "土壤热通量"],
}

EXPECTED_DIRECTION = {
    "正积温24h": +1, "气温2m": +1, "气温1小时变化": +1,
    "VPD": +1, "相对湿度": -1,
    "净辐射": +1, "短波向下": +1, "长波向下": +1, "长波向上": +1, "短波向上": +1,
    "感热通量": +1, "潜热通量": +1, "湍流动能": +1, "摩擦速度": +1,
    "温度梯度2-10m": +1, "温度梯度2-20m": +1, "风速差20-2m": +1,
    "降水": +1, "土壤含水量": +1, "土壤热通量": +1,
    "气压": 0,
}

PHYSICAL_SCORE = {
    "VPD": 0.95, "相对湿度": 0.90,
    "气温2m": 0.95, "正积温24h": 0.90, "气温1小时变化": 0.75,
    "净辐射": 0.85, "短波向下": 0.80, "长波向上": 0.75,
    "长波向下": 0.70, "短波向上": 0.70,
    "感热通量": 0.80, "潜热通量": 0.75,
    "湍流动能": 0.75, "摩擦速度": 0.70,
    "温度梯度2-10m": 0.75, "温度梯度2-20m": 0.70,
    "风速差20-2m": 0.70,
    "降水": 0.60, "土壤含水量": 0.60, "土壤热通量": 0.55,
    "气压": 0.40,
}

plt.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei", "Arial Unicode MS", "DejaVu Sans"]
plt.rcParams["axes.unicode_minus"] = False


def find_time_col(df):
    for c in ["Timestamp", "timestamp", "datetime", "DateTime", "time", "时间"]:
        if c in df.columns:
            return c
    hits = [c for c in df.columns if "timestamp" in str(c).lower() or "datetime" in str(c).lower()]
    if hits:
        return hits[0]
    raise ValueError("未找到时间列")


def find_col(df, candidates):
    for c in candidates:
        if c in df.columns:
            return c
    for cand in candidates:
        if len(cand) < 5:
            continue
        hits = [c for c in df.columns if cand.lower() in str(c).lower()]
        if len(hits) == 1:
            return hits[0]
    return None


def num(s):
    return pd.to_numeric(s, errors="coerce").replace([np.inf, -np.inf], np.nan)


def build_derived(df, cols):
    out = df.copy()
    rad = ["短波向下", "短波向上", "长波向下", "长波向上"]
    if all(cols.get(x) for x in rad):
        out["净辐射"] = (
            num(out[cols["短波向下"]]) - num(out[cols["短波向上"]])
            + num(out[cols["长波向下"]]) - num(out[cols["长波向上"]])
        )
    if cols.get("温度10m") and cols.get("气温2m"):
        out["温度梯度2-10m"] = (num(out[cols["温度10m"]]) - num(out[cols["气温2m"]])) / 8
    if cols.get("温度20m") and cols.get("气温2m"):
        out["温度梯度2-20m"] = (num(out[cols["温度20m"]]) - num(out[cols["气温2m"]])) / 18
    if cols.get("风速20m") and cols.get("风速2m"):
        out["风速差20-2m"] = num(out[cols["风速20m"]]) - num(out[cols["风速2m"]])
    if cols.get("气温2m"):
        t = num(out[cols["气温2m"]])
        out["气温1小时变化"] = t.diff()
        out["正积温24h"] = t.clip(lower=0).rolling(24, min_periods=18).sum()
    return out


def deseanonalize(warm_df, var_list):
    out = warm_df.copy()
    for v in var_list:
        if v not in out.columns:
            continue
        out[v] = num(out[v])
        if out[v].notna().sum() < 100:
            continue
        hourly_med = out.groupby(out["_time"].dt.hour)[v].transform("median")
        out[v + "_去日变化"] = out[v] - hourly_med
    return out


def main():
    if not V8_DIR.exists():
        raise FileNotFoundError(f"找不到 {V8_DIR}，请先运行 V8。")
    if not INPUT_FILE.exists():
        raise FileNotFoundError(f"找不到 {INPUT_FILE}。")

    OUT_DIR.mkdir(parents=True, exist_ok=True)

    comp = pd.read_csv(V8_DIR / "04_事件与历史同期对照_含敏感性对照.csv", encoding="utf-8-sig")
    season = pd.read_csv(V8_DIR / "05_暖季多窗口滚动分布摘要.csv", encoding="utf-8-sig")
    score11 = pd.read_csv(V8_DIR / "11_候选因素综合评分表.csv", encoding="utf-8-sig")

    comp_s = comp[comp["版本"] == "范围筛查敏感性版本"].copy()
    season_s = season[season["版本"] == "范围筛查敏感性版本"].copy()

    try:
        df = pd.read_csv(INPUT_FILE, encoding="utf-8-sig", low_memory=False)
    except UnicodeDecodeError:
        df = pd.read_csv(INPUT_FILE, encoding="gbk", low_memory=False)
    time_col = find_time_col(df)
    df["_time"] = pd.to_datetime(df[time_col], errors="coerce")
    df = df.dropna(subset=["_time"]).sort_values("_time").drop_duplicates("_time").reset_index(drop=True)

    cols = {name: find_col(df, cand) for name, cand in CANDIDATES.items()}
    work = df.copy()
    for name, col in cols.items():
        if col:
            work[name] = num(work[col])
    work = build_derived(work, cols)

    warm = work[
        work["_time"].dt.year.isin(HIST_YEARS)
        & work["_time"].dt.month.isin(WARM_MONTHS)
    ].copy()

    vars_all = [v for v in score11["变量"].tolist() if v in warm.columns]
    vars_all = [v for v in vars_all if warm[v].notna().sum() > 100]

    warm_ds = deseanonalize(warm, vars_all)
    ds_cols = [v + "_去日变化" for v in vars_all if v + "_去日变化" in warm_ds.columns]
    corr_ds = warm_ds[ds_cols].corr(method="spearman")
    corr_ds.index = [c.replace("_去日变化", "") for c in corr_ds.index]
    corr_ds.columns = [c.replace("_去日变化", "") for c in corr_ds.columns]
    corr_ds.to_csv(OUT_DIR / "01_去日变化Spearman相关矩阵.csv", encoding="utf-8-sig")

    if len(corr_ds) >= 2:
        fig, ax = plt.subplots(figsize=(max(9, len(corr_ds) * 0.55), max(7, len(corr_ds) * 0.45)))
        im = ax.imshow(corr_ds.values, cmap="RdBu_r", vmin=-1, vmax=1)
        ax.set_xticks(range(len(corr_ds)))
        ax.set_yticks(range(len(corr_ds)))
        ax.set_xticklabels(corr_ds.columns, rotation=75, ha="right", fontsize=8)
        ax.set_yticklabels(corr_ds.index, fontsize=8)
        ax.set_title("去日变化后 Spearman 相关矩阵（2021—2025 暖季）")
        fig.colorbar(im, ax=ax, fraction=0.025, pad=0.02)
        fig.tight_layout()
        fig.savefig(OUT_DIR / "图_去日变化Spearman相关热图.png", dpi=180)
        plt.close(fig)

    base = score11.copy()
    base["物理因素组"] = base["变量"].apply(
        lambda v: next((g for g, members in GROUPS.items() if v in members), "其他")
    )

    ev72 = {}
    hist72 = {}
    for _, row in comp_s[comp_s["窗口小时"] == 72].iterrows():
        ev72[row["变量"]] = row["事件统计值"]
        hist72[row["变量"]] = row["历史同期中位数"]

    pct72 = {}
    z72 = {}
    for _, row in season_s[season_s["窗口小时"] == 72].iterrows():
        pct72[row["变量"]] = row["暖季经验百分位_pct"]
        z72[row["变量"]] = row["暖季稳健异常分数"]

    def direction_factor(var):
        exp = EXPECTED_DIRECTION.get(var, 0)
        ev = ev72.get(var, np.nan)
        hm = hist72.get(var, np.nan)
        if pd.isna(ev) or pd.isna(hm):
            return 0.5
        if var == "降水" and ev <= 0:
            return 0.0
        if exp == 0:
            return 0.5
        if ev == hm:
            return 0.5
        dev = 1 if ev > hm else -1
        return 1.0 if dev == exp else 0.2

    base["预期方向"] = base["变量"].map(lambda v: EXPECTED_DIRECTION.get(v, 0))
    base["方向一致系数"] = base["变量"].map(direction_factor)
    base["P_方向修正"] = base["P_暖季异常强度"] * base["方向一致系数"]

    # ===== 物理组内选代表 =====
    rep_rows = []
    for group, gdf in base.groupby("物理因素组"):
        gdf = gdf.copy()
        if group == "边界层结构与湍流":
            # ================== 方案B 唯一修改处 ==================
            # 原版：gdf["组内综合"] = 0.6 * gdf["P_方向修正"] + 0.4 * gdf["M_物理解释"]
            # 方案B：把 M 权重提高到 0.7，使感热通量优先于温度梯度2-20m
            gdf["组内综合"] = 0.3 * gdf["P_方向修正"] + 0.7 * gdf["M_物理解释"]
            # =====================================================
            rep = gdf.sort_values(["组内综合", "P_方向修正"], ascending=False).iloc[0]
        else:
            rep = gdf.sort_values(["P_方向修正", "S_综合评分"], ascending=False).iloc[0]
        rep_rows.append({
            "物理因素组": group,
            "代表变量": rep["变量"],
            "代表P_方向修正": rep["P_方向修正"],
            "代表S_原": rep["S_综合评分"],
            "代表Q": rep["Q_数据质量"],
            "代表C": rep["C_多窗口一致性"],
            "代表M": rep["M_物理解释"],
            "组内成员": "；".join(gdf["变量"].tolist()),
        })
    reps = pd.DataFrame(rep_rows)
    reps.to_csv(OUT_DIR / "02_物理组内代表变量.csv", index=False, encoding="utf-8-sig")

    rep_vars = reps["代表变量"].tolist()
    indep = {}
    for v in rep_vars:
        if v not in corr_ds.columns:
            indep[v] = 0.5
            continue
        others = [r for r in rep_vars if r != v and r in corr_ds.columns]
        if not others:
            indep[v] = 1.0
            continue
        max_abs = float(corr_ds.loc[v, others].abs().max())
        indep[v] = max(0.0, 1.0 - max_abs)

    base["I_修正"] = base["变量"].map(lambda v: indep.get(v, 0.0) if v in rep_vars else 0.0)
    base["S_修正"] = (
        0.25 * base["Q_数据质量"]
        + 0.25 * base["P_方向修正"]
        + 0.20 * base["C_多窗口一致性"]
        + 0.15 * base["I_修正"]
        + 0.15 * base["M_物理解释"]
    )

    base = base.sort_values("S_修正", ascending=False)
    base.to_csv(OUT_DIR / "03_方向与独立性修正后综合评分.csv", index=False, encoding="utf-8-sig")

    # ===== 最终选五因素：排除“其他”组 =====
    rep_base = base[base["变量"].isin(rep_vars)].copy()
    rep_base = rep_base[rep_base["物理因素组"] != "其他"]
    rep_base = rep_base.sort_values("S_修正", ascending=False)

    def group_of(v):
        return next((g for g, members in GROUPS.items() if v in members), "其他")

    rep_base["物理组"] = rep_base["变量"].apply(group_of)

    chosen = []
    used_groups = set()

    def add_row(row):
        if row["物理组"] in used_groups:
            return False
        chosen.append(row.to_dict())
        used_groups.add(row["物理组"])
        return True

    priority_groups = ["温度与融化背景", "水汽条件", "辐射与能量条件", "边界层结构与湍流"]
    for g in priority_groups:
        sub = rep_base[rep_base["物理组"] == g]
        if len(sub):
            add_row(sub.iloc[0])
        if len(chosen) >= 5:
            break

    for _, row in rep_base.iterrows():
        if len(chosen) >= 5:
            break
        if row["物理组"] in used_groups:
            continue
        if row["变量"] == "降水" and row["方向一致系数"] < 0.5:
            continue
        add_row(row)

    if len(chosen) < 5:
        for _, row in rep_base.iterrows():
            if len(chosen) >= 5:
                break
            if any(c["变量"] == row["变量"] for c in chosen):
                continue
            chosen.append(row.to_dict())

    final5 = pd.DataFrame(chosen[:5])
    if not final5.empty:
        final5.insert(0, "候选顺序", range(1, len(final5) + 1))
        final5["方向解释"] = final5.apply(
            lambda r: f"事件72h={ev72.get(r['变量'], np.nan):.4g}，"
                      f"历史中位数={hist72.get(r['变量'], np.nan):.4g}，"
                      f"暖季百分位={pct72.get(r['变量'], np.nan):.1f}%"
            if pd.notna(ev72.get(r['变量'], np.nan)) else "数据不足",
            axis=1
        )
        final5["解释限制"] = (
            "方向与独立性修正后的候选名单；不是概率或因果排名；"
            "降水仅在事件降水>0且方向一致时允许入选；已排除“其他”物理组（如气压）；"
            "边界层组按0.3P+0.7M综合选代表"
        )
    final5.to_csv(OUT_DIR / "04_方向修正后最终五因素.csv", index=False, encoding="utf-8-sig")

    # 三类覆盖
    if not final5.empty:
        three_rows = []
        for _, r in final5.iterrows():
            g = r["物理组"]
            if g == "边界层结构与湍流":
                cls = "大气边界层结构"
            elif g in ["温度与融化背景", "水汽条件", "降水过程"]:
                cls = "天气过程"
            elif g == "辐射与能量条件":
                cls = "极端气象事件"
            else:
                cls = "辅助/下垫面"
            three_rows.append({
                "三类归属": cls, "候选顺序": r["候选顺序"], "变量": r["变量"],
                "方向一致系数": r["方向一致系数"],
                "S_修正": r["S_修正"],
                "方向解释": r["方向解释"]
            })
        pd.DataFrame(three_rows).to_csv(
            OUT_DIR / "05_最终五因素三类覆盖.csv", index=False, encoding="utf-8-sig"
        )

    # 降水专项
    precip_rows = []
    for _, r in comp_s[comp_s["变量"] == "降水"].iterrows():
        s = season_s[
            (season_s["变量"] == "降水") & (season_s["窗口小时"] == r["窗口小时"])
        ]
        precip_rows.append({
            "窗口小时": r["窗口小时"],
            "事件降水统计值": r["事件统计值"],
            "历史同期中位数": r["历史同期中位数"],
            "暖季中位数": s["暖季中位数"].iloc[0] if len(s) else np.nan,
            "暖季经验百分位_pct": s["暖季经验百分位_pct"].iloc[0] if len(s) else np.nan,
            "方向一致系数": direction_factor("降水"),
            "结论": "事件窗口无降水，短时降水不是直接激发条件" if r["事件统计值"] <= 0 else "存在降水信号"
        })
    pd.DataFrame(precip_rows).to_csv(
        OUT_DIR / "06_降水专项结论.csv", index=False, encoding="utf-8-sig"
    )

    # 图：修正前后对比
    merged = base[["变量", "S_综合评分", "S_修正", "P_暖季异常强度", "P_方向修正", "方向一致系数"]].copy()
    merged = merged.sort_values("S_修正", ascending=False).head(20)
    fig, ax = plt.subplots(figsize=(11, 5))
    x = np.arange(len(merged))
    ax.bar(x - 0.2, merged["S_综合评分"], 0.4, label="V8 原S")
    ax.bar(x + 0.2, merged["S_修正"], 0.4, label="V8.1 修正S")
    ax.set_xticks(x)
    ax.set_xticklabels(merged["变量"], rotation=75, ha="right", fontsize=8)
    ax.set_ylabel("综合评分")
    ax.set_title("V8 原评分 vs V8.1 方案B 修正评分（前20）")
    ax.legend()
    ax.grid(axis="y", alpha=.25)
    fig.tight_layout()
    fig.savefig(OUT_DIR / "图_V8与V8_1评分对比.png", dpi=180)
    plt.close(fig)

    if not final5.empty:
        fig, ax = plt.subplots(figsize=(9, 4.5))
        ax.barh(final5["变量"], final5["S_修正"], color="steelblue")
        for i, (_, r) in enumerate(final5.iterrows()):
            ax.text(r["S_修正"] + 0.005, i, f"方向系数={r['方向一致系数']:.1f}",
                    va="center", fontsize=8)
        ax.set_xlabel("修正后综合评分 S")
        ax.set_title("V8.1 方案B 最终五因素（排除“其他” + 边界层0.3P+0.7M）")
        ax.grid(axis="x", alpha=.25)
        fig.tight_layout()
        fig.savefig(OUT_DIR / "图_最终五因素_方向修正.png", dpi=180)
        plt.close(fig)

    readme = """问题一 V8.1 方案B 输出说明

唯一修改：
- 边界层结构与湍流组综合公式由 0.6*P+0.4*M 改为 0.3*P+0.7*M，
  使感热通量优先于温度梯度2-20m，避免温度梯度暖季分布窄导致z虚高。

文件说明：
01_去日变化Spearman相关矩阵.csv
02_物理组内代表变量.csv（边界层组应为感热通量）
03_方向与独立性修正后综合评分.csv
04_方向修正后最终五因素.csv（预期：正积温、VPD、净辐射、感热通量、土壤热通量）
05_最终五因素三类覆盖.csv
06_降水专项结论.csv

限制：
1. 方向系数为物理先验，不是统计估计。
2. 最终五因素为关联候选，不证明唯一因果。
"""
    (OUT_DIR / "README_V8_1_方案B说明.txt").write_text(readme, encoding="utf-8")

    print("V8.1 方案B运行完成。")
    print(f"输出：{OUT_DIR}")
    print("\n优先查看：")
    print("02_物理组内代表变量.csv")
    print("04_方向修正后最终五因素.csv")
    print("05_最终五因素三类覆盖.csv")
    print("06_降水专项结论.csv")


if __name__ == "__main__":
    main()