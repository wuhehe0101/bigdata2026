# -*- coding: utf-8 -*-
"""
吉隆县冰崩—泥石流研究：clead.csv 二次质控诊断脚本
用途：
1. 读取 clead.csv，不修改、不覆盖原文件；
2. 输出数据完整性、时间连续性、可疑值、事件窗口诊断表；
3. 仅“标记”可疑值，不自动删除或修正，以便先核验原始记录和单位。

运行方式（Windows / Anaconda）：
    python question1_second_qc.py
也可以在命令行指定输入文件：
    python question1_second_qc.py "D:\\路径\\clead.csv"

依赖：
    pandas, numpy
安装（如缺少）：
    pip install pandas numpy
"""

from pathlib import Path
import sys
import warnings

import numpy as np
import pandas as pd

warnings.filterwarnings("ignore", category=RuntimeWarning)

# ===== 可按需修改的默认路径 =====
PROJECT_DIR = Path(r"D:\pythonProjects\mother_model\问题一")
ATTACHMENT_DIR = Path(r"D:\pythonProjects\mother_model\附件")
OUTPUT_DIR_NAME = "Question1_SecondQC"

# 事件发生时间约为 2026-08-26 10:30；逐小时数据最后一个完整时次取 10:00
EVENT_TIME = pd.Timestamp("2026-08-26 10:30:00")
EVENT_CUTOFF = pd.Timestamp("2026-08-26 10:00:00")
EVENT_START_6H = EVENT_CUTOFF - pd.Timedelta(hours=5)   # 6个整点时次：05:00—10:00
EVENT_START_24H = EVENT_CUTOFF - pd.Timedelta(hours=23) # 24个整点时次：前一日11:00—当日10:00
EVENT_START_72H = EVENT_CUTOFF - pd.Timedelta(hours=71)

# 仅作为“需要人工核查”的筛查阈值，不代表自动判错或自动删除
VPD_REVIEW_HIGH = 100.0       # hPa；clead 中最大值约 1940 hPa，明显值得回查
LONGWAVE_REVIEW_HIGH = 800.0  # W/m²；用于筛查极端大值，不直接认定错误
PRESSURE_EXPECTED_HPA_MIN = 400.0
PRESSURE_EXPECTED_HPA_MAX = 800.0


def find_input_file():
    """优先使用命令行路径；否则按常见目录查找 clead.csv。"""
    if len(sys.argv) > 1:
        p = Path(sys.argv[1].strip('"'))
        if p.is_file():
            return p
        raise FileNotFoundError(f"命令行指定的文件不存在：{p}")

    candidates = [
        PROJECT_DIR / "clead.csv",
        ATTACHMENT_DIR / "clead.csv",
        Path.cwd() / "clead.csv",
    ]
    for p in candidates:
        if p.is_file():
            return p

    # 在项目目录和附件目录内递归搜索，优先文件名完全匹配的结果
    search_roots = [p for p in [PROJECT_DIR, ATTACHMENT_DIR] if p.exists()]
    matches = []
    for root in search_roots:
        try:
            matches.extend(root.rglob("clead.csv"))
        except (PermissionError, OSError):
            pass
    if matches:
        return sorted(matches, key=lambda p: (len(str(p)), str(p).lower()))[0]

    raise FileNotFoundError(
        "未找到 clead.csv。\n"
        "请把 clead.csv 放到以下任一目录：\n"
        f"  {PROJECT_DIR}\n  {ATTACHMENT_DIR}\n"
        "或者运行：python question1_second_qc.py \"D:\\完整路径\\clead.csv\""
    )


def read_csv_robust(path):
    """尝试常见编码读取 CSV。"""
    errors = []
    for enc in ["utf-8-sig", "utf-8", "gbk"]:
        try:
            df = pd.read_csv(path, encoding=enc, low_memory=False)
            return df
        except Exception as exc:
            errors.append(f"{enc}: {exc}")
    raise RuntimeError("CSV 读取失败：\n" + "\n".join(errors))


def choose_time_column(df):
    """寻找时间列，优先 Timestamp / Time / DateTime。"""
    preferred = ["Timestamp", "timestamp", "Time", "time", "DateTime", "datetime", "日期时间", "时间"]
    for col in preferred:
        if col in df.columns:
            return col
    for col in df.columns:
        low = str(col).lower()
        if "timestamp" in low or low in {"time", "datetime", "date_time"}:
            return col
    raise KeyError(f"找不到时间列。当前列名：{list(df.columns[:20])}")


def to_numeric_columns(df, time_col):
    """保留原始列名；将除时间列外的字段尽可能转为数值。"""
    out = df.copy()
    out[time_col] = pd.to_datetime(out[time_col], errors="coerce")
    for col in out.columns:
        if col != time_col:
            out[col] = pd.to_numeric(out[col], errors="coerce")
    return out


def write_csv(df, path):
    df.to_csv(path, index=False, encoding="utf-8-sig")


def main():
    input_path = find_input_file()
    output_dir = input_path.parent / OUTPUT_DIR_NAME
    output_dir.mkdir(parents=True, exist_ok=True)

    print("=" * 72)
    print("吉隆县研究数据二次质控诊断")
    print(f"输入文件：{input_path}")
    print(f"输出目录：{output_dir}")
    print("注意：本脚本只诊断和标记，不会覆盖或修改 clead.csv。")
    print("=" * 72)

    raw = read_csv_robust(input_path)
    time_col = choose_time_column(raw)
    df = to_numeric_columns(raw, time_col)

    # 时间字段质量与基本摘要
    valid_time = df[time_col].dropna()
    if valid_time.empty:
        raise ValueError(f"时间列 {time_col} 无法解析，请检查日期格式。")

    duplicate_count = int(df.loc[df[time_col].notna(), time_col].duplicated().sum())
    time_min, time_max = valid_time.min(), valid_time.max()
    expected = pd.date_range(time_min.floor("h"), time_max.floor("h"), freq="h")
    observed = pd.DatetimeIndex(valid_time.drop_duplicates().sort_values())
    missing_hours = expected.difference(observed.floor("h").unique())

    overview = pd.DataFrame([
        ["输入文件", str(input_path)],
        ["原始行数", len(raw)],
        ["字段数", len(raw.columns)],
        ["时间列", time_col],
        ["时间解析失败行数", int(df[time_col].isna().sum())],
        ["时间范围起点", str(time_min)],
        ["时间范围终点", str(time_max)],
        ["重复时间戳数（重复项，不含首次）", duplicate_count],
        ["理论逐小时时次数", len(expected)],
        ["缺失小时数（按整点覆盖检查）", len(missing_hours)],
        ["事件时刻", str(EVENT_TIME)],
        ["事件前最后一个完整小时", str(EVENT_CUTOFF)],
        ["事件前6小时窗口", f"{EVENT_START_6H} 至 {EVENT_CUTOFF}"],
        ["事件前24小时窗口", f"{EVENT_START_24H} 至 {EVENT_CUTOFF}"],
        ["事件前72小时窗口", f"{EVENT_START_72H} 至 {EVENT_CUTOFF}"],
    ], columns=["项目", "结果"])
    write_csv(overview, output_dir / "00_数据与时间概况.csv")

    if len(missing_hours):
        missing_df = pd.DataFrame({"缺失小时": missing_hours.astype(str)})
        write_csv(missing_df, output_dir / "00_缺失小时清单.csv")
    else:
        write_csv(pd.DataFrame(columns=["缺失小时"]), output_dir / "00_缺失小时清单.csv")

    # 字段完整性及基本分布
    completeness_rows = []
    for col in df.columns:
        if col == time_col:
            continue
        s = df[col]
        n_valid = int(s.notna().sum())
        vals = s.dropna()
        completeness_rows.append({
            "变量": col,
            "总行数": len(df),
            "有效值数": n_valid,
            "缺失值数": int(s.isna().sum()),
            "缺失率_pct": round(float(s.isna().mean() * 100), 4),
            "最小值": vals.min() if len(vals) else np.nan,
            "P01": vals.quantile(0.01) if len(vals) else np.nan,
            "中位数": vals.median() if len(vals) else np.nan,
            "P99": vals.quantile(0.99) if len(vals) else np.nan,
            "最大值": vals.max() if len(vals) else np.nan,
        })
    completeness = pd.DataFrame(completeness_rows)
    write_csv(completeness, output_dir / "01_字段完整性与分布.csv")

    # 逐条记录可疑值：仅标记，不删除
    flags = []

    def add_flags(col, condition, rule, severity="待核查"):
        if col not in df.columns:
            return
        mask = condition(df[col]) & df[col].notna() & df[time_col].notna()
        for idx in df.index[mask]:
            flags.append({
                "Timestamp": df.at[idx, time_col],
                "变量": col,
                "数值": df.at[idx, col],
                "标记规则": rule,
                "核查级别": severity,
                "处理建议": "回查原始文件、仪器质控码、变量单位及相邻时次；未核实前不要直接删除或替换",
            })

    # VPD：负值与极端大值需要回查
    for col in df.columns:
        if "VPD" in str(col).upper():
            add_flags(col, lambda s: s < 0, "VPD<0：若变量为水汽压亏缺，物理上通常不应为负", "高优先级")
            add_flags(col, lambda s: s > VPD_REVIEW_HIGH,
                      f"VPD>{VPD_REVIEW_HIGH}：极端值筛查阈值，核对单位/原始值/计算方式", "高优先级")

    # 辐射：负短波、过大的长波值只标记
    for col in df.columns:
        upper = str(col).upper()
        if "RSD" in upper or "RSU" in upper:
            add_flags(col, lambda s: s < -5,
                      "短波辐射<-5 W/m²：夜间可能存在零点偏移，但较大负值需核查", "待核查")
        if "RLD" in upper or "RLU" in upper:
            add_flags(col, lambda s: s > LONGWAVE_REVIEW_HIGH,
                      f"长波辐射>{LONGWAVE_REVIEW_HIGH} W/m²：极端大值筛查阈值", "高优先级")
            add_flags(col, lambda s: s < 0, "长波辐射<0 W/m²：核对传感器与原始数据", "高优先级")

    # 气压列：检查列名与数值量级是否不一致，不修改原列
    for col in df.columns:
        upper = str(col).upper()
        if "PA" in upper and ("FLUX" in upper or "PRESS" in upper or "气压" in str(col)):
            vals = df[col].dropna()
            if len(vals):
                med = vals.median()
                if PRESSURE_EXPECTED_HPA_MIN <= med <= PRESSURE_EXPECTED_HPA_MAX:
                    flags.append({
                        "Timestamp": pd.NaT,
                        "变量": col,
                        "数值": med,
                        "标记规则": "全列中位数约为400–800，数值量级更像 hPa 而不是 kPa；核对源数据单位和是否乘以10",
                        "核查级别": "单位核查",
                        "处理建议": "若源数据确为 kPa 且已乘以10，应将分析数据列名改为 hPa；若源数据本来是 hPa，则需检查是否误乘10",
                    })

    # 其他常见物理边界只做提示性检查
    for col in df.columns:
        name = str(col).lower()
        if "rh" in name or "humidity" in name or "相对湿度" in str(col):
            add_flags(col, lambda s: (s < 0) | (s > 100), "相对湿度超出0–100%范围", "高优先级")
        if "precip" in name or "rain" in name or "降水" in str(col):
            add_flags(col, lambda s: s < 0, "降水量为负值", "高优先级")

    flag_df = pd.DataFrame(flags, columns=[
        "Timestamp", "变量", "数值", "标记规则", "核查级别", "处理建议"
    ])
    if not flag_df.empty:
        flag_df = flag_df.sort_values(["核查级别", "变量", "Timestamp"], na_position="last")
    write_csv(flag_df, output_dir / "02_可疑值逐条清单.csv")

    # 事件前窗口的重点变量明细，方便快速核查
    preferred_tokens = [
        "Ta_2m", "RH_2m", "Precip", "VPD", "Rsd", "Rsu", "Rld", "Rlu",
        "H(", "LE(", "USTAR", "PA(", "PBLH", "SWC", "soil"
    ]
    key_cols = []
    for col in df.columns:
        if col == time_col:
            continue
        if any(token.lower() in str(col).lower() for token in preferred_tokens):
            key_cols.append(col)

    event_windows = [
        ("事件前6小时", EVENT_START_6H, EVENT_CUTOFF),
        ("事件前24小时", EVENT_START_24H, EVENT_CUTOFF),
        ("事件前72小时", EVENT_START_72H, EVENT_CUTOFF),
    ]
    event_summary_rows = []
    event_detail_parts = []
    for label, start, end in event_windows:
        subset = df.loc[(df[time_col] >= start) & (df[time_col] <= end)].copy()
        if not subset.empty:
            detail = subset[[time_col] + key_cols].copy()
            detail.insert(0, "窗口", label)
            detail = detail.rename(columns={time_col: "Timestamp"})
            event_detail_parts.append(detail)
        for col in key_cols:
            vals = subset[col].dropna()
            event_summary_rows.append({
                "窗口": label,
                "起始时刻": str(start),
                "结束时刻": str(end),
                "变量": col,
                "窗口行数": len(subset),
                "有效值数": int(vals.size),
                "缺失值数": int(subset[col].isna().sum()),
                "均值": vals.mean() if len(vals) else np.nan,
                "最小值": vals.min() if len(vals) else np.nan,
                "最大值": vals.max() if len(vals) else np.nan,
            })
    write_csv(pd.DataFrame(event_summary_rows), output_dir / "03_事件窗口重点变量摘要.csv")
    if event_detail_parts:
        write_csv(pd.concat(event_detail_parts, ignore_index=True), output_dir / "03_事件窗口重点变量逐小时明细.csv")
    else:
        write_csv(pd.DataFrame(columns=["窗口", "Timestamp"] + key_cols),
                  output_dir / "03_事件窗口重点变量逐小时明细.csv")

    # 针对插值问题的说明：清洗输出没有插值标记时，无法仅凭 clead.csv 确认哪些值被插值
    notes = [
        ["插值追踪", "clead.csv 未包含明确的“是否插值”标记列，因此无法仅凭该文件准确识别哪些单元格由线性插值得到。"],
        ["建议", "后续应在原清洗脚本中对每个被插值单元格增加插值标记，或将插值前后数据进行差分核查。"],
        ["降水", "降水属于非负、常有大量零值且可能突发的变量，不建议默认用线性插值补缺。"],
        ["辐射", "短波辐射具有昼夜周期，缺测补值需结合太阳高度角/相邻时次；不能不加区分地线性插值。"],
        ["湍流通量", "H、LE、USTAR等变量受稳定度与湍流状态影响，插值值应保留标记并进行敏感性分析。"],
        ["QC标记", "若原始 MET/RADM/SOIL 文件包含 QC 列，应先按数据说明书解释 QC 编码并应用筛选，再删除 QC 列。"],
        ["气压单位", "若 FLUX_PA 数值约为600–630，量级更像 hPa；需回看原始单位与乘10操作，不要只根据列名判断。"],
        ["可疑值原则", "本脚本只产生核查清单，不自动删除、截断或修正任何可疑值。"],
    ]
    write_csv(pd.DataFrame(notes, columns=["主题", "说明"]), output_dir / "04_二次质控注意事项.csv")

    print("\n诊断完成。输出文件：")
    for p in sorted(output_dir.glob("*.csv")):
        print(f"  - {p.name}")
    print("\n可优先查看：")
    print("  1) 00_数据与时间概况.csv")
    print("  2) 01_字段完整性与分布.csv")
    print("  3) 02_可疑值逐条清单.csv")
    print("  4) 03_事件窗口重点变量摘要.csv")
    print("\n提醒：可疑值清单是人工复核线索，不等于最终剔除清单。")


if __name__ == "__main__":
    main()
