# -*- coding: utf-8 -*-
"""
问题一后续实验：DEM地形、土地覆盖、冰川NetCDF元数据与历史灾点检查

本版修正：
1. 原始附件目录与分析输出目录分开；
2. 自动查找附件（7）中的 DEM；若为经纬度坐标，生成米制 UTM 45N 分析副本；
3. 使用（5）文件夹中的 2023 土地覆盖栅格；
4. 将（4）中的 NetCDF 作为 NetCDF 读取，输出变量/坐标/单位清单，不猜测变量含义；
5. 自动查找（6）历史灾点文件；
6. 不会覆盖或修改原始数据。
依赖：
pip install pandas numpy matplotlib rasterio geopandas shapely pyproj xarray netCDF4
"""

from pathlib import Path
import shutil
import warnings
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

BASE_DIR = Path(r"D:\pythonProjects\mother_model\附件")
PROJECT_DIR = Path(r"D:\pythonProjects\mother_model\问题一")
OUT_DIR = PROJECT_DIR / "Question1_CrossValidation"
FIG_DIR = OUT_DIR / "figures"
OUT_DIR.mkdir(parents=True, exist_ok=True)
FIG_DIR.mkdir(parents=True, exist_ok=True)

RASTER_EXTS = {".tif", ".tiff", ".img", ".grd"}
VECTOR_EXTS = {".shp", ".gpkg", ".geojson", ".json", ".csv", ".xlsx", ".xls"}
GLACIER_NC_KEY = "Glacier topographic and dynamic drivers"

def find_folder(prefix):
    """按附件文件夹编号查找，兼容中文括号/英文括号。"""
    for p in BASE_DIR.iterdir():
        if p.is_dir():
            name = p.name
            if name.startswith(f"（{prefix}）") or name.startswith(f"({prefix})"):
                return p
    return None

def find_files(folder, extensions=None):
    if folder is None or not folder.exists():
        return []
    out = []
    for p in folder.rglob("*"):
        if p.is_file() and (extensions is None or p.suffix.lower() in extensions):
            out.append(p)
    return out

def pick_single(candidates, label):
    if not candidates:
        print(f"[未找到] {label}")
        return None
    if len(candidates) == 1:
        print(f"[找到] {label}：{candidates[0]}")
        return candidates[0]
    print(f"\n[找到多个候选文件] {label}，请核实：")
    for i, p in enumerate(candidates, 1):
        print(f"  {i}. {p}")
    return None

def find_dem():
    folder = find_folder(7)
    candidates = [p for p in find_files(folder, RASTER_EXTS)
                  if "dem" in p.stem.lower() or "高程" in p.name or "地形" in p.name]
    if not candidates:
        candidates = [p for p in find_files(folder, RASTER_EXTS)]
    return pick_single(candidates, "DEM")

def find_landcover():
    folder = find_folder(5)
    candidates = [p for p in find_files(folder, RASTER_EXTS)
                  if "2023" in p.stem and ("lUCD".lower() in p.stem.lower()
                                             or "land" in p.stem.lower()
                                             or "覆盖" in p.stem
                                             or "利用" in p.stem)]
    if not candidates:
        candidates = [p for p in find_files(folder, RASTER_EXTS) if "2023" in p.stem]
    return pick_single(candidates, "2023年土地覆盖")

def find_glacier_nc():
    folder = find_folder(4)
    candidates = [p for p in find_files(folder, {".nc", ".nc4", ".netcdf"})]
    return pick_single(candidates, "冰川NetCDF文件")

def find_disaster_points():
    folder = find_folder(6)
    candidates = find_files(folder, VECTOR_EXTS)
    # 优先空间矢量文件；CSV/Excel 只有在没有矢量时才使用
    vector_candidates = [p for p in candidates if p.suffix.lower() in {".shp", ".gpkg", ".geojson", ".json"}]
    if vector_candidates:
        return pick_single(vector_candidates, "历史灾点矢量文件")
    tabular = [p for p in candidates if p.suffix.lower() in {".csv", ".xlsx", ".xls"}]
    return pick_single(tabular, "历史灾点表格文件")

def print_raster_info(path, label):
    import rasterio
    if path is None:
        return None
    try:
        with rasterio.open(path) as ds:
            arr = ds.read(1, masked=True).astype("float64")
            vals = arr.compressed()
            row = {
                "数据": label, "文件": str(path), "CRS": str(ds.crs),
                "宽度": ds.width, "高度": ds.height, "波段数": ds.count,
                "分辨率_x": ds.res[0], "分辨率_y": ds.res[1],
                "NoData": ds.nodata, "有效像元数": int(vals.size),
                "最小值": float(vals.min()) if vals.size else np.nan,
                "中位数": float(np.median(vals)) if vals.size else np.nan,
                "最大值": float(vals.max()) if vals.size else np.nan,
            }
            print(f"\n[{label}] CRS={ds.crs}; 分辨率={ds.res}; 大小={ds.width}x{ds.height}")
            print(f"有效值范围：{row['最小值']} 至 {row['最大值']}")
            return row
    except Exception as e:
        print(f"[读取失败] {label}: {e}")
        return None

def make_projected_dem(dem_path):
    """若DEM为经纬度坐标，重投影为UTM 45N；输出分析副本，不动原文件。"""
    import rasterio
    from rasterio.warp import calculate_default_transform, reproject, Resampling

    if dem_path is None:
        return None

    out_path = OUT_DIR / "DEM_UTM45N.tif"
    with rasterio.open(dem_path) as src:
        if src.crs is None:
            raise ValueError("DEM没有坐标系信息。请先从数据说明中确认CRS，不能猜测。")
        print("\n原始DEM坐标系：", src.crs)
        if not src.crs.is_geographic:
            print("DEM已是投影坐标系，将直接用于坡度计算。")
            return dem_path

        target_crs = "EPSG:32645"
        transform, width, height = calculate_default_transform(
            src.crs, target_crs, src.width, src.height, *src.bounds
        )
        profile = src.profile.copy()
        profile.update(
            crs=target_crs, transform=transform, width=width, height=height,
            compress="deflate"
        )
        print(f"正在将经纬度DEM重投影到 {target_crs} ...")
        with rasterio.open(out_path, "w", **profile) as dst:
            for band in range(1, src.count + 1):
                reproject(
                    source=rasterio.band(src, band),
                    destination=rasterio.band(dst, band),
                    src_transform=src.transform,
                    src_crs=src.crs,
                    src_nodata=src.nodata,
                    dst_transform=transform,
                    dst_crs=target_crs,
                    dst_nodata=src.nodata,
                    resampling=Resampling.bilinear
                )
    print("[生成] 投影后的DEM：", out_path)
    return out_path

def calc_slope_aspect(dem, transform):
    dx, dy = abs(transform.a), abs(transform.e)
    if dx == 0 or dy == 0:
        raise ValueError("DEM像元分辨率异常，无法计算坡度。")
    # 对NoData周边可能存在的NaN，梯度会传播NaN；保留为缺失值是安全做法
    gy, gx = np.gradient(dem, dy, dx)
    slope = np.degrees(np.arctan(np.sqrt(gx**2 + gy**2)))
    aspect = (np.degrees(np.arctan2(-gx, gy)) + 360) % 360
    slope[~np.isfinite(dem)] = np.nan
    aspect[~np.isfinite(dem)] = np.nan
    return slope, aspect

def inspect_netcdf(nc_path):
    """读取冰川NetCDF元数据。部分Windows底层HDF5库对中文路径兼容性不佳，
    因此先复制到纯英文短路径再打开；原始文件不做修改。"""
    if nc_path is None:
        return
    try:
        import xarray as xr
    except ImportError:
        print("\n[缺少依赖] 请在 math_model 环境运行：conda install xarray netcdf4")
        return

    rows = []
    print("\n========== 冰川NetCDF数据集信息 ==========")
    try:
        # 已验证 D:\\glacier_test.nc 可被 xarray 正常读取
        nc_temp_path = Path(r"D:\glacier_test.nc")
        shutil.copy2(nc_path, nc_temp_path)
        print("[NetCDF] 已复制到英文短路径：", nc_temp_path)

        with xr.open_dataset(nc_temp_path) as ds:
            print(ds)
            print("\n维度：", dict(ds.sizes))
            print("\n变量信息：")
            for name, var in ds.data_vars.items():
                units = var.attrs.get("units", "")
                long_name = var.attrs.get("long_name", "")
                standard_name = var.attrs.get("standard_name", "")
                print(f"- {name}: dims={var.dims}, shape={var.shape}, units={units}, "
                      f"long_name={long_name}, standard_name={standard_name}")
                rows.append({
                    "变量名": name, "维度": str(var.dims), "形状": str(var.shape),
                    "单位": units, "long_name": long_name,
                    "standard_name": standard_name, "属性": str(var.attrs)
                })
            print("\n坐标信息：")
            for name, coord in ds.coords.items():
                print(f"- {name}: dims={coord.dims}, shape={coord.shape}, 属性={coord.attrs}")

            # 输出关键变量的有效值统计，便于后续核查，不在此阶段做空间合并
            stats = []
            for name in ["dem", "slope", "thickness", "vx", "vy", "v", "glacier_mask"]:
                if name not in ds:
                    continue
                arr = np.asarray(ds[name].values, dtype="float64")
                valid = arr[np.isfinite(arr)]
                stats.append({
                    "变量名": name,
                    "单位": ds[name].attrs.get("units", ""),
                    "有效像元数": int(valid.size),
                    "最小值": float(valid.min()) if valid.size else np.nan,
                    "中位数": float(np.median(valid)) if valid.size else np.nan,
                    "均值": float(valid.mean()) if valid.size else np.nan,
                    "最大值": float(valid.max()) if valid.size else np.nan,
                })

        pd.DataFrame(rows).to_csv(
            OUT_DIR / "06_冰川NetCDF变量清单.csv", index=False, encoding="utf-8-sig"
        )
        if stats:
            pd.DataFrame(stats).to_csv(
                OUT_DIR / "06_冰川关键变量统计.csv", index=False, encoding="utf-8-sig"
            )
        print("[输出] ", OUT_DIR / "06_冰川NetCDF变量清单.csv")
        print("[输出] ", OUT_DIR / "06_冰川关键变量统计.csv")
        print("注意：NetCDF变量已读取，但空间匹配前仍需确认坐标参考系与覆盖范围。")
    except Exception as e:
        print(f"[读取NetCDF失败] {type(e).__name__}: {e}")
        print("如果英文短路径也读取失败，请把完整报错发来。")

def inspect_disaster_points(path):
    if path is None:
        return
    suffix = path.suffix.lower()
    try:
        if suffix in {".shp", ".gpkg", ".geojson", ".json"}:
            import geopandas as gpd
            gdf = gpd.read_file(path)
            print("\n历史灾点数据：", path)
            print("记录数：", len(gdf), "CRS：", gdf.crs)
            print("字段：", list(gdf.columns))
            print(gdf.head())
            gdf.drop(columns="geometry").to_csv(
                OUT_DIR / "07_历史灾点属性表预览.csv", index=False, encoding="utf-8-sig"
            )
        elif suffix == ".csv":
            df = pd.read_csv(path, encoding="utf-8-sig")
            print("\n历史灾点CSV：", path, "形状：", df.shape)
            print("字段：", list(df.columns))
            print(df.head())
            df.head(20).to_csv(OUT_DIR / "07_历史灾点属性表预览.csv",
                               index=False, encoding="utf-8-sig")
        elif suffix in {".xlsx", ".xls"}:
            df = pd.read_excel(path)
            print("\n历史灾点Excel：", path, "形状：", df.shape)
            print("字段：", list(df.columns))
            print(df.head())
            df.head(20).to_csv(OUT_DIR / "07_历史灾点属性表预览.csv",
                               index=False, encoding="utf-8-sig")
    except Exception as e:
        print(f"[历史灾点读取失败] {e}")

def main():
    if not BASE_DIR.exists():
        raise FileNotFoundError(f"附件目录不存在：{BASE_DIR}")

    print("附件目录：", BASE_DIR)
    print("分析输出目录：", OUT_DIR)

    dem_original = find_dem()
    landcover_path = find_landcover()
    glacier_nc = find_glacier_nc()
    disaster_path = find_disaster_points()

    if dem_original is None:
        print("\n没有唯一识别到DEM。请检查附件（7）目录中的文件名。")
        return

    dem_path = make_projected_dem(dem_original)

    infos = []
    info = print_raster_info(dem_path, "DEM（用于地形分析）")
    if info:
        infos.append(info)
    info = print_raster_info(landcover_path, "土地覆盖（2023）")
    if info:
        infos.append(info)
    pd.DataFrame(infos).to_csv(
        OUT_DIR / "01_栅格数据清单.csv", index=False, encoding="utf-8-sig"
    )

    # DEM地形分析
    import rasterio
    with rasterio.open(dem_path) as ds:
        dem_ma = ds.read(1, masked=True).astype("float64")
        dem = dem_ma.filled(np.nan)
        transform, crs = ds.transform, ds.crs

    if crs is None or crs.is_geographic:
        raise ValueError(f"DEM仍不是可用于米制坡度计算的投影坐标系：{crs}")

    slope, aspect = calc_slope_aspect(dem, transform)
    valid_dem = np.isfinite(dem)
    valid_slope = np.isfinite(slope)
    if not valid_dem.any() or not valid_slope.any():
        raise ValueError("DEM没有有效像元，无法统计。")

    np.save(OUT_DIR / "DEM_elevation.npy", dem.astype("float32"))
    np.save(OUT_DIR / "DEM_slope_degree.npy", slope.astype("float32"))
    np.save(OUT_DIR / "DEM_aspect_degree.npy", aspect.astype("float32"))

    summary = pd.DataFrame([{
        "有效DEM像元数": int(valid_dem.sum()),
        "高程_min": float(np.nanmin(dem)),
        "高程_median": float(np.nanmedian(dem)),
        "高程_max": float(np.nanmax(dem)),
        "坡度_min": float(np.nanmin(slope)),
        "坡度_median": float(np.nanmedian(slope)),
        "坡度_max": float(np.nanmax(slope)),
        "DEM_CRS": str(crs),
        "像元分辨率_x_m": abs(transform.a),
        "像元分辨率_y_m": abs(transform.e),
    }])
    summary.to_csv(OUT_DIR / "02_DEM地形统计.csv", index=False, encoding="utf-8-sig")

    bins = [-0.001, 5, 15, 25, 35, 45, 90]
    labels = ["0-5°", "5-15°", "15-25°", "25-35°", "35-45°", ">45°"]
    classes = pd.cut(slope[valid_slope], bins=bins, labels=labels)
    counts = pd.Series(classes).value_counts(sort=False)
    pd.DataFrame({
        "坡度等级": counts.index.astype(str),
        "像元数": counts.values,
        "面积占比（像元比例）": counts.values / max(1, counts.values.sum())
    }).to_csv(OUT_DIR / "03_坡度分级统计.csv", index=False, encoding="utf-8-sig")

    plt.figure(figsize=(9, 7))
    im = plt.imshow(np.where(valid_dem, dem, np.nan), cmap="terrain")
    plt.colorbar(im, label="Elevation (check source unit)")
    plt.title("DEM Elevation")
    plt.tight_layout()
    plt.savefig(FIG_DIR / "01_DEM高程图.png", dpi=200)
    plt.close()

    plt.figure(figsize=(9, 7))
    im = plt.imshow(slope, cmap="viridis", vmin=0, vmax=60)
    plt.colorbar(im, label="Slope (degree)")
    plt.title("Slope")
    plt.tight_layout()
    plt.savefig(FIG_DIR / "02_坡度图.png", dpi=200)
    plt.close()

    inspect_netcdf(glacier_nc)
    inspect_disaster_points(disaster_path)

    readme = f"""问题一后续交叉验证输出说明
DEM原始文件：{dem_original}
DEM分析文件：{dem_path}
DEM CRS：{crs}

输出文件：
01_栅格数据清单.csv：DEM和土地覆盖栅格的基本信息。
02_DEM地形统计.csv：高程、坡度整体统计。
03_坡度分级统计.csv：坡度等级像元比例。
06_冰川NetCDF变量清单.csv：冰川NetCDF变量、维度、单位及属性。
07_历史灾点属性表预览.csv：若成功读取，保存历史灾点属性预览。
figures：DEM高程图、坡度图。

解释限制：
1. NetCDF变量尚需依据变量名、单位、坐标与数据说明确认，未自动猜测冰川速度或厚度。
2. 单期DEM/冰川数据只能描述空间背景，不能证明灾前变化趋势。
3. 土地覆盖选用2023年数据，与2026年事件存在时间差。
4. 历史灾点只有在确认位置坐标系、字段含义后，才能进行栅格采样或统计。
5. 坡度计算要求投影坐标单位为米；重投影只生成分析副本，不修改原始DEM。
"""
    (OUT_DIR / "README_结果说明.txt").write_text(readme, encoding="utf-8")
    print("\n完成。输出目录：", OUT_DIR)
    print("请查看 01_栅格数据清单.csv、02_DEM地形统计.csv、06_冰川NetCDF变量清单.csv。")

if __name__ == "__main__":
    main()
