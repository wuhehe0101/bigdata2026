# -*- coding: utf-8 -*-
"""
吉隆县问题一：扩展多年6—9月暖季背景数据集，并建立严格同期对照
输入：Jilong_Master_Cleaned.csv（清洗后的逐小时综合观测数据）
输出目录：问题一/Question1_WarmSeason_Expanded
说明：
1. 保留原有结果，不覆盖旧目录。
2. 事件时间为2026-08-26 10:30，使用最后一个完整小时2026-08-26 10:00作为分析截止点。
3. 历史暖季背景使用2021—2025年6月1日至9月30日。
4. 严格同期对照使用2021—2025年每年8月19日至26日，并另外比较各年8月26日截止时刻之前的6/24/48/72小时窗口。
"""

from pathlib import Path
import sys
import warnings
import numpy as np
import pandas as pd

warnings.filterwarnings("ignore", category=RuntimeWarning)

PROJECT_DIR = Path(r"D:\pythonProjects\mother_model\问题一")
ATTACHMENT_DIR = Path(r"D:\pythonProjects\mother_model\附件")
OUTPUT_DIR = PROJECT_DIR / "Question1_WarmSeason_Expanded"

EVENT_CUTOFF = pd.Timestamp("2026-08-26 10:00:00")
EVENT_DATE_START = pd.Timestamp("2026-08-26 00:00:00")
WARM_START_MONTH = 6
WARM_END_MONTH = 9
HISTORICAL_YEARS = list(range(2021, 2026))

# 主要分析变量：存在于数据中时自动分析；不会因为个别变量缺失而终止
VARIABLES = [
    "Ta_2m(degree C)",
    "RH_2m(%)",
    "VPD(hPa)",
    "Rsd(W/m2)",
    "Rsu(W/m2)",
    "Rld(W/m2)",
    "Rlu(W/m2)",
    "Precip(mm)",
    "H(W/m2)",
    "LE(W/m2)",
    "USTAR(m/s)",
    "TKE(m2/s2)",
    "WS_2m(m/s)",
    "WS_10m(m/s)",
    "WS_20m(m/s)",
    "VWC_0.1m(m3/m3)",
    "VWC_0.2m(m3/m3)",
    "VWC_0.4m(m3/m3)",
    "VWC_0.8m(m3/m3)",
    "VWC_1.6m(m3/m3)",
    "soilT_0.1m(degree C)",
    "soilT_0.2m(degree C)",
    "soilT_0.4m(degree C)",
    "soilT_0.8m(degree C)",
    "soilT_1.6m(degree C)",
]

def find_input_file():
    candidates = [
        PROJECT_DIR / "Jilong_Master_Cleaned.csv",
        PROJECT_DIR / "Jilong_Master_Cleaned(1).csv",
        ATTACHMENT_DIR / "Jilong_Master_Cleaned.csv",
        ATTACHMENT_DIR / "Jilong_Master_Cleaned(1).csv",
    ]
    for p in candidates:
        if p.exists():
            return p

    search_roots = [PROJECT_DIR, ATTACHMENT_DIR]
    found = []
    for root in search_roots:
        if root.exists():
            found.extend(root.rglob("Jilong_Master_Cleaned.csv"))
            found.extend(root.rglob("Jilong_Master_Cleaned(1).csv"))
    if found:
        # Prefer exact filename without (1), and the project folder if possible
        found = sorted(set(found), key=lambda p: ("(1)" in p.name, str(p).count("附件"), len(str(p))))
        return found[0]
    return None

def safe_write_csv(df, path):
    df.to_csv(path, index=False, encoding="utf-8-sig")

def summarize_by_variable(df, variables, group_label):
    rows = []
    for var in variables:
        if var not in df.columns:
            continue
        x = pd.to_numeric(df[var], errors="coerce").dropna()
        rows.append({
            "数据集": group_label,
            "指标": var,
            "有效小时数": int(x.size),
            "缺失率": float(df[var].isna().mean()) if len(df) else np.nan,
            "均值": x.mean() if len(x) else np.nan,
            "标准差": x.std(ddof=1) if len(x) > 1 else np.nan,
            "中位数": x.median() if len(x) else np.nan,
            "P05": x.quantile(0.05) if len(x) else np.nan,
            "P90": x.quantile(0.90) if len(x) else np.nan,
            "P95": x.quantile(0.95) if len(x) else np.nan,
            "最大值": x.max() if len(x) else np.nan,
            "最小值": x.min() if len(x) else np.nan,
        })
    return rows

def window_stats(df, end_time, hours, variables):
    start_time = end_time - pd.Timedelta(hours=hours)
    # 使用 (start, end] 区间；对规则逐小时数据通常对应hours条记录
    w = df[(df["Timestamp"] > start_time) & (df["Timestamp"] <= end_time)]
    out = {
        "窗口结束时间": end_time,
        "窗口开始时间（不含）": start_time,
        "窗口长度_小时": hours,
        "实际记录数": int(len(w)),
    }
    for var in variables:
        if var not in w.columns:
            continue
        vals = pd.to_numeric(w[var], errors="coerce").dropna()
        out[f"{var}_有效小时数"] = int(vals.size)
        out[f"{var}_均值"] = vals.mean() if len(vals) else np.nan
        out[f"{var}_中位数"] = vals.median() if len(vals) else np.nan
        out[f"{var}_最大值"] = vals.max() if len(vals) else np.nan
        out[f"{var}_最小值"] = vals.min() if len(vals) else np.nan
        if var == "Precip(mm)":
            out[f"{var}_累计值"] = vals.sum() if len(vals) else np.nan
    return out

def main():
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    input_path = find_input_file()
    if input_path is None:
        print("错误：未找到 Jilong_Master_Cleaned.csv。")
        print("请将清洗后的CSV放在以下任一目录：")
        print("  ", PROJECT_DIR)
        print("  ", ATTACHMENT_DIR)
        sys.exit(1)

    print("读取文件：", input_path)
    # 尝试常见编码
    df = None
    last_error = None
    for enc in ["utf-8-sig", "utf-8", "gb18030"]:
        try:
            df = pd.read_csv(input_path, encoding=enc, low_memory=False)
            break
        except Exception as e:
            last_error = e
    if df is None:
        raise RuntimeError(f"读取CSV失败：{last_error}")

    if "Timestamp" not in df.columns:
        raise KeyError("数据中找不到 Timestamp 时间列。")

    df["Timestamp"] = pd.to_datetime(df["Timestamp"], errors="coerce")
    bad_time_count = int(df["Timestamp"].isna().sum())
    df = df.dropna(subset=["Timestamp"]).sort_values("Timestamp").drop_duplicates("Timestamp")
    available_vars = [v for v in VARIABLES if v in df.columns]

    # 衍生净辐射：Rn = Rsd - Rsu + Rld - Rlu
    rad_cols = ["Rsd(W/m2)", "Rsu(W/m2)", "Rld(W/m2)", "Rlu(W/m2)"]
    if all(c in df.columns for c in rad_cols):
        df["Rn(W/m2)"] = (
            pd.to_numeric(df[rad_cols[0]], errors="coerce")
            - pd.to_numeric(df[rad_cols[1]], errors="coerce")
            + pd.to_numeric(df[rad_cols[2]], errors="coerce")
            - pd.to_numeric(df[rad_cols[3]], errors="coerce")
        )
        if "Rn(W/m2)" not in available_vars:
            available_vars.append("Rn(W/m2)")

    df["Year"] = df["Timestamp"].dt.year
    df["Month"] = df["Timestamp"].dt.month
    df["Date"] = df["Timestamp"].dt.date

    # 1. 多年6—9月暖季背景（2021—2025）
    warm = df[
        df["Year"].isin(HISTORICAL_YEARS)
        & df["Month"].between(WARM_START_MONTH, WARM_END_MONTH)
    ].copy()
    safe_write_csv(warm, OUTPUT_DIR / "21_2021-2025年6-9月暖季逐小时背景数据.csv")

    # 2. 每年暖季按日汇总，降低把连续小时误当独立样本的风险
    daily_rows = []
    for date, g in warm.groupby("Date", sort=True):
        row = {"日期": str(date), "年份": pd.Timestamp(date).year, "有效记录数": len(g)}
        for var in available_vars:
            vals = pd.to_numeric(g[var], errors="coerce").dropna()
            row[f"{var}_日均值"] = vals.mean() if len(vals) else np.nan
            row[f"{var}_日最大值"] = vals.max() if len(vals) else np.nan
            row[f"{var}_日最小值"] = vals.min() if len(vals) else np.nan
            if var == "Precip(mm)":
                row[f"{var}_日累计值"] = vals.sum() if len(vals) else np.nan
        daily_rows.append(row)
    daily = pd.DataFrame(daily_rows)
    safe_write_csv(daily, OUTPUT_DIR / "22_2021-2025年6-9月逐日指标.csv")

    # 3. 暖季整体描述统计
    summary_rows = summarize_by_variable(warm, available_vars, "2021-2025年6-9月暖季")
    safe_write_csv(pd.DataFrame(summary_rows), OUTPUT_DIR / "23_暖季背景指标描述统计.csv")

    # 4. 事件前6/24/48/72小时窗口
    event_rows = []
    for h in [6, 24, 48, 72]:
        event_rows.append(window_stats(df, EVENT_CUTOFF, h, available_vars))
    event_windows = pd.DataFrame(event_rows)
    safe_write_csv(event_windows, OUTPUT_DIR / "24_2026事件前6-24-48-72小时指标.csv")

    # 5. 严格同期：各历史年份8月19—26日全时段
    strict_start = pd.Timestamp("2000-08-19 00:00:00")
    strict_rows = []
    for year in HISTORICAL_YEARS:
        s = pd.Timestamp(f"{year}-08-19 00:00:00")
        e = pd.Timestamp(f"{year}-08-26 23:00:00")
        g = df[(df["Timestamp"] >= s) & (df["Timestamp"] <= e)].copy()
        row = {"年份": year, "开始时间": s, "结束时间": e, "记录数": len(g)}
        for var in available_vars:
            vals = pd.to_numeric(g[var], errors="coerce").dropna()
            row[f"{var}_有效小时数"] = len(vals)
            row[f"{var}_均值"] = vals.mean() if len(vals) else np.nan
            row[f"{var}_中位数"] = vals.median() if len(vals) else np.nan
            row[f"{var}_最大值"] = vals.max() if len(vals) else np.nan
            if var == "Precip(mm)":
                row[f"{var}_累计值"] = vals.sum() if len(vals) else np.nan
        strict_rows.append(row)
    safe_write_csv(pd.DataFrame(strict_rows), OUTPUT_DIR / "25_逐年严格同期8月19-26日统计.csv")

    # 6. 各历史年在8月26日10:00之前的同长度窗口，与事件前窗口并列
    hist_window_rows = []
    for year in HISTORICAL_YEARS:
        end_time = pd.Timestamp(f"{year}-08-26 10:00:00")
        for h in [6, 24, 48, 72]:
            row = window_stats(df, end_time, h, available_vars)
            row["年份"] = year
            hist_window_rows.append(row)
    hist_windows = pd.DataFrame(hist_window_rows)
    safe_write_csv(hist_windows, OUTPUT_DIR / "26_逐年严格同期6-24-48-72小时窗口.csv")

    # 7. 将事件窗口与历史同长度窗口均值做简单对照；给出经验百分位，不把小时当独立样本做显著性检验
    comparison_rows = []
    for h in [6, 24, 48, 72]:
        ev = event_windows[event_windows["窗口长度_小时"] == h]
        if ev.empty:
            continue
        erow = ev.iloc[0]
        hist_h = hist_windows[hist_windows["窗口长度_小时"] == h]
        for var in available_vars:
            col = f"{var}_均值"
            if col not in hist_h.columns or col not in event_windows.columns:
                continue
            hv = pd.to_numeric(hist_h[col], errors="coerce").dropna()
            ev_val = pd.to_numeric(pd.Series([erow.get(col, np.nan)]), errors="coerce").iloc[0]
            if len(hv) == 0 or pd.isna(ev_val):
                continue
            # 历史窗口经验百分位：历史值中小于等于事件值的比例
            percentile = float((hv <= ev_val).mean() * 100)
            hist_mean = hv.mean()
            hist_sd = hv.std(ddof=1) if len(hv) > 1 else np.nan
            z = (ev_val - hist_mean) / hist_sd if pd.notna(hist_sd) and hist_sd > 0 else np.nan
            comparison_rows.append({
                "窗口长度_小时": h,
                "指标": var,
                "事件窗口均值": ev_val,
                "历史5年同期窗口均值的平均值": hist_mean,
                "历史5年同期窗口均值的最小值": hv.min(),
                "历史5年同期窗口均值的最大值": hv.max(),
                "历史5年同期经验百分位(%)": percentile,
                "相对历史均值标准化差异": z,
                "历史年份有效数": int(len(hv)),
                "解释提醒": "历史年份仅5个，经验百分位和标准化差异仅作描述，不宜单独作为显著性证据",
            })
    safe_write_csv(pd.DataFrame(comparison_rows), OUTPUT_DIR / "27_事件窗口与逐年同期窗口对照.csv")

    # 8. 质量摘要
    quality = {
        "输入文件": str(input_path),
        "原始读入记录数": int(len(pd.read_csv(input_path, encoding="utf-8-sig", nrows=0).columns)) if False else int(len(df) + bad_time_count),
        "有效时间记录数（去除无效时间和重复时间后）": int(len(df)),
        "无效时间记录数": bad_time_count,
        "时间起点": str(df["Timestamp"].min()),
        "时间终点": str(df["Timestamp"].max()),
        "数据字段数（含衍生字段）": int(len(df.columns)),
        "2021-2025年6-9月暖季小时记录数": int(len(warm)),
        "暖季日期数": int(warm["Timestamp"].dt.date.nunique()),
        "暖季逐日数据行数": int(len(daily)),
        "事件分析截止时间": str(EVENT_CUTOFF),
        "事件前窗口记录数（6小时）": int(event_windows.iloc[0]["实际记录数"]) if len(event_windows) > 0 else 0,
        "事件前窗口记录数（24小时）": int(event_windows.iloc[1]["实际记录数"]) if len(event_windows) > 1 else 0,
        "事件前窗口记录数（48小时）": int(event_windows.iloc[2]["实际记录数"]) if len(event_windows) > 2 else 0,
        "事件前窗口记录数（72小时）": int(event_windows.iloc[3]["实际记录数"]) if len(event_windows) > 3 else 0,
        "分析变量": "；".join(available_vars),
        "说明": "小时记录存在时间自相关；暖季描述统计用于背景刻画，事件判断需结合逐日统计和严格同期对照。降水列为逐小时值时，窗口累计量按窗口内有效值求和。",
    }
    pd.DataFrame([quality]).to_csv(OUTPUT_DIR / "28_数据集构建质量摘要.csv", index=False, encoding="utf-8-sig")

    with open(OUTPUT_DIR / "00_运行说明.txt", "w", encoding="utf-8") as f:
        f.write("吉隆县问题一：多年暖季背景数据集构建完成\\n")
        f.write(f"输入文件：{input_path}\\n")
        f.write(f"输出目录：{OUTPUT_DIR}\\n\\n")
        f.write("请优先检查：\\n")
        f.write("21_2021-2025年6-9月暖季逐小时背景数据.csv：扩展后的逐小时背景数据\\n")
        f.write("22_2021-2025年6-9月逐日指标.csv：按天汇总，减少小时自相关影响\\n")
        f.write("24_2026事件前6-24-48-72小时指标.csv：事件前窗口指标\\n")
        f.write("26_逐年严格同期6-24-48-72小时窗口.csv：逐年同长度窗口\\n")
        f.write("27_事件窗口与逐年同期窗口对照.csv：事件窗口与历史年份对照\\n\\n")
        f.write("注意：2021—2025年历史同期只有5个年度窗口，结果应作为描述性稳健性检查，不要仅凭5个年度样本做强结论。\\n")
    print("\\n完成！输出目录：", OUTPUT_DIR)
    print("暖季逐小时记录数：", len(warm))
    print("暖季逐日记录数：", len(daily))
    print("分析变量：", ", ".join(available_vars))
    print("建议优先检查输出文件 21、22、24、26、27、28。")

if __name__ == "__main__":
    main()
