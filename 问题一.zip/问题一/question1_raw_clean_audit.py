
# -*- coding: utf-8 -*-
"""
原始数据与 clead.csv 定点核查脚本
只核查，不修改原始文件和清洗结果。

输出目录：clead.csv 同级目录/Question1_RawClean_Audit
"""

from pathlib import Path
import sys
import re
import numpy as np
import pandas as pd

# 默认路径
CLEANED_CSV_DEFAULT = Path(
    r"D:\pythonProjects\mother_model\问题一\clead.csv"
)
RAW_DATA_DIR_DEFAULT = Path(
    r"D:\pythonProjects\mother_model\附件\（1）西藏吉隆高寒山区地气相互作用逐小时综合观测数据集（2021–2026）"
)
OUTPUT_FOLDER = "Question1_RawClean_Audit"

# 可疑值阈值：仅用于标记，不自动删除
VPD_HIGH = 100.0
LONGWAVE_HIGH = 800.0
SHORTWAVE_NEGATIVE = -5.0


def read_csv(path):
    """兼容常见中文 CSV 编码。"""
    for enc in ("utf-8-sig", "utf-8", "gbk"):
        try:
            return pd.read_csv(path, encoding=enc, low_memory=False)
        except Exception:
            continue
    raise RuntimeError(f"无法读取 CSV：{path}")


def detect_time_col(df):
    """自动寻找时间列。"""
    for col in df.columns:
        name = str(col).strip().lower()
        if name in (
            "timestamp", "time", "datetime",
            "date_time", "date time"
        ):
            return col

    for col in df.columns:
        if "time" in str(col).lower():
            return col

    return None


def load_table(path):
    df = read_csv(path)
    time_col = detect_time_col(df)

    if time_col is None:
        return None, None

    df[time_col] = pd.to_datetime(df[time_col], errors="coerce")
    df = df.loc[df[time_col].notna()].copy()
    df = df.sort_values(time_col)

    return df, time_col


def classify_file(path):
    """依据文件名判断数据类型。"""
    name = path.name.upper()

    for typ in ("FLUX", "MET", "RADM", "SOIL"):
        if typ in name:
            return typ

    return "UNKNOWN"


def find_raw_files(root):
    if not root.exists():
        raise FileNotFoundError(
            f"原始数据目录不存在：{root}\n"
            "请在运行命令中指定正确的原始数据目录。"
        )

    files = []

    for path in root.rglob("*.csv"):
        if path.name.lower() == "clead.csv":
            continue

        if OUTPUT_FOLDER.lower() in str(path).lower():
            continue

        files.append(path)

    return files


def norm_name(name):
    """统一列名格式，便于匹配。"""
    return re.sub(r"\s+", "", str(name)).lower()


def find_column(df, candidates):
    """优先精确匹配，再匹配去单位后的名称。"""
    columns = list(df.columns)
    normalized = {col: norm_name(col) for col in columns}

    # 精确匹配
    for candidate in candidates:
        target = norm_name(candidate)

        for col in columns:
            if normalized[col] == target:
                return col

    # 去除单位后匹配
    for candidate in candidates:
        target = norm_name(candidate)
        target_base = re.sub(r"\([^)]*\)", "", target)

        for col in columns:
            current = normalized[col]
            current_base = re.sub(r"\([^)]*\)", "", current)

            if current_base == target_base:
                return col

    # 后缀匹配，兼容 FLUX_VPD(hPa) 等前缀列名
    for candidate in candidates:
        target = norm_name(candidate)

        for col in columns:
            current = normalized[col]

            if current.endswith(target):
                return col

    return None


def add_reason(raw_value, clean_value, qc_value=None):
    reasons = []

    if pd.isna(raw_value) and not pd.isna(clean_value):
        reasons.append("原始缺失、清洗后有值，可能由插值补出")

    elif not pd.isna(raw_value) and pd.isna(clean_value):
        reasons.append("原始有值、清洗后缺失，可能经过筛选或缺失值替换")

    elif not pd.isna(raw_value) and not pd.isna(clean_value):
        try:
            if not np.isclose(
                float(raw_value), float(clean_value),
                rtol=1e-6, atol=1e-6
            ):
                reasons.append("原始值与清洗值不同，可能涉及单位转换或插值")
        except (TypeError, ValueError):
            if str(raw_value) != str(clean_value):
                reasons.append("原始值与清洗值不同")

    if qc_value is not None and not pd.isna(qc_value):
        reasons.append(f"原始 QC 值={qc_value}，需核对数据说明")

    if not reasons:
        reasons.append("原始值与清洗值一致，仍需检查物理合理性")

    return "；".join(reasons)


def main():
    # 允许从命令行传入路径
    cleaned_path = (
        Path(sys.argv[1])
        if len(sys.argv) > 1
        else CLEANED_CSV_DEFAULT
    )

    raw_root = (
        Path(sys.argv[2])
        if len(sys.argv) > 2
        else RAW_DATA_DIR_DEFAULT
    )

    if not cleaned_path.is_file():
        raise FileNotFoundError(
            f"找不到清洗文件：{cleaned_path}\n"
            "请检查 clead.csv 的实际位置。"
        )

    output_dir = cleaned_path.parent / OUTPUT_FOLDER
    output_dir.mkdir(parents=True, exist_ok=True)

    cleaned_raw = read_csv(cleaned_path)
    clean_time_col = detect_time_col(cleaned_raw)

    if clean_time_col is None:
        raise ValueError("clead.csv 中未找到时间列。")

    cleaned_raw[clean_time_col] = pd.to_datetime(
        cleaned_raw[clean_time_col], errors="coerce"
    )
    cleaned_raw = cleaned_raw.loc[
        cleaned_raw[clean_time_col].notna()
    ].copy()

    cleaned_raw = cleaned_raw.sort_values(clean_time_col)
    duplicate_clean = int(
        cleaned_raw[clean_time_col].duplicated().sum()
    )

    cleaned = cleaned_raw.drop_duplicates(
        clean_time_col, keep="last"
    ).set_index(clean_time_col)

    print(f"清洗文件：{cleaned_path}")
    print(f"清洗数据唯一时间戳数：{len(cleaned):,}")
    print(f"清洗文件重复时间戳数：{duplicate_clean}")
    print(f"原始数据目录：{raw_root}")

    raw_files = find_raw_files(raw_root)

    inventory = []
    duplicate_rows = []
    audit_rows = []

    # 每个变量独立核查，避免一个变量的匹配掩盖其他变量
    specifications = {
        "FLUX": [
            ("VPD", ["VPD(hPa)", "VPD"]),
            ("e_sat", ["e_sat(kPa)", "e_sat"]),
            ("e_sat_probe", ["e_sat_probe(kPa)", "e_sat_probe"]),
            ("e", ["e(kPa)", "e"]),
            ("PA", ["PA(kPa)", "PA(hPa)", "PA"]),
        ],
        "RADM": [
            ("Rsd", ["Rsd(W/m2)", "Rsd"]),
            ("Rsu", ["Rsu(W/m2)", "Rsu"]),
            ("Rld", ["Rld(W/m2)", "Rld"]),
            ("Rlu", ["Rlu(W/m2)", "Rlu"]),
        ],
        "MET": [
            ("RH_1m", ["RH_1m(%)", "RH_1m"]),
            ("RH_2m", ["RH_2m(%)", "RH_2m"]),
            ("RH_20m", ["RH_20m(%)", "RH_20m"]),
        ],
        "SOIL": [
            ("VWC_0.8m", ["VWC_0.8m(m3/m3)", "VWC_0.8m"]),
            ("G_0.1m", ["G_0.1m(W/m2)", "G_0.1m"]),
        ],
    }

    for path in raw_files:
        typ = classify_file(path)

        try:
            raw_df, raw_time_col = load_table(path)

            if raw_df is None:
                inventory.append({
                    "文件": str(path),
                    "类型": typ,
                    "状态": "跳过：未找到时间列",
                    "行数": np.nan,
                    "重复时间戳数": np.nan,
                })
                continue

            duplicate_count = int(
                raw_df[raw_time_col].duplicated().sum()
            )

            inventory.append({
                "文件": str(path),
                "类型": typ,
                "状态": "已读取",
                "行数": len(raw_df),
                "重复时间戳数": duplicate_count,
            })

            if duplicate_count:
                duplicate_rows.append({
                    "文件": str(path),
                    "重复时间戳数": duplicate_count,
                })

            if typ not in specifications:
                continue

            raw_indexed = raw_df.drop_duplicates(
                raw_time_col, keep="last"
            ).set_index(raw_time_col)

            common_times = raw_indexed.index.intersection(
                cleaned.index
            )

            if len(common_times) == 0:
                continue

            for variable, candidates in specifications[typ]:
                raw_col = find_column(raw_df, candidates)

                clean_candidates = [
                    f"{typ}_{candidate}"
                    for candidate in candidates
                ] + candidates

                clean_col = find_column(
                    cleaned, clean_candidates
                )

                if raw_col is None or clean_col is None:
                    continue

                raw_values = pd.to_numeric(
                    raw_indexed[raw_col], errors="coerce"
                )
                clean_values = pd.to_numeric(
                    cleaned[clean_col], errors="coerce"
                )

                qc_col = None
                base = norm_name(
                    re.sub(r"\([^)]*\)", "", str(raw_col))
                )

                for col in raw_df.columns:
                    col_norm = norm_name(col)

                    if "qc" in col_norm and base in col_norm:
                        qc_col = col
                        break

                for ts in common_times:
                    rv = raw_values.loc[ts]
                    cv = clean_values.loc[ts]

                    if isinstance(rv, pd.Series):
                        rv = rv.iloc[-1]
                    if isinstance(cv, pd.Series):
                        cv = cv.iloc[-1]

                    qc_value = None
                    if qc_col is not None:
                        qc_value = raw_indexed.loc[ts, qc_col]
                        if isinstance(qc_value, pd.Series):
                            qc_value = qc_value.iloc[-1]

                    flagged = False

                    if pd.isna(rv) != pd.isna(cv):
                        flagged = True

                    elif not pd.isna(rv) and not pd.isna(cv):
                        if not np.isclose(
                            float(rv), float(cv),
                            rtol=1e-6, atol=1e-6
                        ):
                            flagged = True

                    # 额外标记明显可疑的数值
                    if not pd.isna(rv):
                        value = float(rv)

                        if variable == "VPD":
                            flagged |= value < 0 or value > VPD_HIGH

                        elif variable in ("e_sat", "e_sat_probe", "e"):
                            flagged |= value < 0 or value > 20

                        elif variable in ("Rsd", "Rsu"):
                            flagged |= value < SHORTWAVE_NEGATIVE

                        elif variable in ("Rld", "Rlu"):
                            flagged |= value < 0 or value > LONGWAVE_HIGH

                        elif variable.startswith("RH_"):
                            flagged |= value < 0 or value > 100

                        elif variable == "VWC_0.8m":
                            flagged |= value < 0 or value > 1

                        elif variable == "PA":
                            # 原始值与清洗值不同，尤其要检查是否乘以了 10
                            flagged |= not np.isclose(
                                value, float(cv) if not pd.isna(cv) else np.nan,
                                rtol=1e-6, atol=1e-6
                            )

                    if flagged:
                        audit_rows.append({
                            "Timestamp": ts,
                            "数据类型": typ,
                            "变量": variable,
                            "原始文件": str(path),
                            "原始变量列名": raw_col,
                            "清洗变量列名": clean_col,
                            "原始值": rv,
                            "清洗后值": cv,
                            "原始QC列": qc_col or "",
                            "原始QC值": (
                                qc_value
                                if qc_col is not None
                                else np.nan
                            ),
                            "可能原因": add_reason(
                                rv, cv, qc_value
                            ),
                        })

        except Exception as exc:
            inventory.append({
                "文件": str(path),
                "类型": typ,
                "状态": (
                    f"读取或核查失败："
                    f"{type(exc).__name__}: {exc}"
                ),
                "行数": np.nan,
                "重复时间戳数": np.nan,
            })

    # 输出原始文件清单
    pd.DataFrame(inventory).to_csv(
        output_dir / "00_原始文件清单.csv",
        index=False, encoding="utf-8-sig"
    )

    pd.DataFrame(
        duplicate_rows,
        columns=["文件", "重复时间戳数"]
    ).to_csv(
        output_dir / "00_原始文件重复时间戳.csv",
        index=False, encoding="utf-8-sig"
    )

    audit_columns = [
        "Timestamp", "数据类型", "变量", "原始文件",
        "原始变量列名", "清洗变量列名", "原始值",
        "清洗后值", "原始QC列", "原始QC值", "可能原因"
    ]

    audit = pd.DataFrame(
        audit_rows, columns=audit_columns
    )

    if not audit.empty:
        audit = audit.sort_values(
            ["数据类型", "变量", "Timestamp"]
        )

    audit.to_csv(
        output_dir / "01_原始值与清洗后值对照.csv",
        index=False, encoding="utf-8-sig"
    )

    if not audit.empty:
        summary = (
            audit.groupby(
                ["数据类型", "变量", "原始变量列名", "清洗变量列名"],
                dropna=False
            )
            .agg(
                被标记记录数=("Timestamp", "size"),
                最早时刻=("Timestamp", "min"),
                最晚时刻=("Timestamp", "max"),
            )
            .reset_index()
        )
    else:
        summary = pd.DataFrame(columns=[
            "数据类型", "变量", "原始变量列名",
            "清洗变量列名", "被标记记录数",
            "最早时刻", "最晚时刻"
        ])

    summary.to_csv(
        output_dir / "02_差异汇总.csv",
        index=False, encoding="utf-8-sig"
    )

    # 输出事件前72小时的差异记录
    if not audit.empty:
        times = pd.to_datetime(audit["Timestamp"])
        event_mask = (
            (times >= pd.Timestamp("2026-08-23 11:00:00"))
            & (times <= pd.Timestamp("2026-08-26 10:00:00"))
        )
        event_audit = audit.loc[event_mask].copy()
    else:
        event_audit = audit.copy()

    event_audit.to_csv(
        output_dir / "03_事件前72小时差异记录.csv",
        index=False, encoding="utf-8-sig"
    )

    print("\n核查完成。输出目录：")
    print(output_dir)
    print("\n生成文件：")
    for file in sorted(output_dir.glob("*.csv")):
        print(" -", file.name)

    if audit.empty:
        print(
            "\n未发现可输出的差异记录。"
            "请检查原始目录、文件名和变量列名；"
            "没有差异记录不代表数据一定正确。"
        )


if __name__ == "__main__":
    main()
