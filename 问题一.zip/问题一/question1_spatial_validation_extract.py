# -*- coding: utf-8 -*-
"""
问题一：空间交叉验证第二步
目标：
1. 对84个历史灾害多边形进行真实几何/有效像元检查（不只看矩形范围）
2. 提取与DEM相交灾点的高程统计
3. 提取灾点范围内土地覆盖类别计数（类别代码先保留，不擅自解释）
4. 在冰川网格有效像元上提取DEM、坡度、冰厚和速度变量，并用DEM做高程一致性检查
"""
from pathlib import Path
import shutil
import warnings
import numpy as np
import pandas as pd
import rasterio
from rasterio.mask import mask
from rasterio.warp import transform_bounds
import geopandas as gpd
import xarray as xr
from pyproj import CRS
from shapely.geometry import mapping, box

BASE = Path(r"D:\pythonProjects\mother_model\附件")
PROJECT = Path(r"D:\pythonProjects\mother_model\问题一")
OUT = PROJECT / "Question1_CrossValidation"
OUT.mkdir(parents=True, exist_ok=True)
TARGET_CRS = "EPSG:32645"

def find_one(folder_no, suffixes, keyword=None):
    folder = next((p for p in BASE.iterdir() if p.is_dir() and
                   (p.name.startswith(f"（{folder_no}）") or p.name.startswith(f"({folder_no})"))), None)
    if folder is None:
        raise FileNotFoundError(f"未找到附件文件夹（{folder_no}）")
    files = [p for p in folder.rglob("*") if p.is_file() and p.suffix.lower() in suffixes]
    if keyword:
        matched = [p for p in files if keyword.lower() in p.name.lower()]
        if matched:
            files = matched
    if len(files) != 1:
        raise RuntimeError(f"附件（{folder_no}）匹配到{len(files)}个文件：\n" + "\n".join(map(str, files)))
    return files[0]

dem_src = find_one(7, {".tif", ".tiff"}, "DEM")
land_src = find_one(5, {".tif", ".tiff"}, "2023")
nc_src = find_one(4, {".nc", ".nc4", ".netcdf"})
shp_src = find_one(6, {".shp", ".gpkg", ".geojson", ".json"})
print("DEM:", dem_src)
print("土地覆盖:", land_src)
print("冰川NetCDF:", nc_src)
print("历史灾害矢量:", shp_src)

# Read/reproject vector to the common analysis CRS
geo = gpd.read_file(shp_src)
if geo.crs is None:
    raise RuntimeError("历史灾害矢量缺少CRS，停止叠加以免产生错误结果。")
geo = geo[geo.geometry.notna() & ~geo.geometry.is_empty].copy()
geo["原始记录序号"] = np.arange(1, len(geo) + 1)
geo_p = geo.to_crs(TARGET_CRS)

# helper for raster stats by polygon; geometry is transformed into raster CRS
def zonal_stats_one(raster_path, geom_target, target_crs=TARGET_CRS):
    with rasterio.open(raster_path) as src:
        geom_src = gpd.GeoSeries([geom_target], crs=target_crs).to_crs(src.crs).iloc[0]
        if not geom_src.intersects(box(*src.bounds)):
            return {"范围相交": False, "有效像元数": 0}
        try:
            arr, _ = mask(src, [mapping(geom_src)], crop=True, filled=False, all_touched=False)
        except ValueError:
            return {"范围相交": True, "有效像元数": 0}
        band = arr[0]
        if np.ma.isMaskedArray(band):
            vals = band.compressed()
        else:
            vals = band.ravel()
            if src.nodata is not None:
                vals = vals[vals != src.nodata]
        vals = np.asarray(vals)
        vals = vals[np.isfinite(vals)]
        if vals.size == 0:
            return {"范围相交": True, "有效像元数": 0}
        return {
            "范围相交": True, "有效像元数": int(vals.size),
            "最小值": float(np.min(vals)), "均值": float(np.mean(vals)),
            "中位数": float(np.median(vals)), "最大值": float(np.max(vals)),
            "标准差": float(np.std(vals))
        }

# 1. Per-historical polygon actual raster coverage and zonal stats
results = []
for idx, row in geo_p.iterrows():
    geom = row.geometry
    name = str(row.get("Name", ""))
    code = str(row.get("Code", ""))
    rec = {"原始记录序号": int(row["原始记录序号"]), "Name": name, "Code": code}
    rec["几何与DEM范围相交"] = bool(geom.intersects(box(*rasterio.open(dem_src).bounds))) if False else None
    dem_stats = zonal_stats_one(dem_src, geom)
    rec["DEM范围相交"] = dem_stats.get("范围相交", False)
    rec["DEM有效像元数"] = dem_stats.get("有效像元数", 0)
    for k in ["最小值", "均值", "中位数", "最大值", "标准差"]:
        rec[f"DEM_{k}_m"] = dem_stats.get(k, np.nan)
    land_stats = zonal_stats_one(land_src, geom)
    rec["土地覆盖范围相交"] = land_stats.get("范围相交", False)
    rec["土地覆盖有效像元数"] = land_stats.get("有效像元数", 0)
    # Categorical raster: mode and class pixel counts; preserve raw class codes.
    with rasterio.open(land_src) as ls:
        g_land = gpd.GeoSeries([geom], crs=TARGET_CRS).to_crs(ls.crs).iloc[0]
        try:
            a, _ = mask(ls, [mapping(g_land)], crop=True, filled=False, all_touched=False)
            ar = a[0]
            vals = ar.compressed() if np.ma.isMaskedArray(ar) else ar.ravel()
            if ls.nodata is not None:
                vals = vals[vals != ls.nodata]
            vals = vals[np.isfinite(vals)]
            if len(vals):
                codes, counts = np.unique(vals.astype(int), return_counts=True)
                mode_idx = int(np.argmax(counts))
                rec["土地覆盖主类别代码"] = int(codes[mode_idx])
                rec["土地覆盖类别种数"] = int(len(codes))
                rec["土地覆盖类别计数"] = ";".join(f"{int(c)}:{int(n)}" for c, n in zip(codes, counts))
            else:
                rec["土地覆盖主类别代码"] = np.nan
                rec["土地覆盖类别种数"] = 0
                rec["土地覆盖类别计数"] = ""
        except ValueError:
            rec["土地覆盖主类别代码"] = np.nan
            rec["土地覆盖类别种数"] = 0
            rec["土地覆盖类别计数"] = ""
    results.append(rec)
    if (len(results) % 10) == 0:
        print(f"已处理历史灾害多边形：{len(results)}/{len(geo_p)}")

hist_df = pd.DataFrame(results)
hist_df.to_csv(OUT / "11_历史灾害多边形真实像元统计.csv", index=False, encoding="utf-8-sig")
print("\n历史灾害多边形数:", len(hist_df))
print("DEM内有有效像元的多边形数:", int((hist_df["DEM有效像元数"] > 0).sum()))
print("土地覆盖内有有效像元的多边形数:", int((hist_df["土地覆盖有效像元数"] > 0).sum()))

# 2. Glacier grid: summarize valid glacier cells and compare its DEM with the independent DEM raster
nc_tmp = Path(r"D:\glacier_test_spatial_validation.nc")
shutil.copy2(nc_src, nc_tmp)
with xr.open_dataset(nc_tmp) as ds:
    sr_attrs = ds["spatial_ref"].attrs if "spatial_ref" in ds else {}
    crs_text = sr_attrs.get("spatial_ref") or sr_attrs.get("crs_wkt")
    if not crs_text:
        raise RuntimeError("NetCDF缺少可解析CRS，不能继续空间匹配。")
    glacier_crs = CRS.from_user_input(crs_text)
    x = np.asarray(ds["x"].values, dtype=float)
    y = np.asarray(ds["y"].values, dtype=float)
    xx, yy = np.meshgrid(x, y)
    mask_arr = np.asarray(ds["glacier_mask"].values) if "glacier_mask" in ds else None
    if mask_arr is None:
        valid = np.ones(xx.shape, dtype=bool)
    else:
        valid = np.isfinite(mask_arr) & (mask_arr > 0)
    # Variables to summarize; use only glacier-mask cells and finite values.
    var_names = ["dem", "slope", "thickness", "v", "v_amp", "vx", "vy"]
    glacier_summary = []
    for var in var_names:
        if var not in ds:
            continue
        arr = np.asarray(ds[var].values, dtype=float)
        vals = arr[valid & np.isfinite(arr)]
        glacier_summary.append({
            "变量": var,
            "单位": ds[var].attrs.get("units", ""),
            "有效冰川像元数": int(vals.size),
            "最小值": float(np.min(vals)) if vals.size else np.nan,
            "均值": float(np.mean(vals)) if vals.size else np.nan,
            "中位数": float(np.median(vals)) if vals.size else np.nan,
            "最大值": float(np.max(vals)) if vals.size else np.nan,
            "标准差": float(np.std(vals)) if vals.size else np.nan,
            "数据时间属性": ds[var].attrs.get("standard_name", "")
        })
    pd.DataFrame(glacier_summary).to_csv(OUT / "12_冰川有效像元变量统计.csv", index=False, encoding="utf-8-sig")

    # sample independent DEM at glacier-cell centers; only within DEM bounds
    coords = np.column_stack([xx[valid].ravel(), yy[valid].ravel()])
    if glacier_crs.to_string() != TARGET_CRS:
        gdf_pts = gpd.GeoDataFrame(geometry=gpd.points_from_xy(coords[:,0], coords[:,1]), crs=glacier_crs).to_crs(TARGET_CRS)
        coords_target = np.column_stack([gdf_pts.geometry.x, gdf_pts.geometry.y])
    else:
        coords_target = coords
    with rasterio.open(dem_src) as dem:
        if dem.crs.to_string() != TARGET_CRS:
            # sample expects coordinates in the DEM CRS
            pts = gpd.GeoDataFrame(geometry=gpd.points_from_xy(coords_target[:,0], coords_target[:,1]), crs=TARGET_CRS).to_crs(dem.crs)
            sample_coords = [(p.x, p.y) for p in pts.geometry]
        else:
            sample_coords = [tuple(p) for p in coords_target]
        dem_vals = np.array([v[0] for v in dem.sample(sample_coords)], dtype=float)
        if dem.nodata is not None:
            dem_vals[dem_vals == dem.nodata] = np.nan
    glacier_dem = np.asarray(ds["dem"].values, dtype=float)[valid].ravel()
    ok = np.isfinite(dem_vals) & np.isfinite(glacier_dem)
    diff = dem_vals[ok] - glacier_dem[ok]
    compare = pd.DataFrame([{
        "冰川有效像元总数": int(valid.sum()),
        "与DEM有效高程匹配像元数": int(ok.sum()),
        "DEM减冰川NetCDF_dem_平均差_m": float(np.mean(diff)) if diff.size else np.nan,
        "高程差绝对值中位数_m": float(np.median(np.abs(diff))) if diff.size else np.nan,
        "高程差绝对值均值_m": float(np.mean(np.abs(diff))) if diff.size else np.nan,
        "高程差标准差_m": float(np.std(diff)) if diff.size else np.nan,
        "说明": "这是两套高程栅格的像元中心抽样比较；差异可能来自分辨率、重采样、NoData和数据源，不应要求完全相等。"
    }])
    compare.to_csv(OUT / "13_冰川DEM高程一致性检查.csv", index=False, encoding="utf-8-sig")
    print("\n冰川有效像元数:", int(valid.sum()))
    print("冰川网格与DEM匹配的有效高程像元数:", int(ok.sum()))
    print("两套DEM平均高程差(m):", float(np.mean(diff)) if diff.size else "无有效匹配")
    print("注意：NetCDF中的v标注为2014—2024年气候态速度，不是2026年8月26日的实时速度。")

# 3. One-page summary
summary = [
    {"检查项":"历史灾害多边形总数","结果":len(hist_df),"解释":"原始历史灾害矢量有效几何数量"},
    {"检查项":"有DEM有效像元的历史多边形","结果":int((hist_df["DEM有效像元数"]>0).sum()),"解释":"可进行灾点多边形内高程统计"},
    {"检查项":"有土地覆盖有效像元的历史多边形","结果":int((hist_df["土地覆盖有效像元数"]>0).sum()),"解释":"可进行土地覆盖类别统计"},
    {"检查项":"有冰川栅格范围重叠的历史多边形","结果":int(geo_p.geometry.intersects(box(353442.5,3127917.5,357792.5,3132057.5)).sum()),"解释":"仅为基于当前NetCDF范围的几何相交数量；预期为0，需注意该数据与灾点区不直接重叠"}
]
pd.DataFrame(summary).to_csv(OUT / "14_空间交叉验证摘要.csv", index=False, encoding="utf-8-sig")
print("\n全部完成，输出目录:", OUT)
print("新增文件：11_历史灾害多边形真实像元统计.csv、12_冰川有效像元变量统计.csv、13_冰川DEM高程一致性检查.csv、14_空间交叉验证摘要.csv")
